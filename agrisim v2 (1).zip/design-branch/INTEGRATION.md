# AgriSim — Design v2 Integration Guide

## 1. Créer la branche

```bash
git checkout main
git pull origin main
git checkout -b feat/design-v2
```

---

## 2. Fichiers à remplacer (copie directe)

Ces fichiers remplacent entièrement leurs équivalents dans le repo :

| Fichier source (ce dossier)                        | Destination dans le repo                        |
|----------------------------------------------------|--------------------------------------------------|
| `src/index.css`                                    | `src/index.css`                                  |
| `src/components/AppHeader.tsx`                     | `src/components/AppHeader.tsx`                   |
| `src/components/HerdManagementPanel.tsx`           | `src/components/HerdManagementPanel.tsx`         |
| `src/components/CulturesPanel.tsx`                 | `src/components/CulturesPanel.tsx`               |

```bash
# Depuis la racine du repo, avec les fichiers de ce dossier dans /tmp/design-v2/ :
cp /tmp/design-v2/src/index.css src/index.css
cp /tmp/design-v2/src/components/AppHeader.tsx src/components/AppHeader.tsx
cp /tmp/design-v2/src/components/HerdManagementPanel.tsx src/components/HerdManagementPanel.tsx
cp /tmp/design-v2/src/components/CulturesPanel.tsx src/components/CulturesPanel.tsx
```

---

## 3. Patches manuels

### 3a. `src/lib/mapVisuals.ts`

Remplacer l'objet `COMMUNE_BORDER_STYLES` par le contenu de `src/lib/mapVisuals.patch.ts`.

Chercher dans le fichier :
```ts
export const COMMUNE_BORDER_STYLES: Record<string, CommuneBorderStyle> = {
```
Et remplacer tout le bloc jusqu'à `};` par la version dans le patch.

---

### 3b. `src/components/FarmMap.tsx`

Le fichier `src/components/FarmMap.patch.tsx` contient deux blocs de remplacement clairement annotés.

**Bloc 1** — chercher le commentaire :
```tsx
{/* Pass 1 — commune block rectangles only */}
```
Remplacer tout jusqu'au `</g>` fermant (avant `{/* Pass 2 — tiles */}`) par le bloc "Pass 1" du patch.

**Bloc 2** — chercher le commentaire :
```tsx
{/* Pass 3 — commune labels on top of everything */}
```
Remplacer tout jusqu'à la fin du `communeGroups.map(...)` par le bloc "Pass 3" du patch.

---

## 4. Ajouter la police DM Sans (optionnel si Tailwind gère les fonts)

Si votre projet n'utilise pas de CDN Google Fonts, installez via npm :

```bash
npm install @fontsource/dm-sans @fontsource/dm-mono
```

Puis dans `src/main.tsx` :
```ts
import '@fontsource/dm-sans/variable.css';
import '@fontsource/dm-mono/400.css';
import '@fontsource/dm-mono/500.css';
```

Ou garder l'`@import url(...)` dans `index.css` si vous avez accès internet en dev.

---

## 5. Vérifier que ça compile

```bash
npm run dev
```

Vérifier dans le navigateur :
- [ ] Header compact visible, DM Sans appliqué
- [ ] Sidebar cheptel : cartes fines, boutons +/− plus petits
- [ ] Sidebar cultures : même style
- [ ] Carte : contours communes avec pilules de labels

---

## 6. Commit & push

```bash
git add -A
git commit -m "feat: design v2 — DM Sans, compact header, commune pills, tighter sidebars"
git push origin feat/design-v2
```

Puis ouvrir une Pull Request sur GitHub.

---

## Résumé des changements visuels

| Zone            | Avant                              | Après                                      |
|-----------------|------------------------------------|--------------------------------------------|
| Typographie     | system-ui / Tailwind default       | DM Sans (texte) + DM Mono (chiffres)       |
| Header          | 64px, cards arrondies lourdes      | 60px, compact, boutons plats              |
| Sidebars        | `rounded-[2rem]`, padding 24px     | `rounded-[12px]`, padding 16px, plus dense |
| Commune labels  | Texte SVG brut                     | Pilules pill avec fond coloré              |
| Commune borders | Couleurs vives (orange/rouge)      | Palette verte/bleue/brune harmonieuse      |
| Tokens CSS      | Aucun                              | Variables `--color-*`, `--radius-*`        |
