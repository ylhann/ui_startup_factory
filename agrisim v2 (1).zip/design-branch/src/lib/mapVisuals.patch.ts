/**
 * PATCH: src/lib/mapVisuals.ts
 *
 * Replace the COMMUNE_BORDER_STYLES object with this updated version.
 * Colors are more refined and consistent with the new design palette.
 */

export const COMMUNE_BORDER_STYLES: Record<string, CommuneBorderStyle> = {
  plaine:             { color: '#2d5a27', width: 1.5,                  label: 'Plaine' },
  defavorisee_simple: { color: '#1a4a8a', width: 2,   dashArray: '7 4', label: 'Défavorisée' },
  montagne:           { color: '#8a3a1a', width: 2.5, dashArray: '7 4', label: 'Montagne' },
  haute_montagne:     { color: '#6b1a6b', width: 3,   dashArray: '7 4', label: 'Haute montagne' },
};
