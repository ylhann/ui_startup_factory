import {
  Tractor,
  User,
  Leaf,
  TrendingUp,
  Map as MapIcon,
  Calendar,
  BarChart2,
  Trees,
  Landmark,
  Database,
  Settings,
  ArrowRight,
  ChevronDown,
} from 'lucide-react';

import type { GameState, YearSummary } from '../types';
import { cn } from '../lib/utils';

interface AppHeaderProps {
  game: GameState;
  regionLabel: string;
  certificationLabel: string;
  estimatedSummary: YearSummary | null;
  totalOwnedHectaresNet: number;
  estiveSurfaceHa: number;
  allYears: Record<string, GameState>;
  isCalculating: boolean;
  setIsFarmerInfoOpen: (value: boolean) => void;
  setIsCertificationPickerOpen: (value: boolean) => void;
  setIsEstimatedGainsOpen: (value: boolean) => void;
  setIsMaecAdvisorOpen: (value: boolean) => void;
  setIsStatsOpen: (value: boolean) => void;
  setIsSnaManagerOpen: (value: boolean) => void;
  setIsScenarioOpen: (value: boolean) => void;
  setIsAdminOpen: (value: boolean) => void;
  setIsSettingsOpen: (value: boolean) => void;
  openParcelGroups: () => void;
  handleNextTurn: () => void;
  switchToYear: (yearKey: string) => void;
}

export function AppHeader({
  game,
  regionLabel,
  certificationLabel,
  estimatedSummary,
  totalOwnedHectaresNet,
  estiveSurfaceHa,
  allYears,
  isCalculating,
  setIsFarmerInfoOpen,
  setIsCertificationPickerOpen,
  setIsEstimatedGainsOpen,
  setIsMaecAdvisorOpen,
  setIsStatsOpen,
  setIsSnaManagerOpen,
  setIsScenarioOpen,
  setIsAdminOpen,
  setIsSettingsOpen,
  openParcelGroups,
  handleNextTurn,
  switchToYear,
}: AppHeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-[var(--color-white)] border-b border-[var(--color-border)] px-5 flex items-center justify-between h-[60px] shadow-[0_1px_0_var(--color-border)]">

      {/* ── Logo ── */}
      <div className="flex items-center gap-2.5 mr-6 shrink-0">
        <div className="w-8 h-8 rounded-[8px] bg-[var(--color-green)] flex items-center justify-center text-white">
          <Tractor size={18} />
        </div>
        <div>
          <div className="font-semibold text-[15px] leading-tight tracking-tight">AgriSim</div>
          <div className="text-[9px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.1em]">PAC 2026</div>
        </div>
      </div>

      <div className="w-px h-8 bg-[var(--color-border)] mr-5 shrink-0" />

      {/* ── Farmer + Certification ── */}
      <div className="flex items-center gap-2 mr-5">
        <button
          type="button"
          onClick={() => setIsFarmerInfoOpen(true)}
          className={cn(
            'flex items-center gap-2 px-3 py-2 rounded-[10px] border transition-colors text-left',
            'bg-[var(--color-bg)] border-[var(--color-border)] hover:bg-white hover:border-[#c8c8c0]'
          )}
        >
          <div className="w-6 h-6 rounded-[6px] bg-[var(--color-border)] flex items-center justify-center shrink-0 text-[var(--color-ink-60)]">
            <User size={14} />
          </div>
          <div>
            <div className="text-[10px] text-[var(--color-ink-30)] font-semibold leading-none mb-0.5">Agriculteur</div>
            <div className="text-[13px] font-semibold leading-none tracking-tight max-w-[160px] truncate">
              {game.farmer.name}
            </div>
          </div>
          <ChevronDown size={13} className="text-[var(--color-ink-30)]" />
        </button>

        <button
          type="button"
          onClick={() => setIsCertificationPickerOpen(true)}
          className="flex items-center gap-2 px-3 py-2 rounded-[10px] border bg-[var(--color-green-l)] border-[#c8dfc4] hover:brightness-95 transition-all text-left"
        >
          <Leaf size={14} className="text-[var(--color-green)] shrink-0" />
          <div>
            <div className="text-[10px] text-[var(--color-green)] font-semibold uppercase tracking-[.05em] leading-none mb-0.5">Certification</div>
            <div className="text-[13px] font-semibold leading-none tracking-tight">{certificationLabel}</div>
          </div>
        </button>
      </div>

      <div className="w-px h-8 bg-[var(--color-border)] mr-5 shrink-0" />

      {/* ── Key metrics ── */}
      <div className="hidden md:flex items-center gap-5 mr-auto">
        <button
          onClick={() => setIsEstimatedGainsOpen(true)}
          className="text-left hover:bg-[var(--color-bg)] px-2 py-1 rounded-[8px] transition-colors"
        >
          <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] leading-none mb-1">Subventions</div>
          <div className="flex items-center gap-1.5 text-[var(--color-green)] font-semibold text-[15px] tracking-tight leading-none">
            <TrendingUp size={14} />
            {estimatedSummary?.subsidies.total.toLocaleString('fr-FR') ?? '—'} €
          </div>
        </button>

        <button
          onClick={openParcelGroups}
          disabled={!game.source}
          className="text-left hover:bg-[var(--color-bg)] px-2 py-1 rounded-[8px] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] leading-none mb-1">Hectares</div>
          <div className="flex items-center gap-1.5 text-[var(--color-ink)] font-semibold text-[15px] tracking-tight leading-none">
            <MapIcon size={14} />
            {totalOwnedHectaresNet.toFixed(2)} ha
          </div>
          {estiveSurfaceHa > 0 && (
            <div className="text-[10px] text-[var(--color-ink-30)] mt-0.5">
              Estives : {estiveSurfaceHa.toFixed(2)} ha
            </div>
          )}
        </button>

        <button
          onClick={() => setIsMaecAdvisorOpen(true)}
          className="text-left hover:bg-[var(--color-bg)] px-2 py-1 rounded-[8px] transition-colors"
        >
          <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] leading-none mb-1">MAEC</div>
          <div className="flex items-center gap-1.5 text-blue-600 font-semibold text-[13px] leading-none">
            <Leaf size={13} />
            Conseiller
          </div>
        </button>

        <div className="text-left px-2 py-1">
          <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] leading-none mb-1">Campagne</div>
          <div className="flex items-center gap-1.5 text-[var(--color-ink)] font-semibold text-[13px] leading-none">
            <Calendar size={13} />
            {Object.keys(allYears).length <= 1 ? (
              <span>{game.source?.campaign ?? game.year}</span>
            ) : (
              <select
                value={game.source?.campaign ?? String(game.year)}
                onChange={(e) => { if (e.target.value) switchToYear(e.target.value); }}
                className="bg-transparent border-none outline-none cursor-pointer hover:text-[var(--color-green)] transition-colors font-semibold text-[13px]"
              >
                {Object.keys(allYears).sort().map(k => (
                  <option key={k} value={k}>{k}</option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* ── Right actions ── */}
      <div className="flex items-center gap-1.5">
        {Object.keys(allYears).length > 1 && (
          <button
            onClick={() => setIsStatsOpen(true)}
            title="Statistiques multi-années"
            className="w-8 h-8 rounded-[8px] flex items-center justify-center text-[var(--color-ink-30)] hover:bg-[var(--color-bg)] hover:text-[var(--color-ink)] border border-[var(--color-border)] transition-colors"
          >
            <BarChart2 size={15} />
          </button>
        )}
        {[
          { icon: Trees, title: 'Gestion des SNA', onClick: () => setIsSnaManagerOpen(true), color: 'text-[var(--color-green)]' },
          { icon: Landmark, title: 'Comparateur de scénarios', onClick: () => setIsScenarioOpen(true), color: 'text-indigo-500' },
          { icon: Database, title: 'Référentiel PAC', onClick: () => setIsAdminOpen(true), color: 'text-amber-500' },
          { icon: Settings, title: 'Paramètres', onClick: () => setIsSettingsOpen(true), color: 'text-[var(--color-ink-30)]' },
        ].map(({ icon: Icon, title, onClick, color }) => (
          <button
            key={title}
            onClick={onClick}
            title={title}
            className={cn(
              'w-8 h-8 rounded-[8px] flex items-center justify-center border border-[var(--color-border)] hover:bg-[var(--color-bg)] transition-colors',
              color
            )}
          >
            <Icon size={15} />
          </button>
        ))}

        <div className="w-px h-6 bg-[var(--color-border)] mx-1.5" />

        <button
          onClick={handleNextTurn}
          disabled={isCalculating}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-[9px] text-[13px] font-semibold transition-all',
            'bg-[var(--color-green)] text-white hover:brightness-110 active:scale-[.98]',
            isCalculating && 'opacity-60 cursor-not-allowed'
          )}
        >
          {isCalculating ? 'Calcul…' : 'Analyser'}
          {!isCalculating && <ArrowRight size={14} />}
        </button>
      </div>
    </header>
  );
}
