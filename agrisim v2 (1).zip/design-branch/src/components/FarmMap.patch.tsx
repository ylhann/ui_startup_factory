/**
 * PATCH: FarmMap.tsx — commune group visuals
 *
 * Replace the TWO existing blocks inside the <svg> element:
 *   1. "Pass 1 — commune block rectangles only"
 *   2. "Pass 3 — commune labels on top of everything"
 *
 * Everything else (SVG setup, tiles, HexTile, toolbar, legend, zoom controls)
 * remains unchanged.
 */

// ─── REPLACE "Pass 1 — commune block rectangles only" WITH: ───────────────────

{/* Pass 1 — commune block backgrounds + borders */}
{communeGroups.map(group => {
  const isSelected = selectedCommuneKey === group.key;
  const regionId = group.tiles[0]?.regionId ?? 'plaine';
  const borderStyle = COMMUNE_BORDER_STYLES[regionId] ?? COMMUNE_BORDER_STYLES.plaine;
  return (
    <g key={group.key}>
      {/* Main zone fill */}
      <rect
        x={group.x}
        y={group.y}
        width={group.width}
        height={group.height}
        rx={16}
        ry={16}
        fill={isSelected ? borderStyle.color : 'white'}
        fillOpacity={isSelected ? 0.1 : 0.04}
        stroke={isSelected ? borderStyle.color : borderStyle.color}
        strokeWidth={isSelected ? 2.5 : borderStyle.width}
        strokeDasharray={isSelected ? undefined : borderStyle.dashArray}
        className={cn(
          interactionMode === 'move' ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer',
        )}
        onMouseDown={(event) => {
          if (interactionMode === 'move') {
            onStartCommuneDragByKey(group.key, event);
          }
        }}
        onClick={(event) => {
          event.stopPropagation();
          onSelectCommune(group.key);
        }}
      />
      {/* Move handle — only when in move mode */}
      {interactionMode === 'move' && (
        <g
          transform={`translate(${group.x + group.width - HEX_SIZE * 0.15}, ${group.y + HEX_SIZE * 0.15})`}
          onMouseDown={(event) => onStartCommuneDragByKey(group.key, event)}
          className="cursor-grab active:cursor-grabbing"
        >
          <rect x={-16} y={-11} width={32} height={22} rx={11}
            fill="white" fillOpacity={0.92}
            stroke={borderStyle.color} strokeWidth={1}
          />
          <Move x={-7} y={-7} size={14} color={isSelected ? borderStyle.color : '#94a3b8'} />
        </g>
      )}
    </g>
  );
})}


// ─── REPLACE "Pass 3 — commune labels on top of everything" WITH: ─────────────

{/* Pass 3 — commune labels: pill badge above each group */}
{communeGroups.map(group => {
  const isSelected = selectedCommuneKey === group.key;
  const regionId = group.tiles[0]?.regionId ?? 'plaine';
  const borderStyle = COMMUNE_BORDER_STYLES[regionId] ?? COMMUNE_BORDER_STYLES.plaine;
  const labelX = group.x + group.width / 2;
  const labelY = group.y - HEX_SIZE * 0.5;
  // Estimate pill width from label length (~6.5px/char + 24px padding)
  const pillW = Math.max(80, group.label.length * 6.5 + 24);
  const pillH = 20;

  return (
    <g key={`lbl-${group.key}`} className="pointer-events-none">
      {/* Pill background */}
      <rect
        x={labelX - pillW / 2}
        y={labelY - pillH / 2}
        width={pillW}
        height={pillH}
        rx={pillH / 2}
        fill={isSelected ? borderStyle.color : 'white'}
        fillOpacity={isSelected ? 1 : 0.95}
        stroke={borderStyle.color}
        strokeWidth={1.5}
      />
      {/* Label text */}
      <text
        x={labelX}
        y={labelY + 4}
        textAnchor="middle"
        fontFamily="'DM Sans', sans-serif"
        fontSize={10}
        fontWeight={600}
        letterSpacing={0.3}
        fill={isSelected ? 'white' : borderStyle.color}
      >
        {group.label}
      </text>
      {/* Region badge (non-plaine only) */}
      {regionId !== 'plaine' && (
        <text
          x={labelX}
          y={group.y + group.height + HEX_SIZE * 0.5}
          textAnchor="middle"
          fontFamily="'DM Sans', sans-serif"
          fontSize={8}
          fontWeight={600}
          fill={borderStyle.color}
          opacity={0.8}
        >
          {borderStyle.label}
        </text>
      )}
    </g>
  );
})}
