import { Info, Plus, Wheat } from 'lucide-react';
import type { Crop } from '../types';

interface CulturesPanelProps {
  ownedCrops: Crop[];
  cropStats: Map<string, { area: number; count: number }>;
  getCropTip: (cropId: string) => string;
  onAddClick: () => void;
}

export function CulturesPanel({
  ownedCrops,
  cropStats,
  getCropTip,
  onAddClick,
}: CulturesPanelProps) {
  const totalSurfaceHa = Array.from(cropStats.values()).reduce((sum, stat) => sum + stat.area, 0);

  return (
    <div className="bg-[var(--color-card)] rounded-[var(--radius-lg)] border border-[var(--color-border)] p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[7px] bg-[#fdf7e8] flex items-center justify-center text-[var(--color-amber)]">
            <Wheat size={15} />
          </div>
          <div>
            <div className="font-semibold text-[14px] tracking-tight leading-tight">Cultures</div>
            <div className="text-[11px] text-[var(--color-ink-30)]">
              {ownedCrops.length} cultures · {totalSurfaceHa.toFixed(1)} ha
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={onAddClick}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-[var(--color-amber)] text-white text-[12px] font-semibold hover:brightness-110 transition-all"
        >
          <Plus size={12} /> Ajouter
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: 'Cultures', value: ownedCrops.length, mono: false },
          { label: 'Surface', value: `${totalSurfaceHa.toFixed(1)} ha`, mono: true },
        ].map(s => (
          <div key={s.label} className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-[9px] px-3 py-2">
            <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] mb-0.5">{s.label}</div>
            <div className={`font-semibold text-[18px] tracking-tight ${s.mono ? 'font-mono' : ''}`}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Crop list */}
      <div className="flex flex-col gap-2 overflow-y-auto custom-scrollbar max-h-72 pr-0.5">
        {ownedCrops.length === 0 && (
          <div className="rounded-[10px] border border-dashed border-[var(--color-border)] p-4 text-[13px] text-[var(--color-ink-30)] text-center">
            Aucune culture déclarée.
          </div>
        )}

        {ownedCrops.map(crop => {
          const stat = cropStats.get(crop.id) || { area: 0, count: 0 };
          return (
            <div key={crop.id} className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-[10px] px-3 py-2.5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[13px] font-medium">{crop.label}</span>
                <span className="text-[11px] text-[var(--color-ink-30)] bg-[var(--color-card)] border border-[var(--color-border)] rounded-[5px] px-1.5 py-0.5 font-mono">
                  {stat.count} parc.
                </span>
              </div>

              <div className="grid grid-cols-3 gap-1.5 mb-2">
                {[
                  { label: 'Ha', value: stat.area.toFixed(1), color: 'text-[var(--color-ink)]' },
                  { label: 'Prime', value: `+${crop.revenuePerHa.toLocaleString()}€/ha`, color: 'text-[var(--color-green)]' },
                  { label: 'Coût', value: `-${crop.costPerHa.toLocaleString()}€/ha`, color: 'text-red-500' },
                ].map(m => (
                  <div key={m.label} className="bg-[var(--color-card)] border border-[var(--color-border)] rounded-[7px] px-2 py-1.5 text-center">
                    <div className="text-[9px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.06em] mb-0.5">{m.label}</div>
                    <div className={`text-[11px] font-semibold font-mono ${m.color}`}>{m.value}</div>
                  </div>
                ))}
              </div>

              <div className="flex items-start gap-1.5 text-[11px] text-[var(--color-ink-60)]">
                <Info size={10} className="shrink-0 mt-0.5 text-[var(--color-ink-30)]" />
                <span className="leading-tight">{getCropTip(crop.id)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
