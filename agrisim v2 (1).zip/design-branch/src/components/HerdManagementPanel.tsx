import { useMemo, type Dispatch, type SetStateAction } from 'react';
import { Beef, Minus, Plus } from 'lucide-react';
import { ANIMALS } from '../gameLogic';
import type { GameState } from '../types';
import { cn } from '../lib/utils';
import { HERD_SUBCATEGORIES } from './HerdDetailModal';

interface HerdManagementPanelProps {
  game: GameState;
  ownedAnimals: typeof ANIMALS;
  availableAnimalsToAdd: typeof ANIMALS;
  setGame: Dispatch<SetStateAction<GameState | null>>;
  setAddAnimalId: (value: string) => void;
  setIsAddAnimalOpen: (value: boolean) => void;
  openHerdDetail: (animalId: string) => void;
  updateHerd: (animalId: string, delta: number) => void;
}

export function HerdManagementPanel({
  game,
  ownedAnimals,
  availableAnimalsToAdd,
  setGame,
  setAddAnimalId,
  setIsAddAnimalOpen,
  openHerdDetail,
  updateHerd,
}: HerdManagementPanelProps) {
  const totalUgb = useMemo(
    () => ANIMALS.reduce((acc, animal) => acc + (game.herd?.[animal.id] || 0) * animal.ugb, 0),
    [game.herd]
  );

  const totalHeads = useMemo(
    () => Object.values(game.herd || {}).reduce((acc, value) => acc + value, 0),
    [game.herd]
  );

  return (
    <div className="bg-[var(--color-card)] rounded-[var(--radius-lg)] border border-[var(--color-border)] p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-[7px] bg-[#f5f0ec] flex items-center justify-center text-[#7c5a3c]">
            <Beef size={15} />
          </div>
          <div>
            <div className="font-semibold text-[14px] tracking-tight leading-tight">Cheptel</div>
            <div className="text-[11px] text-[var(--color-ink-30)]">
              {totalHeads} têtes · {totalUgb.toFixed(1)} UGB
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            if (availableAnimalsToAdd.length > 0) setAddAnimalId(availableAnimalsToAdd[0].id);
            setIsAddAnimalOpen(true);
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-[var(--color-green)] text-white text-[12px] font-semibold hover:brightness-110 transition-all"
        >
          <Plus size={12} /> Ajouter
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-2">
        {[
          { label: 'UGB', value: totalUgb.toFixed(1) },
          { label: 'Têtes', value: totalHeads },
        ].map(s => (
          <div key={s.label} className="bg-[var(--color-bg)] border border-[var(--color-border)] rounded-[9px] px-3 py-2">
            <div className="text-[10px] text-[var(--color-ink-30)] font-semibold uppercase tracking-[.07em] mb-0.5">{s.label}</div>
            <div className="font-semibold text-[18px] tracking-tight font-mono">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Animal list */}
      <div className="flex flex-col gap-2 overflow-y-auto custom-scrollbar max-h-72 pr-0.5">
        {ownedAnimals.length === 0 && (
          <div className="rounded-[10px] border border-dashed border-[var(--color-border)] p-4 text-[13px] text-[var(--color-ink-30)] text-center">
            Aucun animal déclaré.
          </div>
        )}

        {ownedAnimals.map(animal => {
          const count = game.herd?.[animal.id] || 0;
          const hasSubs = !!HERD_SUBCATEGORIES[animal.id];
          return (
            <div
              key={animal.id}
              className="flex items-center gap-3 px-3 py-2.5 bg-[var(--color-bg)] border border-[var(--color-border)] rounded-[10px]"
            >
              <div
                className={cn('flex-1 min-w-0', hasSubs && 'cursor-pointer')}
                onClick={hasSubs ? () => openHerdDetail(animal.id) : undefined}
                role={hasSubs ? 'button' : undefined}
                tabIndex={hasSubs ? 0 : undefined}
                onKeyDown={hasSubs ? (e) => (e.key === 'Enter' || e.key === ' ') && openHerdDetail(animal.id) : undefined}
              >
                <div className="text-[13px] font-medium truncate">{animal.label}</div>
                <div className="text-[11px] text-[var(--color-ink-30)] font-mono">
                  {count} · {(count * animal.ugb).toFixed(1)} UGB
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => updateHerd(animal.id, -1)}
                  title={`Diminuer ${animal.label}`}
                  className="w-6 h-6 rounded-[6px] bg-[var(--color-card)] border border-[var(--color-border)] flex items-center justify-center text-[var(--color-ink-60)] hover:bg-white hover:border-[#c8c8c0] transition-colors"
                >
                  <Minus size={11} />
                </button>
                <button
                  onClick={() => updateHerd(animal.id, 1)}
                  title={`Augmenter ${animal.label}`}
                  className="w-6 h-6 rounded-[6px] bg-[var(--color-card)] border border-[var(--color-border)] flex items-center justify-center text-[var(--color-ink-60)] hover:bg-white hover:border-[#c8c8c0] transition-colors"
                >
                  <Plus size={11} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Agneaux vendus (sheep only) */}
      {ownedAnimals.some(a => a.id === 'sheep') && (
        <div className="pt-2 border-t border-[var(--color-border)]">
          <div className="flex items-center justify-between gap-3">
            <label className="text-[12px] font-medium text-[var(--color-ink-60)]">Agneaux vendus (N−1)</label>
            <input
              type="number"
              min={0}
              value={game.lambsSold || ''}
              onChange={(e) => {
                const value = e.target.value === '' ? 0 : Math.max(0, parseInt(e.target.value) || 0);
                setGame(prev => prev ? { ...prev, lambsSold: value } : prev);
              }}
              placeholder="0"
              className="w-20 px-2 py-1.5 rounded-[8px] border border-[var(--color-border)] text-[12px] font-semibold text-center bg-white focus:ring-2 focus:ring-[var(--color-green)] outline-none font-mono"
            />
          </div>
          {(game.herd?.sheep ?? 0) > 0 && (
            <div className="text-[11px] text-[var(--color-ink-30)] text-right mt-1 font-mono">
              Ratio : {((game.lambsSold || 0) / (game.herd?.sheep ?? 1)).toFixed(2)} (min 0,5)
            </div>
          )}
        </div>
      )}
    </div>
  );
}
