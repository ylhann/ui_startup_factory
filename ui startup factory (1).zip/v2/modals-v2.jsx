// ─── V2 Modals ────────────────────────────────────────────────────────────────

const { useState: useMSt, useEffect: useMEf } = React;

async function callAI(system, prompt) {
  if (window.claude) {
    try { return await window.claude.complete({ messages:[{ role:"user", content:`SYSTEM: ${system}\n\nUSER: ${prompt}` }] }); }
    catch(e) {}
  }
  // Demo fallback
  if (system.includes("coffee")) return `[Alex AI]: Int8 quantization keeps dropping accuracy past the threshold. Six hours in.\n[Casey Cloud]: Same thing hit us on the sensor pipeline. We added a calibration step pre-export — fixed it cold.\n[Alex AI]: Smart. A per-layer scale factor post-quant could do the same.\n[Casey Cloud]: Exactly. Now it's in our CI. Zero regressions since.\n[Alex AI]: I'll get Sam to redesign the calibration UI — needs to work for non-ML folks.\n[Casey Cloud]: Good call. Docs are half the battle anyway.\n==KNOWLEDGE==\nA calibration step before quantization export eliminates most accuracy degradation in production AI pipelines.`;
  if (system.includes("Director")) return `## Core Idea Soundness\n\nSolid technical differentiation. Decentralized approach is timely but adds serious coordination overhead.\n\n## Execution Risks\n\n- **Team gap**: Missing GTM leadership entirely\n- **Timeline**: Seed runway with 4 open milestones is aggressive\n- **Regulatory**: Decentralized AI faces evolving EU and US compliance pressures\n\n## Actionable Improvements\n\n- Hire a Head of Partnerships within 30 days\n- Compress milestones 3 and 4 into a phased launch\n- Start regulatory mapping in EU and US markets now`;
  return "Demo mode — connect your API key for live AI responses.";
}

// ── Coffee Meeting Modal ───────────────────────────────────────────────────────
function CoffeeMeetingModal({ agents, startups, onClose }) {
  const [lines,     setLines]     = useMSt([]);
  const [knowledge, setKnowledge] = useMSt("");
  const [loading,   setLoading]   = useMSt(true);
  const [tick,      setTick]      = useMSt(0);

  useMEf(() => {
    const iv = setInterval(() => setTick(t => (t+1)%4), 400);
    return () => clearInterval(iv);
  }, []);

  useMEf(() => {
    (async () => {
      const names  = agents.map(a=>`${a.name} (${a.expertise}, ${startups.find(s=>s.id===a.startupId)?.name})`).join(" and ");
      const skills = agents.map(a=>`${a.name}: ${a.skills.map(s=>`${s.name} Lv${s.level}`).join(", ")}`).join(" | ");
      const tasks  = agents.map(a=>`${a.name}: ${a.tasks.find(t=>t.status==="doing")?.label||"idle"}`).join(" | ");
      const txt = await callAI(
        "You simulate a realistic, casual coffee break conversation between AI agents. Technical, grounded, human.",
        `Coffee break: ${names}. Skills: ${skills}. Work: ${tasks}. Write 6-8 exchanges as [Name]: message. End with ==KNOWLEDGE== and a one-sentence insight.`
      );
      const parts = txt.split("==KNOWLEDGE==");
      setLines((parts[0]||txt).trim().split("\n").filter(l=>l.trim()));
      setKnowledge((parts[1]||"").trim());
      setLoading(false);
    })();
  }, []);

  const dots = ".".repeat(tick+1);

  return (
    <SysModal onClose={onClose} width={620}>
      <SysModalHeader title="☕  COFFEE_MEETING.exe" subtitle={`PARTICIPANTS :: ${agents.map(a=>a.name).join(" × ")}`} onClose={onClose} />
      <div style={{ padding:"20px 22px", display:"flex", flexDirection:"column", gap:16 }}>
        {/* Agents */}
        <div style={{ display:"flex", gap:16, justifyContent:"center" }}>
          {agents.map(a => {
            const s = startups.find(x=>x.id===a.startupId);
            return (
              <div key={a.id} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:6 }}>
                <XpRing totalXp={a.totalXp||0} size={52}>
                  <div style={{ fontSize:22 }}>{a.avatar}</div>
                </XpRing>
                <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#2a5a2a", textAlign:"center" }}>{a.name}</div>
                <SysTag label={s?.name||"—"} dim />
              </div>
            );
          })}
          <div style={{ display:"flex", alignItems:"center", justifyContent:"center", padding:"0 8px" }}>
            <div style={{ width:40, height:1, background:"linear-gradient(90deg, #0d2a0d, #00ff8844, #0d2a0d)" }} />
          </div>
        </div>

        {/* Transcript */}
        <div style={{ background:"#030603", border:"1px solid #0d1a0d", borderRadius:6,
          padding:16, maxHeight:260, overflowY:"auto", position:"relative" }}>
          {loading ? (
            <div style={{ textAlign:"center", fontFamily:"'JetBrains Mono', monospace",
              color:"#1a4a1a", fontSize:11, padding:24 }}>
              CONNECTING_AGENTS{dots}
            </div>
          ) : lines.map((line, i) => {
            const m = line.match(/^\[([^\]]+)\]:\s*(.*)/);
            if (!m) return null;
            const [, speaker, msg] = m;
            const agent = agents.find(a=>a.name.includes(speaker)||speaker.includes(a.name.split(" ")[0]));
            return (
              <div key={i} style={{ display:"flex", gap:10, marginBottom:14, alignItems:"flex-start",
                animation:"fadeSlideIn 0.3s ease both", animationDelay:`${i*0.06}s` }}>
                <div style={{ width:30, height:30, background:"#060a06", borderRadius:4, flexShrink:0,
                  display:"flex", alignItems:"center", justifyContent:"center", fontSize:14,
                  border:`1px solid ${LEVEL_COLORS[getLevel(agent?.totalXp||0)]}33` }}>
                  {agent?.avatar||"?"}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#00ff88",
                    marginBottom:3, letterSpacing:"0.06em" }}>{speaker.toUpperCase()}</div>
                  <div style={{ fontSize:12, color:"#2a4a2a", lineHeight:1.7 }}>{msg}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Knowledge */}
        {knowledge && (
          <div style={{ background:"rgba(0,255,136,0.03)", border:"1px solid rgba(0,255,136,0.15)",
            borderRadius:6, padding:"12px 16px", display:"flex", gap:10, alignItems:"flex-start" }}>
            <span style={{ fontSize:14, flexShrink:0 }}>◈</span>
            <div>
              <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#00ff88",
                letterSpacing:"0.08em", textTransform:"uppercase", marginBottom:5 }}>KNOWLEDGE_CAPTURED</div>
              <div style={{ fontSize:12, color:"#2a6a2a", lineHeight:1.7 }}>{knowledge}</div>
            </div>
          </div>
        )}

        {!loading && (
          <div style={{ display:"flex", gap:8, justifyContent:"center" }}>
            {agents.map(a => (
              <div key={a.id} style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9,
                color:"#00ff88", background:"rgba(0,255,136,0.06)", border:"1px solid rgba(0,255,136,0.2)",
                borderRadius:3, padding:"3px 10px" }}>+30XP +15ST → {a.name.split(" ")[0].toUpperCase()}</div>
            ))}
          </div>
        )}

        <div style={{ display:"flex", justifyContent:"flex-end" }}>
          <SysBtn label="CLOSE" onClick={onClose} />
        </div>
      </div>
    </SysModal>
  );
}

// ── Pitch Feedback Modal ───────────────────────────────────────────────────────
function PitchFeedbackModal({ startup, onClose }) {
  const [content, setContent] = useMSt("");
  const [loading, setLoading] = useMSt(true);
  const [tick,    setTick]    = useMSt(0);
  useMEf(() => { const iv=setInterval(()=>setTick(t=>(t+1)%4),400); return ()=>clearInterval(iv); },[]);
  useMEf(() => {
    (async () => {
      const txt = await callAI(
        "You are a ruthless but constructive Incubator Director at 'The Pépinière'. Give structured, realistic feedback using markdown ## sections: Core Idea Soundness, Execution Risks, Actionable Improvements. Concise and brutally honest.",
        `Startup: "${startup.name}" | Stage: ${startup.parameters.funding} | Objective: "${startup.objective}" | Stealth: ${startup.parameters.stealth}`
      );
      setContent(txt); setLoading(false);
    })();
  }, []);

  return (
    <SysModal onClose={onClose} width={640}>
      <SysModalHeader title={`EVALUATE :: ${startup.name.toUpperCase()}`} subtitle="SOURCE :: INCUBATOR_DIRECTOR_AI" onClose={onClose} />
      <div style={{ padding:"20px 22px", display:"flex", flexDirection:"column", gap:16 }}>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          <div style={{ fontSize:32 }}>{startup.logo}</div>
          <div>
            <div style={{ fontFamily:"'JetBrains Mono', monospace", color:"#00ff88", fontSize:14, fontWeight:700 }}>{startup.name}</div>
            <div style={{ fontSize:11, color:"#1a3a1a", marginTop:2 }}>{startup.objective}</div>
          </div>
          <div style={{ marginLeft:"auto" }}>
            <SysTag label={startup.parameters.funding} />
            {startup.parameters.stealth && <SysTag label="STEALTH" color="#f59e0b" />}
          </div>
        </div>
        <div style={{ background:"#030603", border:"1px solid #0d1a0d", borderRadius:6,
          padding:18, maxHeight:360, overflowY:"auto", minHeight:120 }}>
          {loading
            ? <div style={{ fontFamily:"'JetBrains Mono', monospace", color:"#1a4a1a", fontSize:11, textAlign:"center", padding:30 }}>DIRECTOR_REVIEWING{".".repeat(tick+1)}</div>
            : <SysMd text={content} />}
        </div>
        <div style={{ display:"flex", justifyContent:"flex-end" }}>
          <SysBtn label="CLOSE" onClick={onClose} />
        </div>
      </div>
    </SysModal>
  );
}

// ── Kanban Modal ───────────────────────────────────────────────────────────────
function KanbanModal({ startup, employees, setEmployees, onClose }) {
  const team = employees.filter(e=>e.startupId===startup.id);
  const cols = [
    { id:"todo",  label:"TODO",        color:"#1a3a1a" },
    { id:"doing", label:"IN_PROGRESS", color:"#00cfff" },
    { id:"done",  label:"DONE",        color:"#00ff88" },
  ];
  const moveTask = (empId, taskId, status) => {
    setEmployees(prev=>prev.map(e=>e.id!==empId?e:{...e,tasks:e.tasks.map(t=>t.id!==taskId?t:{...t,status,progress:status==="todo"?0:status==="done"?100:t.progress})}));
  };

  return (
    <SysModal onClose={onClose} width={1100}>
      <SysModalHeader title={`KANBAN :: ${startup.name.toUpperCase()}`} subtitle={`AGENTS_ACTIVE :: ${team.length} | STAGE :: ${startup.parameters.funding.toUpperCase()}`} onClose={onClose} />
      <div style={{ padding:"20px 22px", display:"flex", flexDirection:"column", gap:16, maxHeight:"80vh", overflowY:"auto" }}>

        {/* Milestone timeline */}
        {startup.milestones?.length>0 && (
          <div style={{ background:"#030603", border:"1px solid #0d1a0d", borderRadius:6, padding:18 }}>
            <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#1a4a1a",
              textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:16 }}>MILESTONE_TIMELINE</div>
            <div style={{ display:"flex", alignItems:"flex-start" }}>
              {startup.milestones.map((m,i) => {
                const done=m.status==="completed", active=m.status==="in-progress", last=i===startup.milestones.length-1;
                return (
                  <div key={m.id} style={{ display:"flex", flex:last?"none":1, position:"relative" }}>
                    {!last && <div style={{ position:"absolute", top:9, left:18, right:-6, height:1,
                      background: done ? "rgba(0,255,136,0.4)" : "#0d1a0d", zIndex:1 }} />}
                    <div style={{ position:"relative", zIndex:2, display:"flex", flexDirection:"column", gap:8, width:130 }}>
                      <div style={{ width:18, height:18, borderRadius:2,
                        background: done?"rgba(0,255,136,0.15)":active?"rgba(0,207,255,0.08)":"#060a06",
                        border:`1px solid ${done?"#00ff88":active?"#00cfff":"#0d1a0d"}`,
                        display:"flex", alignItems:"center", justifyContent:"center", fontSize:9,
                        color:done?"#00ff88":active?"#00cfff":"#1a3a1a",
                        boxShadow:active?"0 0 8px rgba(0,207,255,0.3)":"none" }}>
                        {done?"◉":active?"◈":"○"}
                      </div>
                      <div style={{ paddingRight:10 }}>
                        <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9,
                          color:done?"#00ff88":active?"#00cfff":"#1a3a1a", lineHeight:1.5 }}>{m.label}</div>
                        <div style={{ fontSize:8, color:"#0d2a0d", marginTop:2, textTransform:"uppercase", letterSpacing:"0.04em" }}>{m.status.replace("-"," ")}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Kanban board */}
        <div style={{ display:"flex", gap:12 }}>
          {cols.map(col => {
            const colTasks = team.flatMap(e=>e.tasks.filter(t=>t.status===col.id).map(t=>({...t,empId:e.id,empName:e.name,empAvatar:e.avatar})));
            return (
              <div key={col.id}
                onDragOver={e=>e.preventDefault()}
                onDrop={e=>{ e.preventDefault(); try{ const d=JSON.parse(e.dataTransfer.getData("text/plain")); moveTask(d.empId,d.taskId,col.id); }catch(err){} }}
                style={{ flex:1, background:"#030603", border:`1px solid ${col.id==="todo"?"#0d1a0d":col.id==="doing"?"rgba(0,207,255,0.15)":"rgba(0,255,136,0.15)"}`,
                  borderRadius:6, padding:14, minHeight:220, display:"flex", flexDirection:"column" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
                  marginBottom:12, paddingBottom:10, borderBottom:"1px solid #0d1a0d" }}>
                  <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:col.color,
                    letterSpacing:"0.08em" }}>{col.label}</div>
                  <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#0d2a0d",
                    background:"#060a06", border:"1px solid #0d1a0d", borderRadius:2, padding:"1px 6px" }}>{colTasks.length}</div>
                </div>
                <div style={{ flex:1, display:"flex", flexDirection:"column", gap:8 }}>
                  {colTasks.map(task => {
                    const blocked=task.status!=="done"&&task.dependencies?.some(d=>{
                      const owner=team.find(e=>e.tasks.some(t=>t.id===d));
                      return owner?.tasks.find(t=>t.id===d)?.status!=="done";
                    });
                    return (
                      <div key={task.id} draggable
                        onDragStart={e=>e.dataTransfer.setData("text/plain",JSON.stringify({empId:task.empId,taskId:task.id}))}
                        style={{ background:"#060a06", border:`1px solid ${blocked?"#0a100a":"#0d1a0d"}`,
                          borderRadius:4, padding:10, cursor:"grab", opacity:blocked?0.5:1,
                          transition:"border-color 0.2s" }}>
                        <div style={{ fontSize:11, color:blocked?"#0d1a0d":"#2a4a2a", lineHeight:1.5,
                          textDecoration:blocked?"line-through":"none", marginBottom:8 }}>{task.label}</div>
                        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                          <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                            <span style={{ fontSize:12 }}>{task.empAvatar}</span>
                            <span style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#0d2a0d" }}>{task.empName.split(" ")[0].toUpperCase()}</span>
                          </div>
                          {blocked && <SysTag label="BLOCKED" color="#f59e0b" />}
                        </div>
                        {task.status==="doing"&&task.progress>0 && (
                          <div style={{ marginTop:8, height:1, background:"#0d1a0d", overflow:"hidden" }}>
                            <div style={{ height:"100%", background:"#00cfff", width:`${task.progress}%`, boxShadow:"0 0 6px #00cfff" }} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {colTasks.length===0 && (
                    <div style={{ textAlign:"center", fontFamily:"'JetBrains Mono', monospace",
                      fontSize:9, color:"#0a150a", padding:"20px 0", letterSpacing:"0.06em" }}>DROP_HERE</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ display:"flex", justifyContent:"flex-end" }}>
          <SysBtn label="CLOSE" onClick={onClose} />
        </div>
      </div>
    </SysModal>
  );
}

// ── Add Startup Modal ──────────────────────────────────────────────────────────
function AddStartupModal({ onAdd, onClose }) {
  const [name,      setName]      = useMSt("");
  const [objective, setObjective] = useMSt("");
  const [repo,      setRepo]      = useMSt("");
  return (
    <SysModal onClose={onClose} width={440}>
      <SysModalHeader title="REGISTER_STARTUP.exe" subtitle="CREATE :: NEW_VENTURE_ENTRY" onClose={onClose} />
      <div style={{ padding:"20px 22px", display:"flex", flexDirection:"column", gap:14 }}>
        <SysInput label="Startup Name *" value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Nexus.io" />
        <SysInput label="Core Objective" value={objective} onChange={e=>setObjective(e.target.value)} placeholder="Primary simulation goal…" area />
        <SysInput label="Cloud Repository (optional)" value={repo} onChange={e=>setRepo(e.target.value)} placeholder="github.com/user/repo" />
        <div style={{ display:"flex", gap:8, marginTop:4 }}>
          <SysBtn label="ABORT" onClick={onClose} />
          <div style={{ flex:1 }} />
          <SysBtn label="CONFIRM_ENTRY" onClick={()=>{ onAdd(name,objective,repo); onClose(); }} accent disabled={!name.trim()} />
        </div>
      </div>
    </SysModal>
  );
}

// ── Add Employee Modal ─────────────────────────────────────────────────────────
function AddEmployeeModal({ startups, onAdd, onClose }) {
  const [name,      setName]      = useMSt("");
  const [expertise, setExpertise] = useMSt("Frontend");
  const [startupId, setStartupId] = useMSt(startups[0]?.id||"");
  const [skill1,    setSkill1]    = useMSt("React");
  const [skill2,    setSkill2]    = useMSt("TypeScript");
  const avatar = AVATAR_POOL[Math.floor(Math.random()*AVATAR_POOL.length)];

  const handleSubmit = () => {
    if (!name.trim()) return;
    onAdd({ id:`e${Date.now()}`, name:name.trim(), avatar, expertise, startupId,
      currentRoom:"work_area", mood:"happy", energy:100, stress:0, experience:1,
      totalXp:0, skillTokens:100,
      skills:[
        { name:skill1||"Skill A", level:1, xp:0, maxXp:100 },
        { name:skill2||"Skill B", level:1, xp:0, maxXp:100 },
      ],
      tasks:[{ id:`t${Date.now()}`, label:"Initialize workspace", status:"todo", progress:0 }],
      journal:["Just joined the team. Ready to ship."],
    });
    onClose();
  };

  return (
    <SysModal onClose={onClose} width={440}>
      <SysModalHeader title="DEPLOY_AGENT.exe" subtitle="INITIALIZE :: NEW_AGENT_INSTANCE" onClose={onClose} />
      <div style={{ padding:"20px 22px", display:"flex", flexDirection:"column", gap:14 }}>
        <SysInput label="Agent Name *" value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Jordan Dev" />
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
          <SysSelect label="Expertise" value={expertise} onChange={e=>setExpertise(e.target.value)} options={EXPERTISE_OPTS} />
          <SysSelect label="Startup" value={startupId} onChange={e=>setStartupId(e.target.value)} options={startups.map(s=>s.id)} />
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
          <SysInput label="Skill A" value={skill1} onChange={e=>setSkill1(e.target.value)} placeholder="React" />
          <SysInput label="Skill B" value={skill2} onChange={e=>setSkill2(e.target.value)} placeholder="TypeScript" />
        </div>
        {/* Avatar preview */}
        <div style={{ background:"#030603", border:"1px solid #0d1a0d", borderRadius:4,
          padding:"10px 14px", display:"flex", alignItems:"center", gap:12 }}>
          <span style={{ fontSize:26 }}>{avatar}</span>
          <div>
            <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:10, color:"#1a4a1a" }}>AVATAR_ASSIGNED :: RANDOM</div>
            <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#0d2a0d", marginTop:2 }}>LV1 · 100 SKILL_TOKENS</div>
          </div>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          <SysBtn label="ABORT" onClick={onClose} />
          <div style={{ flex:1 }} />
          <SysBtn label="CONFIRM_DEPLOY" onClick={handleSubmit} accent disabled={!name.trim()} />
        </div>
      </div>
    </SysModal>
  );
}

Object.assign(window, { CoffeeMeetingModal, PitchFeedbackModal, KanbanModal, AddStartupModal, AddEmployeeModal });
