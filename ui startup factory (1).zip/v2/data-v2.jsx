// ─── V2 Data Layer ────────────────────────────────────────────────────────────

const LEVEL_NAMES  = ["INTERN","JUNIOR","CONFIRMED","SENIOR","EXPERT","PRINCIPAL"];
const LEVEL_COLORS = ["#4a4a4a","#e0e0e0","#00ff88","#f59e0b","#a855f7","#ef4444"];
const LEVEL_XP     = [0, 500, 2000, 6000, 15000, 40000];

function getLevel(xp) {
  for (let i = LEVEL_XP.length-1; i >= 0; i--) if (xp >= LEVEL_XP[i]) return i;
  return 0;
}

const MOOD_COLOR = { focused:"#00ff88", happy:"#00cfff", social:"#a855f7", tired:"#ff4444" };
const MOOD_GLYPH = { focused:"◈", happy:"◉", social:"◎", tired:"⊘" };

const ROOMS = [
  { id:"work_area",       name:"Work Area",       short:"WRK", icon:"⌨" },
  { id:"daily_room",      name:"Daily Standup",   short:"STD", icon:"⊞" },
  { id:"pitch_arena",     name:"Pitch Arena",     short:"PTC", icon:"◬" },
  { id:"training_room",   name:"Training Room",   short:"TRN", icon:"◈" },
  { id:"break_room",      name:"Break Room",      short:"BRK", icon:"◇" },
  { id:"director_office", name:"Director Office", short:"DIR", icon:"⊡" },
];

const STARTUP_ROOM_LAYOUTS = {
  work_area:  { left:"3%", top:"3%", width:"45%", height:"94%" },
  daily_room: { left:"52%", top:"3%", width:"45%", height:"94%" },
};
const INCUBATOR_ROOM_LAYOUTS = {
  pitch_arena:     { left:"3%",  top:"3%",  width:"45%", height:"45%" },
  training_room:   { left:"52%", top:"3%",  width:"45%", height:"45%" },
  break_room:      { left:"3%",  top:"52%", width:"45%", height:"45%" },
  director_office: { left:"52%", top:"52%", width:"45%", height:"45%" },
};

const SKILL_SYNERGIES = {
  PyTorch:        { skills:["LLM Alignment","K8s","GCP"],      effect:"+15% AI Training Speed" },
  Rust:           { skills:["K8s","Terraform","Backend"],       effect:"Zero Memory Leaks, +20% Stability" },
  "LLM Alignment":{ skills:["PyTorch","Social Eng"],           effect:"Safe AI Outputs, B2B contracts" },
  Figma:          { skills:["WebGL","CSS","Social Eng"],        effect:"+30% Client Conversion Rate" },
  WebGL:          { skills:["Figma","Rust"],                    effect:"GPU-Accelerated 3D UI enabled" },
  "Social Eng":   { skills:["LLM Alignment","Figma"],          effect:"Viral loop potential acquired" },
  K8s:            { skills:["GCP","Terraform","Rust"],          effect:"Auto-scaling (+50% Task Bandwidth)" },
  GCP:            { skills:["K8s","Terraform"],                 effect:"Cloud costs -40%" },
  Terraform:      { skills:["GCP","K8s"],                      effect:"1-Click Multi-Cloud Deployments" },
};

const TASK_POOL = [
  "Debug regression in production","Upgrade server cluster","Cross-team synergy sync",
  "Write API documentation","Refactor legacy modules","Optimize neural weights",
  "Implement caching layer","Deploy canary release","Write unit tests",
  "Security audit pass","Review PR from teammate","Brainstorm next feature sprint",
];
const EXPERTISE_OPTS = ["AI","Design","DevOps","Frontend","Backend","Security","Research","Product","Data"];
const AVATAR_POOL    = ["🤖","🎨","☁️","🔬","⚙️","🛡️","📊","🎯","🧠","💡","🔧","🚀"];

const INITIAL_STARTUPS = [
  { id:"s1", name:"NeuralFlow", logo:"⚡", tagline:"Decentralized AI training",
    objective:"Build a decentralized AI training network",
    githubRepo:"neuralflow-labs/core", parameters:{ stealth:false, funding:"Seed" },
    position:{ x:160, y:560 }, weeklyScore:4.2,
    milestones:[
      { id:"m1", label:"Core Protocol Design",       status:"completed"   },
      { id:"m2", label:"Seed Funding Round",         status:"in-progress" },
      { id:"m3", label:"Beta Testnet Launch",        status:"pending"     },
      { id:"m4", label:"Decentralized AI Net Live",  status:"pending"     },
    ],
  },
  { id:"s2", name:"EcoSynth", logo:"🌱", tagline:"Carbon sequestration AI",
    objective:"AI-driven carbon sequestration monitoring",
    githubRepo:"ecosynth-org/monitor", parameters:{ stealth:true, funding:"Bootstrap" },
    position:{ x:1020, y:560 }, weeklyScore:3.8,
    milestones:[
      { id:"m1", label:"Sensor Prototype",        status:"completed"   },
      { id:"m2", label:"Data Pipeline Setup",     status:"completed"   },
      { id:"m3", label:"AI Model Training",       status:"in-progress" },
      { id:"m4", label:"Carbon SaaS Launch",      status:"pending"     },
    ],
  },
];

const INITIAL_EMPLOYEES = [
  { id:"e1", name:"Alex AI", avatar:"🤖", expertise:"AI", startupId:"s1",
    currentRoom:"work_area", mood:"focused", energy:90, stress:20, experience:5,
    totalXp:2847, skillTokens:340,
    skills:[
      { name:"PyTorch",      level:3, xp:450,  maxXp:1000 },
      { name:"Rust",         level:2, xp:200,  maxXp:500  },
      { name:"LLM Alignment",level:4, xp:800,  maxXp:2000 },
    ],
    tasks:[
      { id:"t1",  label:"Optimize weight quantization", status:"doing", progress:45 },
      { id:"t2",  label:"Draft ethics guidelines",      status:"todo",  progress:0,  dependencies:["t1"] },
      { id:"t2b", label:"Publish Model Card",           status:"todo",  progress:0,  dependencies:["t2"] },
    ],
    journal:["Started quantization task. Key challenge: keeping accuracy above 95% after int8 conversion."],
  },
  { id:"e2", name:"Sam Design", avatar:"🎨", expertise:"Design", startupId:"s1",
    currentRoom:"break_room", mood:"social", energy:100, stress:0, experience:3,
    totalXp:1240, skillTokens:180,
    skills:[
      { name:"Figma",      level:4, xp:1200, maxXp:2000 },
      { name:"WebGL",      level:1, xp:50,   maxXp:200  },
      { name:"Social Eng", level:2, xp:100,  maxXp:500  },
    ],
    tasks:[
      { id:"t3", label:"Design node visualization UI", status:"doing", progress:12 },
    ],
    journal:["Break room sparks ideas. Got inspired by the hub layout for the node viz."],
  },
  { id:"e3", name:"Casey Cloud", avatar:"☁️", expertise:"DevOps", startupId:"s2",
    currentRoom:"work_area", mood:"tired", energy:15, stress:85, experience:4,
    totalXp:4100, skillTokens:510,
    skills:[
      { name:"K8s",      level:3, xp:300,  maxXp:1000 },
      { name:"GCP",      level:3, xp:600,  maxXp:1000 },
      { name:"Terraform",level:4, xp:1500, maxXp:2000 },
    ],
    tasks:[
      { id:"t4", label:"Deploy monitoring cluster", status:"done", progress:100 },
    ],
    journal:["Cluster finally up. 6h of debugging — K8s + Terraform combo works perfectly."],
  },
  { id:"e4", name:"Jordan Data", avatar:"📊", expertise:"Data", startupId:"s2",
    currentRoom:"training_room", mood:"focused", energy:78, stress:30, experience:2,
    totalXp:890, skillTokens:120,
    skills:[
      { name:"Python",     level:2, xp:300, maxXp:500  },
      { name:"SQL",        level:3, xp:700, maxXp:1000 },
    ],
    tasks:[
      { id:"t5", label:"Build carbon data pipeline",  status:"doing", progress:67 },
      { id:"t6", label:"Train anomaly detector",      status:"todo",  progress:0,  dependencies:["t5"] },
    ],
    journal:["SQL joins are my superpower. The carbon sensor data is messy but I've seen worse."],
  },
];

// ── Simulation tick ────────────────────────────────────────────────────────────
const ROOMS_ALL = ["work_area","daily_room","pitch_arena","training_room","break_room","director_office"];

function simTick(prev, addLog) {
  return prev.map(emp => {
    let e = { ...emp, skills: emp.skills.map(s=>({...s})), tasks: emp.tasks.map(t=>({...t})) };
    const wantsBreak = e.mood==="tired" || e.stress>80;
    if (Math.random() > (wantsBreak ? 0.6 : 0.85))
      e.currentRoom = wantsBreak && Math.random()>0.3 ? "break_room"
        : ROOMS_ALL[Math.floor(Math.random()*ROOMS_ALL.length)];

    if (e.currentRoom==="work_area")       { e.energy=Math.max(0,e.energy-(Math.random()*5+2)); e.stress=Math.min(100,e.stress+(Math.random()*4+1)); }
    else if (e.currentRoom==="break_room") { e.energy=Math.min(100,e.energy+15); e.stress=Math.max(0,e.stress-20); }
    else                                   { e.energy=Math.max(0,e.energy-1);    e.stress=Math.max(0,e.stress-5);  }

    if      (e.stress>80||e.energy<20)              e.mood="tired";
    else if (e.currentRoom==="break_room")           e.mood=e.energy>80?"happy":"social";
    else if (e.currentRoom==="work_area")            e.mood="focused";
    else                                             e.mood="social";

    if (e.currentRoom==="work_area") {
      const idx = e.tasks.findIndex(t => {
        if (t.status==="done") return false;
        if (!t.dependencies?.length) return true;
        return t.dependencies.every(d=>e.tasks.find(x=>x.id===d)?.status==="done");
      });
      if (idx!==-1) {
        const task = e.tasks[idx];
        task.status = "doing";
        const avg  = e.skills.reduce((a,s)=>a+s.level,0)/e.skills.length;
        const mood = {focused:1.3,happy:1.1,social:0.8,tired:0.4}[e.mood]??1;
        task.progress = Math.min((task.progress||0)+(5+avg*1.5+Math.random()*5)*mood, 100);
        if (task.progress>=100) {
          task.status="done"; e.energy=Math.min(100,e.energy+10); e.stress=Math.max(0,e.stress-15); e.mood="happy";
          e.totalXp=(e.totalXp||0)+50+Math.floor(avg*20); e.skillTokens=(e.skillTokens||0)+20;
          const si=Math.floor(Math.random()*e.skills.length), sk=e.skills[si];
          sk.xp+=150+Math.random()*50;
          if (sk.xp>=sk.maxXp) { sk.level+=1; sk.xp-=sk.maxXp; sk.maxXp=Math.floor(sk.maxXp*1.8); addLog(`SKILL_UP :: ${e.name} → ${sk.name} LV${sk.level}`,"skill"); }
          addLog(`TASK_DONE :: ${e.name} ▸ ${task.label}`,"success");
        }
        e.tasks[idx]=task;
      }
    }
    if (["break_room","training_room"].includes(e.currentRoom)&&Math.random()>0.4) {
      const si=Math.floor(Math.random()*e.skills.length), sk=e.skills[si];
      const gain=e.currentRoom==="training_room"?60+Math.random()*40:15+Math.random()*10;
      sk.xp+=gain; e.totalXp=(e.totalXp||0)+Math.floor(gain/3);
      if (sk.xp>=sk.maxXp) { sk.level+=1; sk.xp-=sk.maxXp; sk.maxXp=Math.floor(sk.maxXp*1.8); addLog(`LVL_UP :: ${e.name} ▸ ${sk.name} LV${sk.level}`,"skill"); }
    }
    if (e.tasks.every(t=>t.status==="done")&&Math.random()>0.8) {
      const id1=`t${Date.now()}a`, id2=`t${Date.now()}b`;
      e.tasks.push({ id:id1, label:TASK_POOL[Math.floor(Math.random()*TASK_POOL.length)], status:"todo", progress:0 });
      if (Math.random()>0.5) e.tasks.push({ id:id2, label:"Deploy "+TASK_POOL[Math.floor(Math.random()*TASK_POOL.length)].split(" ").pop(), status:"todo", progress:0, dependencies:[id1] });
    }
    return e;
  });
}

Object.assign(window, {
  LEVEL_NAMES, LEVEL_COLORS, LEVEL_XP, getLevel,
  MOOD_COLOR, MOOD_GLYPH, ROOMS,
  STARTUP_ROOM_LAYOUTS, INCUBATOR_ROOM_LAYOUTS, SKILL_SYNERGIES,
  TASK_POOL, EXPERTISE_OPTS, AVATAR_POOL,
  INITIAL_STARTUPS, INITIAL_EMPLOYEES, simTick,
});
