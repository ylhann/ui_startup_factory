// ─── V2 Main App — Tactical OS ────────────────────────────────────────────────

const { useState, useEffect, useRef, useCallback } = React;

// ── Live clock ────────────────────────────────────────────────────────────────
function LiveClock() {
  const [t, setT] = useState(new Date());
  useEffect(() => { const iv = setInterval(()=>setT(new Date()),1000); return ()=>clearInterval(iv); },[]);
  return (
    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:"#1a4a1a", letterSpacing:"0.06em" }}>
      {t.toISOString().replace("T"," ").slice(0,19)}Z
    </span>
  );
}

// ── Log window ────────────────────────────────────────────────────────────────
function LogPanel({ logs, isOpen, setIsOpen }) {
  const endRef = useRef(null);
  useEffect(() => { if (endRef.current && isOpen) endRef.current.scrollTop = endRef.current.scrollHeight; }, [logs, isOpen]);
  const TYPE = {
    success:{ color:"#00ff88", glyph:"◉" },
    skill:  { color:"#a855f7", glyph:"◈" },
    warning:{ color:"#f59e0b", glyph:"⚠" },
    info:   { color:"#1a4a1a", glyph:"·" },
  };
  return (
    <div style={{ position:"fixed", bottom:16, right:16, zIndex:300, width:isOpen?340:"auto",
      display:"flex", flexDirection:"column", alignItems:"flex-end" }}>
      {isOpen && (
        <div style={{ background:"#030603", border:"1px solid #0d2a0d", borderRadius:6, width:"100%",
          marginBottom:8, boxShadow:"0 0 40px rgba(0,0,0,0.8)", overflow:"hidden",
          animation:"sysModalIn 0.15s ease" }}>
          <div style={{ padding:"10px 14px", borderBottom:"1px solid #0d1a0d",
            display:"flex", justifyContent:"space-between", alignItems:"center", background:"#040804" }}>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#00ff88", letterSpacing:"0.08em" }}>SYSTEM_LOGS</div>
            <button onClick={()=>setIsOpen(false)} style={{ background:"transparent",border:"none",cursor:"pointer",color:"#1a3a1a",fontSize:11 }}>✕</button>
          </div>
          <div ref={endRef} style={{ maxHeight:220, overflowY:"auto", padding:10, display:"flex", flexDirection:"column", gap:4 }}>
            {logs.length===0
              ? <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d1a0d", textAlign:"center", padding:16 }}>NO_EVENTS</div>
              : logs.slice(-60).map(log => {
                const ts = TYPE[log.type]||TYPE.info;
                return (
                  <div key={log.id} style={{ display:"flex", gap:8, padding:"5px 8px",
                    background: log.type==="success"?"rgba(0,255,136,0.03)":log.type==="skill"?"rgba(168,85,247,0.03)":"transparent",
                    borderRadius:3, border:"1px solid transparent" }}>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:ts.color, flexShrink:0 }}>{ts.glyph}</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10,
                        color: log.type==="info"?"#2a4a2a":ts.color, lineHeight:1.5 }}>{log.msg}</div>
                      <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:"#0d1a0d", marginTop:1 }}>{log.time}</div>
                    </div>
                  </div>
                );
              })
            }
          </div>
        </div>
      )}
      <button onClick={()=>setIsOpen(o=>!o)}
        style={{ background:"#040804", border:"1px solid #0d2a0d", borderRadius:4, padding:"7px 14px",
          color:"#1a4a1a", fontFamily:"'JetBrains Mono',monospace", fontSize:9, letterSpacing:"0.06em",
          textTransform:"uppercase", cursor:"pointer", display:"flex", alignItems:"center", gap:8,
          boxShadow:"0 4px 20px rgba(0,0,0,0.5)" }}>
        <span style={{ color:"#00ff88" }}>◉</span>
        {isOpen?"CLOSE_LOGS":"ACTIVITY_LOGS"}
        {!isOpen&&logs.length>0 && (
          <span style={{ background:"rgba(0,255,136,0.15)", color:"#00ff88", border:"1px solid rgba(0,255,136,0.3)",
            borderRadius:2, padding:"0 5px", fontSize:8 }}>{logs.length}</span>
        )}
      </button>
    </div>
  );
}

// ── Agent avatar chip (map node) ───────────────────────────────────────────────
function AgentChip({ emp, onClick }) {
  const [hov, setHov] = useState(false);
  const moodCol = MOOD_COLOR[emp.mood]||"#1a4a1a";
  return (
    <div onClick={e=>{ e.stopPropagation(); onClick(); }}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:3, cursor:"pointer",
        position:"relative" }}>
      {/* Speech bubble */}
      {hov && (
        <div style={{ position:"absolute", bottom:"calc(100% + 4px)", left:"50%", transform:"translateX(-50%)",
          background:"#040804", border:"1px solid #0d2a0d", borderRadius:3, padding:"3px 7px",
          whiteSpace:"nowrap", fontSize:8, color:"#2a5a2a", fontFamily:"'JetBrains Mono',monospace",
          boxShadow:"0 4px 12px rgba(0,0,0,0.8)", zIndex:10, pointerEvents:"none" }}>
          {emp.tasks.find(t=>t.status==="doing")?.label?.slice(0,22)||emp.mood.toUpperCase()}
        </div>
      )}
      <XpRing totalXp={emp.totalXp||0} size={36}>
        <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:14, borderRadius:"50%", background:"#040804", position:"relative" }}>
          {emp.avatar}
          <div style={{ position:"absolute", bottom:1, right:1, width:7, height:7, borderRadius:"50%",
            background:moodCol, border:"1.5px solid #040804", boxShadow:`0 0 5px ${moodCol}` }} />
        </div>
      </XpRing>
      <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:6, color:"#1a3a1a",
        textAlign:"center", maxWidth:38, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
        {emp.name.split(" ")[0].toUpperCase()}
      </div>
    </div>
  );
}

// ── Room cell inside a startup/hub node ──────────────────────────────────────
function RoomCell({ roomId, layout, emps, startup, onRoomClick, onAgentClick }) {
  const room = ROOMS.find(r=>r.id===roomId);
  const [hov, setHov] = useState(false);
  return (
    <div onClick={e=>{ e.stopPropagation(); onRoomClick(roomId,room,startup,emps); }}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ position:"absolute", ...layout,
        background: hov ? "rgba(0,255,136,0.11)" : "#0e1a0e",
        border:`1px solid ${hov?"rgba(0,255,136,0.4)":"rgba(0,255,136,0.18)"}`,
        borderRadius:6, overflow:"hidden", cursor:"pointer", transition:"all 0.18s" }}>
      {/* Room label */}
      <div style={{ position:"absolute", top:5, left:7, display:"flex", alignItems:"center", gap:4 }}>
        <span style={{ fontSize:7, color:hov?"#00ff88":"#2a6a2a" }}>{room?.icon||"◇"}</span>
        <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:7, color:hov?"#3a8a3a":"#2a5a2a",
          textTransform:"uppercase", letterSpacing:"0.06em" }}>{room?.short}</span>
        {emps.length>0 && (
          <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:6, color:hov?"#00ff88":"#2a6a2a",
            background:"rgba(0,255,136,0.12)", borderRadius:2, padding:"0 3px" }}>{emps.length}</span>
        )}
      </div>
      {/* Agents */}
      <div style={{ width:"100%", height:"100%", padding:"18px 6px 4px",
        display:"flex", flexWrap:"wrap", gap:6, alignItems:"flex-start",
        overflowY:"auto", boxSizing:"border-box" }}>
        {emps.map(emp => (
          <AgentChip key={emp.id} emp={emp} onClick={()=>onAgentClick(emp)} />
        ))}
      </div>
    </div>
  );
}

// ── Inspector: Agent detail ────────────────────────────────────────────────────
function AgentInspector({ emp, startups, onClose, onRemove }) {
  const [hovSkill,  setHovSkill]  = useState(null);
  const [pingText,  setPingText]  = useState(null);
  const [isPinging, setIsPinging] = useState(false);

  const startup = startups.find(s=>s.id===emp.startupId);
  const level   = getLevel(emp.totalXp||0);
  const moodCol = MOOD_COLOR[emp.mood]||"#1a4a1a";

  const ping = async () => {
    setIsPinging(true); setPingText(null);
    let txt;
    if (window.claude) {
      try { txt = await window.claude.complete({ messages:[{ role:"user", content:
        `You are ${emp.name}, an AI agent (${emp.expertise}) at startup "${startup?.name}". 2-sentence status update. Direct and technical.\nRoom: ${emp.currentRoom} | Mood: ${emp.mood} | Energy: ${Math.floor(emp.energy)}% | Task: ${emp.tasks.find(t=>t.status==="doing")?.label||"idle"}` }]}); }
      catch(e) { txt = null; }
    }
    if (!txt) txt = `Running at ${Math.floor(emp.energy)}% on "${emp.tasks.find(t=>t.status==="doing")?.label||"standby"}". ${emp.mood==="tired"?"Need a break.":"Steady progress."}`;
    setPingText(txt); setIsPinging(false);
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:0, height:"100%" }}>
      {/* Header band */}
      <div style={{ padding:"16px 18px", borderBottom:"1px solid #0d1a0d",
        display:"flex", alignItems:"center", gap:14, flexShrink:0 }}>
        <XpRing totalXp={emp.totalXp||0} size={54}>
          <div style={{ fontSize:22 }}>{emp.avatar}</div>
        </XpRing>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontWeight:700, color:"#00ff88",
            fontSize:14, letterSpacing:"0.04em", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{emp.name.toUpperCase()}</div>
          <div style={{ display:"flex", gap:6, alignItems:"center", marginTop:4, flexWrap:"wrap" }}>
            <SysTag label={LEVEL_NAMES[level]} color={LEVEL_COLORS[level]} />
            <SysTag label={emp.expertise} dim />
            <span style={{ display:"flex", alignItems:"center", gap:4 }}>
              <span style={{ fontSize:10, color:moodCol }}>{MOOD_GLYPH[emp.mood]}</span>
              <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:moodCol }}>{emp.mood.toUpperCase()}</span>
            </span>
          </div>
        </div>
        <button onClick={onClose} style={{ background:"transparent",border:"none",cursor:"pointer",
          color:"#0d2a0d",fontSize:12,fontFamily:"'JetBrains Mono',monospace",flexShrink:0 }}>✕</button>
      </div>

      {/* Scrollable body */}
      <div style={{ flex:1, overflowY:"auto", padding:"14px 18px", display:"flex", flexDirection:"column", gap:14 }}>

        {/* Stats grid */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
          {[["TOTAL_XP",(emp.totalXp||0).toLocaleString(),"#00ff88"],
            ["SKILL_ST",emp.skillTokens||0,"#f59e0b"],
            ["ENERGY",`${Math.round(emp.energy)}%`,"#00cfff"],
            ["STRESS",`${Math.round(emp.stress)}%`,"#ff4444"]].map(([k,v,c])=>(
            <div key={k} style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:"9px 12px" }}>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:16, fontWeight:900, color:c,
                letterSpacing:"-0.02em" }}>{v}</div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:"#0d2a0d",
                textTransform:"uppercase", letterSpacing:"0.08em", marginTop:2 }}>{k}</div>
            </div>
          ))}
        </div>

        {/* Vitals bars */}
        <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
          <StatMeter label="ENERGY" value={emp.energy} color="#00ff88" />
          <StatMeter label="STRESS" value={emp.stress} color="#ff4444" />
        </div>

        {/* Location */}
        <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:"8px 12px",
          display:"flex", gap:10, alignItems:"center" }}>
          <span style={{ fontSize:14, color:"#1a4a1a" }}>{ROOMS.find(r=>r.id===emp.currentRoom)?.icon||"◇"}</span>
          <div>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", textTransform:"uppercase", letterSpacing:"0.06em" }}>LOCATION</div>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:"#2a5a2a", marginTop:1 }}>{ROOMS.find(r=>r.id===emp.currentRoom)?.name||emp.currentRoom}</div>
          </div>
          {startup && (
            <div style={{ marginLeft:"auto" }}>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:"#0d2a0d" }}>VENTURE</div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#1a4a1a", marginTop:1 }}>{startup.name}</div>
            </div>
          )}
        </div>

        {/* Divider */}
        <div style={{ height:1, background:"linear-gradient(90deg,transparent,#0d2a0d,transparent)" }} />

        {/* Skills */}
        <div>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d",
            textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:8 }}>SKILL_MATRIX</div>
          {emp.skills.map(skill => (
            <div key={skill.name} style={{ position:"relative", marginBottom:2 }}
              onMouseEnter={()=>setHovSkill(skill.name)}
              onMouseLeave={()=>setHovSkill(null)}>
              <SkillRow skill={skill} lit={hovSkill===skill.name && !!SKILL_SYNERGIES[hovSkill]?.skills.includes(skill.name)} />
              {hovSkill===skill.name && SKILL_SYNERGIES[skill.name] && (
                <div style={{ position:"absolute", top:"100%", left:0, zIndex:60, width:220,
                  background:"#040804", border:"1px solid rgba(0,207,255,0.25)", borderRadius:4,
                  padding:"10px 12px", boxShadow:"0 8px 32px rgba(0,0,0,0.8)", zIndex:100 }}>
                  <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#00cfff",
                    textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:5 }}>SYNERGY</div>
                  <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#1a4a4a", marginBottom:4 }}>
                    + {SKILL_SYNERGIES[skill.name].skills.join(" · ")}
                  </div>
                  <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#00cfff" }}>
                    ▸ {SKILL_SYNERGIES[skill.name].effect}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Divider */}
        <div style={{ height:1, background:"linear-gradient(90deg,transparent,#0d2a0d,transparent)" }} />

        {/* Tasks */}
        <div>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d",
            textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:10 }}>TASK_FLOW</div>
          <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:12 }}>
            <TaskFlow tasks={emp.tasks} />
          </div>
        </div>

        {/* Journal */}
        {emp.journal?.length > 0 && (
          <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:12 }}>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d",
              textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:6 }}>JOURNAL :: LAST_ENTRY</div>
            <div style={{ fontSize:11, color:"#2a4a2a", lineHeight:1.75, fontStyle:"italic" }}>
              "{emp.journal[emp.journal.length-1]}"
            </div>
          </div>
        )}

        {/* Ping output */}
        {pingText && <PingBubble text={pingText} />}
      </div>

      {/* Actions footer */}
      <div style={{ padding:"12px 18px", borderTop:"1px solid #0d1a0d", display:"flex", gap:8, flexShrink:0 }}>
        <SysBtn label={isPinging?"PINGING…":"PING_AGENT"} onClick={ping} accent disabled={isPinging} size="sm" />
        <div style={{ flex:1 }} />
        <SysBtn label="DECOMMISSION" onClick={()=>{ onRemove(emp.id); onClose(); }} size="sm" />
      </div>
    </div>
  );
}

// ── Inspector: Startup detail ──────────────────────────────────────────────────
function StartupInspector({ startup, employees, onClose, onPitch, onKanban, onAddAgent }) {
  const team = employees.filter(e=>e.startupId===startup.id);
  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%" }}>
      {/* Header */}
      <div style={{ padding:"16px 18px", borderBottom:"1px solid #0d1a0d", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between" }}>
          <div style={{ display:"flex", gap:12, alignItems:"center" }}>
            <div style={{ fontSize:28 }}>{startup.logo}</div>
            <div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontWeight:700, color:"#00ff88",
                fontSize:15, letterSpacing:"0.04em" }}>{startup.name.toUpperCase()}</div>
              <div style={{ fontSize:10, color:"#1a3a1a", marginTop:2, fontFamily:"'JetBrains Mono',monospace" }}>{startup.tagline||startup.objective.slice(0,40)+"…"}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background:"transparent",border:"none",cursor:"pointer",color:"#0d2a0d",fontSize:12,fontFamily:"'JetBrains Mono',monospace" }}>✕</button>
        </div>
        <div style={{ display:"flex", gap:6, marginTop:10, flexWrap:"wrap" }}>
          <SysTag label={startup.parameters.funding} />
          {startup.parameters.stealth && <SysTag label="STEALTH" color="#f59e0b" />}
          {startup.weeklyScore>0 && <SysTag label={`★ ${startup.weeklyScore}`} color="#a855f7" />}
          <SysTag label={`${team.length} AGENTS`} dim />
        </div>
      </div>

      {/* Body */}
      <div style={{ flex:1, overflowY:"auto", padding:"14px 18px", display:"flex", flexDirection:"column", gap:14 }}>

        {/* Objective */}
        <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:12 }}>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:6 }}>CORE_OBJECTIVE</div>
          <div style={{ fontSize:12, color:"#2a4a2a", lineHeight:1.75 }}>{startup.objective}</div>
        </div>

        {/* Milestones */}
        {startup.milestones?.length>0 && (
          <div>
            <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:10 }}>MILESTONE_STATUS</div>
            <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
              {startup.milestones.map(m => {
                const done=m.status==="completed", active=m.status==="in-progress";
                const col=done?"#00ff88":active?"#00cfff":"#0d2a0d";
                return (
                  <div key={m.id} style={{ display:"flex", alignItems:"center", gap:10,
                    background:"#040804", border:`1px solid ${done?"rgba(0,255,136,0.12)":active?"rgba(0,207,255,0.1)":"#0d1a0d"}`,
                    borderRadius:4, padding:"8px 12px" }}>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:col }}>
                      {done?"◉":active?"◈":"○"}
                    </span>
                    <div style={{ flex:1, fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:done?"#2a5a2a":active?"#2a4a5a":"#1a2a1a" }}>{m.label}</div>
                    <SysTag label={m.status.replace("-","_").toUpperCase()} color={col} dim={!done&&!active} />
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Team */}
        <div>
          <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:8 }}>TEAM_ROSTER</div>
          <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
            {team.map(emp => {
              const level=getLevel(emp.totalXp||0), moodC=MOOD_COLOR[emp.mood]||"#1a4a1a";
              return (
                <div key={emp.id}
                  style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4,
                    padding:"8px 12px", display:"flex", alignItems:"center", gap:10,
                    cursor:"pointer", transition:"border-color 0.15s" }}
                  onMouseOver={e=>e.currentTarget.style.borderColor="rgba(0,255,136,0.2)"}
                  onMouseOut={e=>e.currentTarget.style.borderColor="#0d1a0d"}>
                  <div style={{ width:30, height:30, background:"#060a06", borderRadius:3,
                    display:"flex", alignItems:"center", justifyContent:"center", fontSize:14,
                    border:`1px solid ${LEVEL_COLORS[level]}33` }}>{emp.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:"#3a6a3a", fontWeight:700 }}>{emp.name}</div>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", marginTop:1 }}>{emp.expertise} · {LEVEL_NAMES[level]}</div>
                  </div>
                  <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:3 }}>
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#f59e0b" }}>{emp.skillTokens||0} ST</span>
                    <span style={{ fontSize:9, color:moodC }}>{MOOD_GLYPH[emp.mood]} {emp.mood}</span>
                  </div>
                </div>
              );
            })}
            {team.length===0 && <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0a120a", textAlign:"center", padding:16 }}>NO_AGENTS_ASSIGNED</div>}
          </div>
        </div>

        {/* GitHub */}
        {startup.githubRepo && (
          <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4,
            padding:"8px 12px", display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:14, color:"#1a3a1a" }}>⌥</span>
            <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#1a4a1a" }}>{startup.githubRepo}</span>
          </div>
        )}
      </div>

      {/* Footer actions */}
      <div style={{ padding:"12px 18px", borderTop:"1px solid #0d1a0d", display:"flex", gap:6, flexWrap:"wrap", flexShrink:0 }}>
        <SysBtn label="EVALUATE" onClick={onPitch} size="sm" />
        <SysBtn label="KANBAN" onClick={onKanban} size="sm" />
        <div style={{ flex:1 }} />
        <SysBtn label="+ AGENT" onClick={onAddAgent} accent size="sm" />
      </div>
    </div>
  );
}

// ── Inspector: Room detail ─────────────────────────────────────────────────────
function RoomInspector({ roomId, room, emps, startupCtx, onClose, onAgentSelect }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100%" }}>
      <div style={{ padding:"16px 18px", borderBottom:"1px solid #0d1a0d", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <div style={{ width:42, height:42, background:"#040804", border:"1px solid #0d1a0d",
              borderRadius:4, display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:18, color:"#00ff88" }}>{room?.icon||"◇"}</div>
            <div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontWeight:700, color:"#00ff88",
                fontSize:13, letterSpacing:"0.04em" }}>{room?.name?.toUpperCase()||roomId}</div>
              <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", marginTop:2 }}>
                {emps.length} AGENT{emps.length!==1?"S":""} PRESENT
              </div>
            </div>
          </div>
          <button onClick={onClose} style={{ background:"transparent",border:"none",cursor:"pointer",color:"#0d2a0d",fontSize:12 }}>✕</button>
        </div>
        {startupCtx && (
          <div style={{ marginTop:10 }}>
            <SysTag label={startupCtx.logo+" "+startupCtx.name} dim />
          </div>
        )}
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"14px 18px", display:"flex", flexDirection:"column", gap:8 }}>
        {emps.length===0
          ? <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0a120a", textAlign:"center", padding:32 }}>ROOM_EMPTY</div>
          : emps.map(emp => {
            const ct = emp.tasks.find(t=>t.status==="doing");
            const moodC = MOOD_COLOR[emp.mood]||"#1a4a1a";
            return (
              <div key={emp.id} onClick={()=>{ onAgentSelect(emp); onClose(); }}
                style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:4, padding:12,
                  cursor:"pointer", transition:"border-color 0.15s" }}
                onMouseOver={e=>e.currentTarget.style.borderColor="rgba(0,255,136,0.2)"}
                onMouseOut={e=>e.currentTarget.style.borderColor="#0d1a0d"}>
                <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:ct?10:0 }}>
                  <div style={{ width:36, height:36, background:"#060a06", borderRadius:4,
                    display:"flex", alignItems:"center", justifyContent:"center", fontSize:16,
                    border:`1px solid ${LEVEL_COLORS[getLevel(emp.totalXp||0)]}33` }}>{emp.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:11, color:"#3a6a3a", fontWeight:700 }}>{emp.name}</div>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0d2a0d", marginTop:1 }}>{emp.expertise.toUpperCase()}</div>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                    <div style={{ width:6, height:6, borderRadius:"50%", background:moodC, boxShadow:`0 0 5px ${moodC}` }} />
                    <span style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:moodC }}>{emp.mood.toUpperCase()}</span>
                  </div>
                </div>
                {ct && (
                  <div>
                    <div style={{ fontSize:10, color:"#1a3a1a", marginBottom:4, fontFamily:"'JetBrains Mono',monospace" }}>{ct.label}</div>
                    <div style={{ height:1, background:"#0d1a0d", overflow:"hidden" }}>
                      <div style={{ height:"100%", background:"#00cfff", width:`${ct.progress}%`, boxShadow:"0 0 5px #00cfff" }} />
                    </div>
                    <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:8, color:"#00cfff", marginTop:3, textAlign:"right" }}>{Math.round(ct.progress)}%</div>
                  </div>
                )}
              </div>
            );
          })
        }
      </div>
    </div>
  );
}

// ── Empty inspector state ──────────────────────────────────────────────────────
function InspectorEmpty() {
  return (
    <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center",
      justifyContent:"center", gap:14, padding:24, textAlign:"center" }}>
      <div style={{ fontSize:32, opacity:0.2 }}>⊡</div>
      <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:10, color:"#0d2a0d",
        textTransform:"uppercase", letterSpacing:"0.12em" }}>AWAITING_SELECTION</div>
      <div style={{ fontFamily:"'JetBrains Mono',monospace", fontSize:9, color:"#0a120a",
        lineHeight:2, textTransform:"uppercase", letterSpacing:"0.06em" }}>
        CLICK AGENT · ROOM · STARTUP<br/>TO INSPECT
      </div>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────────
function App() {
  const [startups,       setStartups]       = useState(INITIAL_STARTUPS);
  const [employees,      setEmployees]      = useState(INITIAL_EMPLOYEES);
  const [selectedEmpId,  setSelectedEmpId]  = useState(null);
  const [selectedSId,    setSelectedSId]    = useState(null);
  const [roomTarget,     setRoomTarget]     = useState(null); // {roomId,room,startupContext,emps}
  const [logs,           setLogs]           = useState([{ id:"init", time:new Date().toLocaleTimeString(), msg:"SYSTEM_ONLINE :: SIMULATION_ACTIVE", type:"info" }]);
  const [isLogOpen,      setIsLogOpen]      = useState(false);
  const [isMapLocked,    setIsMapLocked]    = useState(false);
  const [hubPos,         setHubPos]         = useState({ x:580, y:1080 });
  const [showAddStartup, setShowAddStartup] = useState(false);
  const [showAddAgent,   setShowAddAgent]   = useState(false);
  const [coffeeMeeting,  setCoffeeMeeting]  = useState(null);
  const [pitchTarget,    setPitchTarget]    = useState(null);
  const [kanbanTarget,   setKanbanTarget]   = useState(null);
  const [vp,             setVp]             = useState({ x:40, y:20, scale:0.52 });
  const mapRef    = useRef(null);
  const isPanning = useRef(false);
  const lastMouse = useRef({ x:0, y:0 });
  const nodeDrag  = useRef(null);

  const addLog = useCallback((msg,type="info") => {
    setLogs(p=>[...p,{ id:Date.now()+Math.random(), time:new Date().toLocaleTimeString(), msg, type }]);
  },[]);

  // Auto-recenter on mount
  useEffect(() => {
    const timeout = setTimeout(() => {
      const rect = mapRef.current?.getBoundingClientRect();
      if (!rect) return;
      const minX = 100, minY = 500, maxX = 1660, maxY = 1760;
      const ns = Math.max(0.12, Math.min(2, Math.min(rect.width/(maxX-minX), rect.height/(maxY-minY))*0.85));
      setVp({ scale:ns, x:-(minX+(maxX-minX)/2)*ns+rect.width/2, y:-(minY+(maxY-minY)/2)*ns+rect.height/2 });
    }, 400);
    return () => clearTimeout(timeout);
  }, []); // eslint-disable-line

  // Simulation
  useEffect(() => {
    const iv = setInterval(()=>setEmployees(p=>simTick(p,addLog)), 4000);
    return ()=>clearInterval(iv);
  },[addLog]);

  // Wheel zoom
  const handleWheel = useCallback(e => {
    e.preventDefault();
    const d=e.deltaY<0?1.12:0.89, rect=mapRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx=e.clientX-rect.left, my=e.clientY-rect.top;
    setVp(v=>{ const ns=Math.max(0.12,Math.min(4,v.scale*d)); return { scale:ns, x:mx-(mx-v.x)*(ns/v.scale), y:my-(my-v.y)*(ns/v.scale) }; });
  },[]);
  useEffect(()=>{ const el=mapRef.current; if(!el) return; el.addEventListener("wheel",handleWheel,{passive:false}); return()=>el.removeEventListener("wheel",handleWheel); },[handleWheel]);

  const onMapMouseDown = e => { if(isMapLocked||e.target.closest("[data-nodedrag]")) return; isPanning.current=true; lastMouse.current={x:e.clientX,y:e.clientY}; };
  const onMapMouseMove = e => {
    if (nodeDrag.current) {
      const nd=nodeDrag.current, dx=(e.clientX-nd.startX)/vp.scale, dy=(e.clientY-nd.startY)/vp.scale;
      if(nd.type==="startup") setStartups(p=>p.map(s=>s.id===nd.id?{...s,position:{x:nd.initX+dx,y:nd.initY+dy}}:s));
      else setHubPos({x:nd.initX+dx,y:nd.initY+dy});
      return;
    }
    if (!isPanning.current) return;
    const dx=e.clientX-lastMouse.current.x, dy=e.clientY-lastMouse.current.y;
    lastMouse.current={x:e.clientX,y:e.clientY};
    setVp(v=>({...v,x:v.x+dx,y:v.y+dy}));
  };
  const onMapMouseUp = () => { isPanning.current=false; nodeDrag.current=null; };

  const recenter = useCallback(() => {
    const rect=mapRef.current?.getBoundingClientRect(); if(!rect) return;
    const nodes=[...startups.map(s=>({x:s.position.x,y:s.position.y,w:580,h:460})),{x:hubPos.x,y:hubPos.y,w:740,h:620}];
    const minX=Math.min(...nodes.map(n=>n.x))-60, minY=Math.min(...nodes.map(n=>n.y))-60;
    const maxX=Math.max(...nodes.map(n=>n.x+n.w))+60, maxY=Math.max(...nodes.map(n=>n.y+n.h))+60;
    const ns=Math.max(0.12,Math.min(3,Math.min(rect.width/(maxX-minX),rect.height/(maxY-minY))*0.88));
    setVp({ scale:ns, x:-(minX+(maxX-minX)/2)*ns+rect.width/2, y:-(minY+(maxY-minY)/2)*ns+rect.height/2 });
  }, [startups, hubPos]);

  const selectedEmp   = employees.find(e=>e.id===selectedEmpId);
  const selectedStart = startups.find(s=>s.id===selectedSId);

  const triggerCoffee = () => {
    const byS={};
    employees.forEach(e=>{ (byS[e.startupId]??=[]).push(e); });
    const ids=Object.keys(byS);
    if(ids.length<2){ addLog("NEED 2+ STARTUPS FOR COFFEE_MEETING","warning"); return; }
    const picks=ids.slice(0,2).map(id=>byS[id][Math.floor(Math.random()*byS[id].length)]);
    setCoffeeMeeting(picks);
  };

  const addStartup = (name,objective,repo) => {
    const n={ id:`s${Date.now()}`, name:name||"New Venture", logo:"🚀", tagline:objective?.slice(0,40)||"Build the future",
      objective:objective||"Build the future", githubRepo:repo||undefined,
      parameters:{funding:"Seed",stealth:false},
      position:{x:160+startups.length*870,y:560}, weeklyScore:0,
      milestones:[
        {id:"m1",label:"Ideation & Validation",status:"completed"},
        {id:"m2",label:"MVP Development",status:"in-progress"},
        {id:"m3",label:"Growth & Scaling",status:"pending"},
        {id:"m4",label:objective||"Final Objective",status:"pending"},
      ]};
    setStartups(p=>[...p,n]);
    addLog(`STARTUP_REGISTERED :: ${n.name.toUpperCase()}`,"success");
  };

  const addEmployee = useCallback(data => {
    setEmployees(p=>[...p,data]);
    addLog(`AGENT_DEPLOYED :: ${data.name.toUpperCase()} → ${startups.find(s=>s.id===data.startupId)?.name}`,"info");
  },[startups]);

  const removeEmployee = id => {
    setEmployees(p=>p.filter(e=>e.id!==id));
    if(selectedEmpId===id) setSelectedEmpId(null);
  };

  const handleRoomClick = (roomId,room,startup,emps) => {
    setRoomTarget({roomId,room,startupContext:startup,emps});
    setSelectedEmpId(null); setSelectedSId(null);
  };

  const handleAgentClick = (emp) => {
    setSelectedEmpId(emp.id); setSelectedSId(null); setRoomTarget(null);
  };

  // Inspector panel content
  const renderInspector = () => {
    if (selectedEmp) return (
      <AgentInspector emp={selectedEmp} startups={startups}
        onClose={()=>setSelectedEmpId(null)} onRemove={removeEmployee} />
    );
    if (roomTarget) return (
      <RoomInspector roomId={roomTarget.roomId} room={roomTarget.room}
        emps={roomTarget.emps} startupCtx={roomTarget.startupContext}
        onClose={()=>setRoomTarget(null)} onAgentSelect={handleAgentClick} />
    );
    if (selectedStart) return (
      <StartupInspector startup={selectedStart} employees={employees}
        onClose={()=>setSelectedSId(null)}
        onPitch={()=>setPitchTarget(selectedStart)}
        onKanban={()=>setKanbanTarget(selectedStart)}
        onAddAgent={()=>setShowAddAgent(true)} />
    );
    return <InspectorEmpty />;
  };

  const totalXP = employees.reduce((a,e)=>a+(e.totalXp||0),0);
  const totalST = employees.reduce((a,e)=>a+(e.skillTokens||0),0);
  const lastLog = logs[logs.length-1];

  return (
    <div style={{ width:"100vw", height:"100vh", background:"#030603", color:"#2a4a2a",
      overflow:"hidden", position:"relative", fontFamily:"'JetBrains Mono',monospace" }}>

      <Scanlines />

      {/* ── TOP HEADER BAR ── */}
      <header style={{ position:"fixed", top:10, left:10, right:10, height:52, zIndex:100,
        background:"rgba(4,10,4,0.97)", border:"1px solid #0d2a0d", borderRadius:6,
        display:"flex", alignItems:"center", padding:"0 18px", gap:20,
        boxShadow:"0 0 40px rgba(0,0,0,0.8), 0 0 1px rgba(0,255,136,0.1)" }}>
        <Bracket size={8} color="#00ff8822" />

        {/* Brand */}
        <div style={{ display:"flex", alignItems:"center", gap:10, flexShrink:0 }}>
          <div style={{ width:32, height:32, background:"#00ff88", borderRadius:3,
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:"0 0 16px rgba(0,255,136,0.4)" }}>
            <span style={{ fontSize:16, filter:"invert(1)" }}>⌬</span>
          </div>
          <div>
            <div style={{ fontWeight:900, color:"#00ff88", fontSize:13, letterSpacing:"0.08em",
              textShadow:"0 0 12px rgba(0,255,136,0.5)" }}>STUDIO_IA</div>
            <div style={{ fontSize:8, color:"#0d3a0d", letterSpacing:"0.2em" }}>TACTICAL_OS v2.0</div>
          </div>
        </div>

        {/* Separator */}
        <div style={{ width:1, height:28, background:"#0d2a0d" }} />

        {/* Live ticker */}
        <div style={{ flex:1, display:"flex", alignItems:"center", gap:8, overflow:"hidden" }}>
          <span style={{ color:"#00ff88", fontSize:10, flexShrink:0, animation:"statusPulse 2s infinite" }}>◉</span>
          <span style={{ fontSize:9, color:"#1a4a1a", letterSpacing:"0.04em", overflow:"hidden",
            textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
            {lastLog?.msg || "SYSTEM_ONLINE"}
          </span>
        </div>

        {/* System metrics mini */}
        <div style={{ display:"flex", gap:16, flexShrink:0 }}>
          {[["AGENTS",employees.length,"#00ff88"],["VENTURES",startups.length,"#a855f7"],
            ["Σ XP",totalXP.toLocaleString(),"#00cfff"],["Σ ST",totalST,"#f59e0b"]].map(([k,v,c])=>(
            <div key={k} style={{ textAlign:"center" }}>
              <div style={{ fontSize:12, fontWeight:900, color:c, letterSpacing:"-0.02em",
                textShadow:`0 0 8px ${c}55` }}>{v}</div>
              <div style={{ fontSize:7, color:"#0d2a0d", letterSpacing:"0.08em" }}>{k}</div>
            </div>
          ))}
        </div>

        {/* Separator */}
        <div style={{ width:1, height:28, background:"#0d2a0d" }} />
        <LiveClock />
        <div style={{ width:1, height:28, background:"#0d2a0d" }} />

        {/* Actions */}
        <div style={{ display:"flex", gap:8, flexShrink:0 }}>
          <SysBtn label="☕ COFFEE" onClick={triggerCoffee} size="sm" />
          <SysBtn label="+ STARTUP" onClick={()=>setShowAddStartup(true)} accent size="sm" />
        </div>
      </header>

      {/* ── MAIN 3-COLUMN LAYOUT ── */}
      <main style={{ position:"absolute", inset:0, top:72, bottom:0, padding:"8px 10px",
        display:"grid", gridTemplateColumns:"256px 1fr 300px", gap:8 }}>

        {/* ── LEFT: Venture list ── */}
        <div style={{ display:"flex", flexDirection:"column", gap:8, overflow:"hidden" }}>
          {/* Section header */}
          <div style={{ padding:"8px 12px", borderBottom:"1px solid #0d1a0d", flexShrink:0 }}>
            <div style={{ fontSize:9, color:"#1a4a1a", letterSpacing:"0.12em", textTransform:"uppercase" }}>
              ACTIVE_VENTURES({startups.length})
            </div>
          </div>

          {/* Startup cards */}
          <div style={{ flex:1, overflowY:"auto", display:"flex", flexDirection:"column", gap:6, paddingRight:2 }}>
            {startups.map(startup => {
              const team=employees.filter(e=>e.startupId===startup.id);
              const sel=selectedSId===startup.id;
              return (
                <div key={startup.id}
                  onClick={()=>{ setSelectedSId(startup.id); setSelectedEmpId(null); setRoomTarget(null); }}
                  style={{ background: sel?"rgba(0,255,136,0.04)":"#040804",
                    border:`1px solid ${sel?"rgba(0,255,136,0.25)":"#0d1a0d"}`,
                    borderRadius:6, padding:"14px 14px", cursor:"pointer",
                    transition:"all 0.18s", position:"relative",
                    boxShadow: sel?"0 0 20px rgba(0,255,136,0.05)":"none" }}
                  onMouseOver={e=>{ if(!sel){ e.currentTarget.style.borderColor="rgba(0,255,136,0.12)"; } }}
                  onMouseOut={e=>{ if(!sel){ e.currentTarget.style.borderColor="#0d1a0d"; } }}>
                  {sel && <Bracket size={8} color="#00ff8844" />}
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                    <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                      <div style={{ width:32, height:32, background:"#060a06", border:`1px solid ${sel?"#0d2a0d":"#0a100a"}`,
                        borderRadius:4, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>
                        {startup.logo}
                      </div>
                      <div>
                        <div style={{ fontWeight:700, color:sel?"#00ff88":"#2a5a2a", fontSize:12, letterSpacing:"0.02em" }}>{startup.name}</div>
                        <div style={{ fontSize:8, color:"#0d2a0d", letterSpacing:"0.06em", marginTop:1 }}>
                          {startup.parameters.funding.toUpperCase()}{startup.parameters.stealth?" · STEALTH":""}
                        </div>
                      </div>
                    </div>
                    <button onClick={e=>{ e.stopPropagation(); setShowAddAgent(true); setSelectedSId(startup.id); }}
                      style={{ background:"transparent", border:"1px solid #0d1a0d", borderRadius:3,
                        width:22, height:22, display:"flex", alignItems:"center", justifyContent:"center",
                        cursor:"pointer", color:"#1a4a1a", fontSize:12 }}>+</button>
                  </div>

                  <div style={{ fontSize:10, color:"#0d2a0d", marginBottom:10, lineHeight:1.6,
                    overflow:"hidden", display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical" }}>
                    {startup.objective}
                  </div>

                  {/* Team avatars */}
                  <div style={{ display:"flex", gap:3, marginBottom:8 }}>
                    {team.slice(0,6).map(e=>(
                      <div key={e.id} style={{ width:18, height:18, background:"#060a06", borderRadius:3,
                        display:"flex", alignItems:"center", justifyContent:"center", fontSize:10,
                        border:`1px solid ${MOOD_COLOR[e.mood]||"#0d1a0d"}44` }}>{e.avatar}</div>
                    ))}
                    {team.length>6&&<div style={{ width:18, height:18, background:"#060a06", borderRadius:3,
                      display:"flex", alignItems:"center", justifyContent:"center", fontSize:8, color:"#0d2a0d",
                      border:"1px solid #0d1a0d" }}>+{team.length-6}</div>}
                  </div>

                  {/* Progress bar + score */}
                  <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                    <div style={{ flex:1, height:1, background:"#0a100a", overflow:"hidden" }}>
                      <div style={{ height:"100%", width:"65%", background:"rgba(0,255,136,0.3)",
                        boxShadow:"0 0 4px rgba(0,255,136,0.2)" }} />
                    </div>
                    {startup.weeklyScore>0 && (
                      <span style={{ fontSize:8, color:"#a855f7", background:"rgba(168,85,247,0.08)",
                        border:"1px solid rgba(168,85,247,0.2)", borderRadius:2, padding:"0 5px" }}>
                        ★{startup.weeklyScore}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Global metrics panel */}
          <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:6, padding:14, flexShrink:0 }}>
            <div style={{ fontSize:8, color:"#0d2a0d", letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:10 }}>GLOBAL_METRICS</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>
              {[["AGENTS",employees.length,"#00ff88"],["VENTURES",startups.length,"#a855f7"],
                ["TOTAL_XP",totalXP.toLocaleString(),"#00cfff"],["TOTAL_ST",totalST,"#f59e0b"]].map(([k,v,c])=>(
                <div key={k} style={{ background:"#030603", border:"1px solid #0a100a", borderRadius:4, padding:"7px 10px", textAlign:"center" }}>
                  <div style={{ fontSize:14, fontWeight:900, color:c, letterSpacing:"-0.02em",
                    textShadow:`0 0 8px ${c}44` }}>{v}</div>
                  <div style={{ fontSize:7, color:"#0a180a", textTransform:"uppercase", letterSpacing:"0.08em", marginTop:2 }}>{k}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── CENTER: Canvas map ── */}
        <div ref={mapRef}
          style={{ background:"#020402", border:"1px solid #0d1a0d", borderRadius:6, position:"relative",
            overflow:"hidden", cursor:isMapLocked?"default":"grab" }}
          onMouseDown={onMapMouseDown} onMouseMove={onMapMouseMove}
          onMouseUp={onMapMouseUp}    onMouseLeave={onMapMouseUp}>

          {/* Subtle radial vignette */}
          <div style={{ position:"absolute", inset:0, pointerEvents:"none", zIndex:5,
            background:"radial-gradient(ellipse at 50% 50%, transparent 55%, rgba(0,4,0,0.7) 100%)" }} />

          {/* Map controls */}
          <div style={{ position:"absolute", top:10, right:10, zIndex:20,
            display:"flex", flexDirection:"column", gap:4 }}>
            {[["⊕",()=>setVp(v=>({...v,scale:Math.min(4,v.scale*1.2)}))],
              ["⊖",()=>setVp(v=>({...v,scale:Math.max(0.12,v.scale/1.2)}))],
              ["⊙",recenter],
              [isMapLocked?"⊠":"⊞",()=>setIsMapLocked(l=>!l)]
            ].map(([glyph,action],i)=>(
              <button key={i} onClick={action}
                style={{ width:30, height:30, background:"#040804",
                  border:`1px solid ${i===3&&isMapLocked?"rgba(245,158,11,0.4)":"#0d1a0d"}`,
                  borderRadius:4, display:"flex", alignItems:"center", justifyContent:"center",
                  cursor:"pointer", fontSize:16, color:i===3&&isMapLocked?"#f59e0b":"#1a4a1a",
                  fontFamily:"'JetBrains Mono',monospace" }}>
                {glyph}
              </button>
            ))}
          </div>

          {/* Canvas world */}
          <div style={{ width:5000, height:5000, position:"absolute",
            transform:`translate(${vp.x}px,${vp.y}px) scale(${vp.scale})`, transformOrigin:"0 0" }}>

            {/* Grid */}
            <div style={{ position:"absolute", inset:0, pointerEvents:"none",
              backgroundImage:"radial-gradient(rgba(0,255,136,0.14) 1px, transparent 1px)",
              backgroundSize:"48px 48px" }} />

            {/* Grid cross-lines (faint) */}
            <div style={{ position:"absolute", inset:0, pointerEvents:"none", opacity:0.03,
              backgroundImage:"linear-gradient(#00ff88 1px,transparent 1px),linear-gradient(90deg,#00ff88 1px,transparent 1px)",
              backgroundSize:"240px 240px" }} />

            {/* Connection lines */}
            <svg style={{ position:"absolute", inset:0, pointerEvents:"none", overflow:"visible" }}>
              {startups.map(s=>(
                <line key={s.id}
                  x1={s.position.x+290} y1={s.position.y+230}
                  x2={hubPos.x+370}    y2={hubPos.y+310}
                  stroke="rgba(0,255,136,0.08)" strokeWidth="1.5"
                  strokeDasharray="6,10" />
              ))}
            </svg>

            {/* ── Startup nodes ── */}
            {startups.map(startup=>(
              <div key={startup.id} data-nodedrag="1"
                style={{ position:"absolute", left:startup.position.x, top:startup.position.y,
                  width:580, height:460, background:"#0c1a0c",
                  border:`1px solid ${selectedSId===startup.id?"rgba(0,255,136,0.55)":"rgba(0,255,136,0.22)"}`,
                  borderRadius:8, overflow:"hidden",
                  boxShadow:selectedSId===startup.id?"0 0 40px rgba(0,255,136,0.12), 0 0 0 1px rgba(0,255,136,0.18)":"0 8px 40px rgba(0,0,0,0.8), 0 0 0 1px rgba(0,255,136,0.1)" }}>

                {/* Node header — drag handle */}
                <div data-nodedrag="1"
                  style={{ height:48, background:"#112011", borderBottom:"1px solid rgba(0,255,136,0.22)",
                    display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 14px",
                    cursor:"grab", userSelect:"none" }}
                  onClick={()=>{ setSelectedSId(startup.id); setSelectedEmpId(null); setRoomTarget(null); }}
                  onPointerDown={e=>{ e.stopPropagation();
                    nodeDrag.current={type:"startup",id:startup.id,startX:e.clientX,startY:e.clientY,initX:startup.position.x,initY:startup.position.y};
                    e.currentTarget.setPointerCapture(e.pointerId); }}
                  onPointerMove={e=>{ if(!nodeDrag.current||nodeDrag.current.id!==startup.id) return; e.stopPropagation();
                    const dx=(e.clientX-nodeDrag.current.startX)/vp.scale, dy=(e.clientY-nodeDrag.current.startY)/vp.scale;
                    setStartups(p=>p.map(s=>s.id===startup.id?{...s,position:{x:nodeDrag.current.initX+dx,y:nodeDrag.current.initY+dy}}:s)); }}
                  onPointerUp={()=>{ nodeDrag.current=null; }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    <span style={{ fontSize:18 }}>{startup.logo}</span>
                    <div>
                      <div style={{ fontWeight:800, color:"#00ff88", fontSize:12, letterSpacing:"0.04em",
                        textShadow:"0 0 8px rgba(0,255,136,0.4)" }}>{startup.name.toUpperCase()}</div>
                      <div style={{ fontSize:8, color:"#0d2a0d", letterSpacing:"0.06em" }}>{startup.parameters.funding.toUpperCase()}</div>
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:6 }}>
                    <button onClick={e=>{e.stopPropagation();setKanbanTarget(startup);}}
                      style={{ background:"transparent", border:"1px solid #0d1a0d", borderRadius:3,
                        padding:"2px 8px", fontSize:7, color:"#1a4a1a", cursor:"pointer", letterSpacing:"0.06em",
                        fontFamily:"'JetBrains Mono',monospace" }}>KANBAN</button>
                    <button onClick={e=>{e.stopPropagation();setPitchTarget(startup);}}
                      style={{ background:"rgba(0,255,136,0.05)", border:"1px solid rgba(0,255,136,0.2)", borderRadius:3,
                        padding:"2px 8px", fontSize:7, color:"#00ff88", cursor:"pointer", letterSpacing:"0.06em",
                        fontFamily:"'JetBrains Mono',monospace" }}>EVALUATE</button>
                  </div>
                </div>

                {/* Rooms */}
                <div style={{ position:"relative", width:"100%", height:"calc(100% - 48px)" }}>
                  {["work_area","daily_room"].map(rId=>{
                    const emps=employees.filter(e=>e.currentRoom===rId&&e.startupId===startup.id);
                    return <RoomCell key={rId} roomId={rId} layout={STARTUP_ROOM_LAYOUTS[rId]}
                      emps={emps} startup={startup} onRoomClick={handleRoomClick} onAgentClick={handleAgentClick} />;
                  })}
                </div>
              </div>
            ))}

            {/* ── Incubator Hub ── */}
            <div data-nodedrag="1"
              style={{ position:"absolute", left:hubPos.x, top:hubPos.y, width:740, height:620,
                background:"#0b180b", border:"1px solid rgba(0,255,136,0.2)",
                borderRadius:8, overflow:"hidden", boxShadow:"0 8px 40px rgba(0,0,0,0.8), 0 0 0 1px rgba(0,255,136,0.1)" }}>
              <div data-nodedrag="1"
                style={{ height:48, background:"#102010", borderBottom:"1px solid rgba(0,255,136,0.22)",
                  display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 14px",
                  cursor:"grab", userSelect:"none" }}
                onPointerDown={e=>{ e.stopPropagation();
                  nodeDrag.current={type:"hub",startX:e.clientX,startY:e.clientY,initX:hubPos.x,initY:hubPos.y};
                  e.currentTarget.setPointerCapture(e.pointerId); }}
                onPointerMove={e=>{ if(!nodeDrag.current||nodeDrag.current.type!=="hub") return; e.stopPropagation();
                  const dx=(e.clientX-nodeDrag.current.startX)/vp.scale, dy=(e.clientY-nodeDrag.current.startY)/vp.scale;
                  setHubPos({x:nodeDrag.current.initX+dx,y:nodeDrag.current.initY+dy}); }}
                onPointerUp={()=>{ nodeDrag.current=null; }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:16 }}>🏢</span>
                  <div>
                    <div style={{ fontWeight:800, color:"#00ff88", fontSize:12, letterSpacing:"0.04em",
                      textShadow:"0 0 8px rgba(0,255,136,0.3)" }}>THE PÉPINIÈRE</div>
                    <div style={{ fontSize:8, color:"#0d2a0d", letterSpacing:"0.06em" }}>INCUBATOR_HUB</div>
                  </div>
                </div>
                <button onClick={triggerCoffee}
                  style={{ background:"rgba(0,255,136,0.05)", border:"1px solid rgba(0,255,136,0.15)", borderRadius:3,
                    padding:"3px 10px", fontSize:7, color:"#00ff88", cursor:"pointer", letterSpacing:"0.06em",
                    fontFamily:"'JetBrains Mono',monospace", display:"flex", alignItems:"center", gap:4 }}>
                  ☕ COFFEE_MEET
                </button>
              </div>
              <div style={{ position:"relative", width:"100%", height:"calc(100% - 48px)" }}>
                {["pitch_arena","training_room","break_room","director_office"].map(rId=>{
                  const emps=employees.filter(e=>e.currentRoom===rId);
                  return <RoomCell key={rId} roomId={rId} layout={INCUBATOR_ROOM_LAYOUTS[rId]}
                    emps={emps} startup={null} onRoomClick={handleRoomClick} onAgentClick={handleAgentClick} />;
                })}
              </div>
            </div>
          </div>
        </div>

        {/* ── RIGHT: Inspector ── */}
        <div style={{ background:"#040804", border:"1px solid #0d1a0d", borderRadius:6,
          overflow:"hidden", display:"flex", flexDirection:"column", position:"relative" }}>
          <Bracket size={8} color="#00ff8818" />
          {/* Panel label */}
          <div style={{ padding:"8px 14px", borderBottom:"1px solid #0d1a0d", flexShrink:0 }}>
            <div style={{ fontSize:8, color:"#0d2a0d", letterSpacing:"0.14em", textTransform:"uppercase" }}>INSPECTOR_PANEL</div>
          </div>
          <div style={{ flex:1, overflow:"hidden" }}>
            {renderInspector()}
          </div>
        </div>
      </main>

      {/* ── Log panel ── */}
      <LogPanel logs={logs} isOpen={isLogOpen} setIsOpen={setIsLogOpen} />

      {/* ── Modals ── */}
      {showAddStartup && <AddStartupModal onAdd={addStartup} onClose={()=>setShowAddStartup(false)} />}
      {showAddAgent   && <AddEmployeeModal startups={startups} onAdd={addEmployee} onClose={()=>setShowAddAgent(false)} />}
      {coffeeMeeting  && (
        <CoffeeMeetingModal agents={coffeeMeeting} startups={startups}
          onClose={()=>{ setCoffeeMeeting(null);
            setEmployees(p=>p.map(e=>coffeeMeeting.find(a=>a.id===e.id)?{...e,totalXp:(e.totalXp||0)+30,skillTokens:(e.skillTokens||0)+15}:e)); }} />
      )}
      {pitchTarget  && <PitchFeedbackModal startup={pitchTarget}  onClose={()=>setPitchTarget(null)} />}
      {kanbanTarget && <KanbanModal startup={kanbanTarget} employees={employees} setEmployees={setEmployees} onClose={()=>setKanbanTarget(null)} />}

      <style>{`
        @keyframes sysModalIn { from{opacity:0;transform:scale(0.97) translateY(8px)} to{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes fadeSlideIn { from{opacity:0;transform:translateX(-6px)} to{opacity:1;transform:translateX(0)} }
        @keyframes statusPulse { 0%,100%{opacity:1} 50%{opacity:0.25} }
        * { box-sizing:border-box; }
        ::-webkit-scrollbar { width:3px; height:3px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:#0d2a0d; border-radius:2px; }
        ::-webkit-scrollbar-thumb:hover { background:#1a4a1a; }
        select option { background:#040804; color:#3a6a3a; }
        input::placeholder, textarea::placeholder { color:#0d2a0d; }
      `}</style>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
