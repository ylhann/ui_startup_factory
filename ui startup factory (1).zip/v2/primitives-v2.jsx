// ─── V2 Primitives ────────────────────────────────────────────────────────────

const { useState: useSt, useEffect: useEf, useRef: useRf, useCallback: useCb } = React;

// ── Scanline overlay (pure CSS via SVG data URI) ──────────────────────────────
function Scanlines() {
  return (
    <div style={{ position:"fixed", inset:0, pointerEvents:"none", zIndex:9999, opacity:0.025,
      backgroundImage:`repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,136,0.3) 2px, rgba(0,255,136,0.3) 3px)`,
      backgroundSize:"100% 3px" }} />
  );
}

// ── Corner bracket decoration ─────────────────────────────────────────────────
function Bracket({ size=10, color="#00ff88", style:s={} }) {
  const b = `2px solid ${color}`;
  return (
    <>
      <div style={{ position:"absolute", top:0, left:0, width:size, height:size, borderTop:b, borderLeft:b, ...s }} />
      <div style={{ position:"absolute", top:0, right:0, width:size, height:size, borderTop:b, borderRight:b, ...s }} />
      <div style={{ position:"absolute", bottom:0, left:0, width:size, height:size, borderBottom:b, borderLeft:b, ...s }} />
      <div style={{ position:"absolute", bottom:0, right:0, width:size, height:size, borderBottom:b, borderRight:b, ...s }} />
    </>
  );
}

// ── Hex ID ────────────────────────────────────────────────────────────────────
function HexId({ id }) {
  return <span style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#1a3a2a", letterSpacing:"0.06em" }}>#{id.toUpperCase().slice(-6)}</span>;
}

// ── System tag ────────────────────────────────────────────────────────────────
function SysTag({ label, color="#00ff88", dim=false }) {
  const c = dim ? "#1a2a1a" : color;
  return (
    <span style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:c,
      background:c+"11", border:`1px solid ${c}33`, borderRadius:3,
      padding:"1px 6px", letterSpacing:"0.06em", textTransform:"uppercase", whiteSpace:"nowrap" }}>
      {label}
    </span>
  );
}

// ── XP Arc ring ───────────────────────────────────────────────────────────────
function XpRing({ totalXp, size=56, children }) {
  const level  = getLevel(totalXp);
  const nextLv = Math.min(level+1, LEVEL_XP.length-1);
  const pct    = nextLv===level ? 1 : (totalXp - LEVEL_XP[level]) / (LEVEL_XP[nextLv] - LEVEL_XP[level]);
  const r      = (size-7)/2;
  const circ   = 2*Math.PI*r;
  const color  = LEVEL_COLORS[level];
  return (
    <div style={{ position:"relative", width:size, height:size, flexShrink:0 }}>
      <svg width={size} height={size} style={{ position:"absolute", top:0, left:0, transform:"rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#0d1a0d" strokeWidth={3.5} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={3.5}
          strokeDasharray={`${pct*circ} ${circ}`} strokeLinecap="round"
          style={{ transition:"stroke-dasharray 0.8s cubic-bezier(.4,0,.2,1)", filter:`drop-shadow(0 0 4px ${color})` }} />
      </svg>
      <div style={{ position:"absolute", inset:4, borderRadius:"50%",
        background:"radial-gradient(circle at 35% 35%, #0d1a11, #060a06)",
        display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden" }}>
        {children}
      </div>
    </div>
  );
}

// ── Stat meter (animated bar with glow) ───────────────────────────────────────
function StatMeter({ label, value, color, mono=false }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <span style={{ fontSize:9, color:"#2a3a2a", fontFamily:"'JetBrains Mono', monospace", letterSpacing:"0.08em", textTransform:"uppercase" }}>{label}</span>
        <span style={{ fontSize:10, color, fontFamily:"'JetBrains Mono', monospace", fontWeight:700 }}>{Math.round(value).toString().padStart(3,"0")}</span>
      </div>
      <div style={{ height:2, background:"#0d1a0d", borderRadius:1, overflow:"hidden", border:"1px solid #0d1a0d" }}>
        <div style={{ height:"100%", width:`${value}%`, background:color,
          boxShadow:`0 0 8px ${color}`, borderRadius:1, transition:"width 1s cubic-bezier(.4,0,.2,1)" }} />
      </div>
    </div>
  );
}

// ── Skill row ─────────────────────────────────────────────────────────────────
function SkillRow({ skill, lit=false }) {
  const pct = Math.min((skill.xp/skill.maxXp)*100, 100);
  const col  = lit ? "#00cfff" : "#00ff88";
  return (
    <div style={{ display:"flex", alignItems:"center", gap:10,
      padding:"6px 10px", borderRadius:4,
      background: lit ? "rgba(0,207,255,0.04)" : "transparent",
      border:`1px solid ${lit ? "rgba(0,207,255,0.2)" : "transparent"}`,
      transition:"all 0.2s" }}>
      <div style={{ width:28, fontFamily:"'JetBrains Mono', monospace", fontSize:10, color:col, fontWeight:700, flexShrink:0 }}>LV{skill.level}</div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:11, color: lit?"#00cfff":"#4a6a4a", marginBottom:3, letterSpacing:"0.02em" }}>{skill.name}{lit?" ↑":""}</div>
        <div style={{ height:2, background:"#0d1a0d", borderRadius:1, overflow:"hidden" }}>
          <div style={{ width:`${pct}%`, height:"100%", background:col, boxShadow:`0 0 6px ${col}80`, borderRadius:1, transition:"width 0.8s ease" }} />
        </div>
      </div>
      <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:"#1a3a1a", width:52, textAlign:"right" }}>{Math.floor(skill.xp)}/{skill.maxXp}</div>
    </div>
  );
}

// ── Task flow list ────────────────────────────────────────────────────────────
function TaskFlow({ tasks }) {
  const statusColor = { todo:"#1a3a1a", doing:"#00cfff", done:"#00ff88" };
  const statusGlyph = { todo:"○", doing:"◈", done:"◉" };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
      {(tasks||[]).map((t,i) => {
        const blocked = t.status!=="done" && t.dependencies?.some(d=>tasks.find(x=>x.id===d)?.status!=="done");
        const col = blocked ? "#1a2a1a" : statusColor[t.status];
        return (
          <div key={t.id} style={{ display:"flex", alignItems:"flex-start", gap:8 }}>
            <div style={{ display:"flex", flexDirection:"column", alignItems:"center", paddingTop:2 }}>
              <span style={{ fontSize:10, color:blocked?"#1a2a1a":col, lineHeight:1 }}>{statusGlyph[t.status]}</span>
              {i < tasks.length-1 && <div style={{ width:1, height:10, background:"#0d1a0d", margin:"2px 0" }} />}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:11, color:blocked?"#1a2a1a":t.status==="done"?"#00ff88":"#3a5a3a",
                textDecoration:blocked?"line-through":"none", letterSpacing:"0.01em" }}>{t.label}</div>
              {t.status==="doing" && t.progress>0 && (
                <div style={{ marginTop:3, height:1, background:"#0d1a0d", overflow:"hidden" }}>
                  <div style={{ height:"100%", width:`${t.progress}%`, background:"#00cfff", boxShadow:"0 0 6px #00cfff" }} />
                </div>
              )}
            </div>
            <div style={{ fontFamily:"'JetBrains Mono', monospace", fontSize:9, color:col, flexShrink:0 }}>
              {blocked?"BLOCKED":t.status==="doing"?`${Math.round(t.progress)}%`:t.status.toUpperCase()}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Simple markdown renderer ──────────────────────────────────────────────────
function SysMd({ text }) {
  if (!text) return null;
  return (
    <div style={{ fontSize:12, lineHeight:1.8, color:"#3a5a3a", fontFamily:"'JetBrains Mono', monospace" }}>
      {text.split("\n").map((line,i) => {
        if (line.startsWith("## ")) return <div key={i} style={{ color:"#00ff88", fontWeight:700, fontSize:11, margin:"12px 0 4px", letterSpacing:"0.06em" }}>{line.slice(3).toUpperCase()}</div>;
        if (line.startsWith("# "))  return <div key={i} style={{ color:"#00cfff", fontWeight:700, fontSize:12, margin:"14px 0 6px" }}>{line.slice(2)}</div>;
        if (line.startsWith("- "))  return <div key={i} style={{ paddingLeft:14, marginBottom:3, color:"#2a4a2a" }}>▸ {line.slice(2)}</div>;
        if (line.startsWith("**")) { const c=line.replace(/\*\*(.*?)\*\*/g,"$1"); return <div key={i} style={{ color:"#4a7a4a", fontWeight:700, marginBottom:2 }}>{c}</div>; }
        if (!line.trim())           return <div key={i} style={{ height:6 }} />;
        return <div key={i} style={{ color:"#2a4a2a", marginBottom:2 }}>{line}</div>;
      })}
    </div>
  );
}

// ── Ping output bubble ────────────────────────────────────────────────────────
function PingBubble({ text }) {
  return (
    <div style={{ background:"rgba(0,207,255,0.04)", border:"1px solid rgba(0,207,255,0.15)",
      borderRadius:6, padding:"12px 14px", position:"relative" }}>
      <div style={{ fontSize:9, color:"#00cfff", fontFamily:"'JetBrains Mono', monospace",
        letterSpacing:"0.08em", marginBottom:6, textTransform:"uppercase" }}>◈ NEURAL_PING_OUTPUT</div>
      <div style={{ fontSize:12, color:"#5aafa0", lineHeight:1.75, fontStyle:"italic" }}>"{text}"</div>
    </div>
  );
}

// ── Icon button ───────────────────────────────────────────────────────────────
function SysBtn({ label, icon, onClick, accent=false, disabled=false, size="sm" }) {
  const [hov, setHov] = useSt(false);
  const pad = size==="sm" ? "7px 12px" : "11px 20px";
  const fs  = size==="sm" ? 9 : 11;
  const bg  = accent
    ? (hov&&!disabled ? "rgba(0,255,136,0.15)" : "rgba(0,255,136,0.08)")
    : (hov&&!disabled ? "rgba(255,255,255,0.05)" : "transparent");
  const border = accent ? "1px solid rgba(0,255,136,0.35)" : "1px solid #0d1a0d";
  const color  = accent ? "#00ff88" : (hov ? "#3a6a3a" : "#1a3a1a");
  return (
    <button onClick={onClick} disabled={disabled}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ display:"flex", alignItems:"center", gap:6, padding:pad, background:bg,
        border, borderRadius:4, color, fontFamily:"'JetBrains Mono', monospace",
        fontSize:fs, fontWeight:700, letterSpacing:"0.06em", textTransform:"uppercase",
        cursor:disabled?"not-allowed":"pointer", opacity:disabled?0.4:1,
        transition:"all 0.15s", outline:"none", whiteSpace:"nowrap",
        boxShadow: accent&&hov ? "0 0 12px rgba(0,255,136,0.15)" : "none" }}>
      {icon && <span style={{ fontSize:fs+2 }}>{icon}</span>}
      {label}
    </button>
  );
}

// ── Input field ───────────────────────────────────────────────────────────────
function SysInput({ label, value, onChange, placeholder, area=false }) {
  const base = { width:"100%", background:"#060a06", border:"1px solid #0d1a0d",
    borderRadius:4, padding:"9px 12px", color:"#3a6a3a", fontSize:11, outline:"none",
    fontFamily:"'JetBrains Mono', monospace", letterSpacing:"0.02em", boxSizing:"border-box",
    resize:"none" };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <div style={{ fontSize:9, color:"#1a3a1a", fontFamily:"'JetBrains Mono', monospace",
        textTransform:"uppercase", letterSpacing:"0.08em" }}>{label}</div>}
      {area
        ? <textarea value={value} onChange={onChange} placeholder={placeholder} rows={3} style={base} />
        : <input    value={value} onChange={onChange} placeholder={placeholder}        style={base} />}
    </div>
  );
}

// ── Select field ──────────────────────────────────────────────────────────────
function SysSelect({ label, value, onChange, options }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <div style={{ fontSize:9, color:"#1a3a1a", fontFamily:"'JetBrains Mono', monospace",
        textTransform:"uppercase", letterSpacing:"0.08em" }}>{label}</div>}
      <select value={value} onChange={onChange}
        style={{ background:"#060a06", border:"1px solid #0d1a0d", borderRadius:4,
          padding:"9px 12px", color:"#3a6a3a", fontSize:11, outline:"none",
          fontFamily:"'JetBrains Mono', monospace", cursor:"pointer", width:"100%" }}>
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

// ── Backdrop modal wrapper ─────────────────────────────────────────────────────
function SysModal({ children, onClose, width=560 }) {
  return (
    <div onClick={e=>{ if(e.target===e.currentTarget) onClose(); }}
      style={{ position:"fixed", inset:0, zIndex:500,
        background:"rgba(0,6,0,0.92)", backdropFilter:"blur(16px)",
        display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}>
      <div style={{ width:"100%", maxWidth:width, background:"#060a06",
        border:"1px solid #0d2a0d", borderRadius:8, position:"relative", overflow:"hidden",
        boxShadow:"0 0 80px rgba(0,255,136,0.06), 0 40px 80px rgba(0,0,0,0.8)",
        animation:"sysModalIn 0.2s cubic-bezier(.4,0,.2,1)" }}>
        <Bracket size={12} color="#00ff8833" />
        {children}
      </div>
    </div>
  );
}

// ── Modal header ──────────────────────────────────────────────────────────────
function SysModalHeader({ title, subtitle, onClose }) {
  return (
    <div style={{ padding:"18px 22px", borderBottom:"1px solid #0d1a0d",
      display:"flex", justifyContent:"space-between", alignItems:"center" }}>
      <div>
        <div style={{ fontFamily:"'JetBrains Mono', monospace", fontWeight:700, color:"#00ff88",
          fontSize:12, letterSpacing:"0.08em", textTransform:"uppercase" }}>{title}</div>
        {subtitle && <div style={{ fontSize:10, color:"#1a3a1a", marginTop:2, fontFamily:"'JetBrains Mono', monospace" }}>{subtitle}</div>}
      </div>
      <button onClick={onClose}
        style={{ background:"transparent", border:"1px solid #0d1a0d", borderRadius:3,
          padding:"4px 8px", cursor:"pointer", color:"#1a3a1a", fontFamily:"'JetBrains Mono', monospace", fontSize:11 }}>✕</button>
    </div>
  );
}

Object.assign(window, {
  Scanlines, Bracket, HexId, SysTag, XpRing,
  StatMeter, SkillRow, TaskFlow, SysMd, PingBubble,
  SysBtn, SysInput, SysSelect, SysModal, SysModalHeader,
});
