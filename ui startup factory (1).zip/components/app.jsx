// ─── Main App ─────────────────────────────────────────────────────────────────

const { useState, useEffect, useRef, useCallback } = React;

const ROOMS_ALL_IDS = ["work_area","daily_room","pitch_arena","training_room","break_room","director_office"];

// ── Simulation tick ────────────────────────────────────────────────────────
function simTick(prev, addLog) {
  return prev.map(emp => {
    let e = { ...emp, skills: emp.skills.map(s=>({...s})), tasks: emp.tasks.map(t=>({...t})) };

    // Movement
    const wantsBreak = e.mood === "tired" || e.stress > 80;
    if (Math.random() > (wantsBreak ? 0.6 : 0.85)) {
      e.currentRoom = wantsBreak && Math.random() > 0.3
        ? "break_room"
        : ROOMS_ALL_IDS[Math.floor(Math.random() * ROOMS_ALL_IDS.length)];
    }

    // Energy / Stress
    if (e.currentRoom === "work_area") {
      e.energy = Math.max(0, e.energy - (Math.random()*5+2));
      e.stress  = Math.min(100, e.stress + (Math.random()*4+1));
    } else if (e.currentRoom === "break_room") {
      e.energy = Math.min(100, e.energy + 15);
      e.stress  = Math.max(0, e.stress - 20);
    } else {
      e.energy = Math.max(0, e.energy - 1);
      e.stress  = Math.max(0, e.stress - 5);
    }

    // Mood
    if      (e.stress > 80 || e.energy < 20) e.mood = "tired";
    else if (e.currentRoom === "break_room")  e.mood = e.energy > 80 ? "happy" : "social";
    else if (e.currentRoom === "work_area")   e.mood = "focused";
    else                                       e.mood = "social";

    // Work
    if (e.currentRoom === "work_area") {
      const idx = e.tasks.findIndex(t => {
        if (t.status === "done") return false;
        if (!t.dependencies?.length) return true;
        return t.dependencies.every(d => e.tasks.find(x=>x.id===d)?.status === "done");
      });
      if (idx !== -1) {
        const task = e.tasks[idx];
        task.status = "doing";
        const avg  = e.skills.reduce((a,s)=>a+s.level,0) / e.skills.length;
        const mood = { focused:1.3, happy:1.1, social:0.8, tired:0.4 }[e.mood] ?? 1;
        task.progress = Math.min((task.progress||0) + (5 + avg*1.5 + Math.random()*5)*mood, 100);
        if (task.progress >= 100) {
          task.status = "done";
          e.energy    = Math.min(100, e.energy + 10);
          e.stress    = Math.max(0, e.stress - 15);
          e.mood      = "happy";
          e.totalXp   = (e.totalXp||0) + 50 + Math.floor(avg*20);
          e.skillTokens = (e.skillTokens||0) + 20;
          const si = Math.floor(Math.random()*e.skills.length);
          const sk = e.skills[si];
          sk.xp += 150 + Math.random()*50;
          if (sk.xp >= sk.maxXp) {
            sk.level += 1; sk.xp -= sk.maxXp; sk.maxXp = Math.floor(sk.maxXp*1.8);
            addLog(`SKILL UP: ${e.name} → ${sk.name} Lv${sk.level}!`, "skill");
          }
          addLog(`${e.name} completed: ${task.label}`, "success");
        }
        e.tasks[idx] = task;
      }
    }

    // Training / Break XP
    if (["break_room","training_room"].includes(e.currentRoom) && Math.random()>0.4) {
      const si = Math.floor(Math.random()*e.skills.length);
      const sk = e.skills[si];
      const gain = e.currentRoom === "training_room" ? 60+Math.random()*40 : 15+Math.random()*10;
      sk.xp += gain;
      e.totalXp = (e.totalXp||0) + Math.floor(gain/3);
      if (sk.xp >= sk.maxXp) {
        sk.level+=1; sk.xp-=sk.maxXp; sk.maxXp=Math.floor(sk.maxXp*1.8);
        addLog(`LEVEL UP: ${e.name} learned ${sk.name} Lv${sk.level}`, "skill");
      }
    }

    // Refill tasks
    if (e.tasks.every(t=>t.status==="done") && Math.random()>0.8) {
      const id1=`t${Date.now()}_a`, id2=`t${Date.now()}_b`;
      e.tasks.push({ id:id1, label:TASK_POOL[Math.floor(Math.random()*TASK_POOL.length)], status:"todo", progress:0 });
      if (Math.random()>0.5) e.tasks.push({ id:id2, label:"Deploy "+TASK_POOL[Math.floor(Math.random()*TASK_POOL.length)].split(" ").pop(), status:"todo", progress:0, dependencies:[id1] });
    }

    return e;
  });
}

// ── Log Window ─────────────────────────────────────────────────────────────
function LogWindow({ logs, isOpen, setIsOpen }) {
  const endRef = useRef(null);
  useEffect(() => { if (endRef.current && isOpen) endRef.current.scrollTop = endRef.current.scrollHeight; }, [logs, isOpen]);
  const typeStyle = {
    success: { color: "#22c55e", bg: "rgba(34,197,94,0.07)", icon: "Check" },
    warning: { color: "#f59e0b", bg: "rgba(245,158,11,0.07)", icon: "Zap" },
    skill:   { color: "#a855f7", bg: "rgba(168,85,247,0.07)", icon: "Brain" },
    info:    { color: "#666",    bg: "transparent",           icon: "Activity" },
  };
  return (
    <div style={{ position: "fixed", bottom: 20, right: 20, zIndex: 300, width: isOpen ? 360 : "auto", display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
      {isOpen && (
        <div style={{ background: "rgba(8,8,8,0.97)", backdropFilter: "blur(16px)", border: "1px solid #1e1e1e",
          borderRadius: 16, width: "100%", marginBottom: 10, boxShadow: "0 8px 40px rgba(0,0,0,0.6)", overflow: "hidden" }}>
          <div style={{ padding: "12px 16px", borderBottom: "1px solid #1a1a1a", display: "flex",
            justifyContent: "space-between", alignItems: "center", background: "#0a0a0a" }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#ccc", display: "flex", alignItems: "center", gap: 8 }}>
              <Icon name="Activity" size={13} color="#3b82f6" /> System Logs
            </div>
            <button onClick={() => setIsOpen(false)} style={{ background: "transparent", border: "none", cursor: "pointer" }}>
              <Icon name="X" size={13} color="#555" />
            </button>
          </div>
          <div ref={endRef} style={{ maxHeight: 240, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 6 }}>
            {logs.length === 0
              ? <div style={{ textAlign: "center", color: "#333", fontSize: 11, padding: 16 }}>No events yet.</div>
              : logs.slice(-50).map(log => {
                  const ts = typeStyle[log.type] || typeStyle.info;
                  return (
                    <div key={log.id} style={{ display: "flex", gap: 8, padding: "7px 10px", background: ts.bg, borderRadius: 8, border: "1px solid rgba(255,255,255,0.03)" }}>
                      <Icon name={ts.icon} size={11} color={ts.color} style={{ marginTop: 1, flexShrink: 0 }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, color: ts.color === "#666" ? "#888" : ts.color, lineHeight: 1.5 }}>{log.msg}</div>
                        <div style={{ fontSize: 9, color: "#333", marginTop: 2 }}>{log.time}</div>
                      </div>
                    </div>
                  );
                })
            }
          </div>
        </div>
      )}
      <button onClick={() => setIsOpen(o => !o)}
        style={{ background: "#0f0f0f", border: "1px solid #2a2a2a", borderRadius: 12, padding: "9px 16px",
          color: "#ccc", fontSize: 11, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center",
          gap: 8, boxShadow: "0 4px 16px rgba(0,0,0,0.4)" }}>
        <Icon name="MessageSq" size={14} color="#3b82f6" />
        {isOpen ? "Close Logs" : "Activity Logs"}
        {!isOpen && logs.length > 0 && (
          <span style={{ background: "#3b82f6", color: "white", fontSize: 9, padding: "2px 6px", borderRadius: 8 }}>{logs.length}</span>
        )}
      </button>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────────
function App() {
  const [startups,        setStartups]        = useState(INITIAL_STARTUPS);
  const [employees,       setEmployees]       = useState(INITIAL_EMPLOYEES);
  const [selectedEmpId,   setSelectedEmpId]   = useState(null);
  const [selectedStartId, setSelectedStartId] = useState(null);
  const [roomTarget,      setRoomTarget]      = useState(null); // { roomId, room, startupContext, emps }
  const [hoveredSkill,    setHoveredSkill]    = useState(null);
  const [logs,            setLogs]            = useState([{ id:"init", time: new Date().toLocaleTimeString(), msg:"System online — simulation running", type:"info" }]);
  const [isLogOpen,       setIsLogOpen]       = useState(false);
  const [isMapLocked,     setIsMapLocked]     = useState(false);
  const [hubPos,          setHubPos]          = useState({ x:700, y:1200 });

  // Modals
  const [showAddStartup,  setShowAddStartup]  = useState(false);
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [coffeeMeeting,   setCoffeeMeeting]   = useState(null);
  const [pitchTarget,     setPitchTarget]     = useState(null);
  const [kanbanTarget,    setKanbanTarget]    = useState(null);
  const [pingResult,      setPingResult]      = useState(null);
  const [isPinging,       setIsPinging]       = useState(false);

  // Map viewport
  const [vp, setVp] = useState({ x:-200, y:-820, scale:0.52 });
  const mapRef    = useRef(null);
  const isPanning = useRef(false);
  const lastMouse = useRef({ x:0, y:0 });
  const nodeDrag  = useRef(null);

  const addLog = useCallback((msg, type="info") => {
    setLogs(p => [...p, { id: Date.now()+Math.random(), time: new Date().toLocaleTimeString(), msg, type }]);
  }, []);

  // ── Simulation ──────────────────────────────────────────────────────────────
  useEffect(() => {
    const iv = setInterval(() => setEmployees(prev => simTick(prev, addLog)), 4000);
    return () => clearInterval(iv);
  }, [addLog]);

  // ── Map wheel ───────────────────────────────────────────────────────────────
  const handleWheel = useCallback(e => {
    e.preventDefault();
    const d = e.deltaY < 0 ? 1.12 : 0.89;
    const rect = mapRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    setVp(v => {
      const ns = Math.max(0.12, Math.min(4, v.scale * d));
      return { scale:ns, x: mx - (mx-v.x)*(ns/v.scale), y: my - (my-v.y)*(ns/v.scale) };
    });
  }, []);
  useEffect(() => {
    const el = mapRef.current;
    if (!el) return;
    el.addEventListener("wheel", handleWheel, { passive:false });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [handleWheel]);

  const onMapMouseDown = e => {
    if (isMapLocked || e.target.closest("[data-nodedrag]")) return;
    isPanning.current = true;
    lastMouse.current = { x:e.clientX, y:e.clientY };
  };
  const onMapMouseMove = e => {
    if (nodeDrag.current) {
      const nd = nodeDrag.current, dx=(e.clientX-nd.startX)/vp.scale, dy=(e.clientY-nd.startY)/vp.scale;
      if (nd.type==="startup") setStartups(p=>p.map(s=>s.id===nd.id?{...s,position:{x:nd.initX+dx,y:nd.initY+dy}}:s));
      else setHubPos({ x:nd.initX+dx, y:nd.initY+dy });
      return;
    }
    if (!isPanning.current) return;
    const dx=e.clientX-lastMouse.current.x, dy=e.clientY-lastMouse.current.y;
    lastMouse.current={x:e.clientX,y:e.clientY};
    setVp(v=>({...v,x:v.x+dx,y:v.y+dy}));
  };
  const onMapMouseUp = () => { isPanning.current=false; nodeDrag.current=null; };

  const recenterAll = () => {
    const rect = mapRef.current?.getBoundingClientRect();
    if (!rect) return;
    const nodes = [...startups.map(s=>({x:s.position.x,y:s.position.y,w:580,h:480})), {x:hubPos.x,y:hubPos.y,w:760,h:640}];
    const minX=Math.min(...nodes.map(n=>n.x))-60, minY=Math.min(...nodes.map(n=>n.y))-60;
    const maxX=Math.max(...nodes.map(n=>n.x+n.w))+60, maxY=Math.max(...nodes.map(n=>n.y+n.h))+60;
    const ns=Math.max(0.12,Math.min(4,Math.min(rect.width/(maxX-minX),rect.height/(maxY-minY))));
    setVp({ scale:ns, x:-(minX+(maxX-minX)/2)*ns+rect.width/2, y:-(minY+(maxY-minY)/2)*ns+rect.height/2 });
  };

  // ── Handlers ────────────────────────────────────────────────────────────────
  const selectedEmp    = employees.find(e=>e.id===selectedEmpId);
  const selectedStart  = startups.find(s=>s.id===selectedStartId);

  const triggerCoffeeMeeting = () => {
    const byS = {};
    employees.forEach(e=>{ (byS[e.startupId]??=[]).push(e); });
    const ids = Object.keys(byS);
    if (ids.length < 2) { addLog("Need 2+ startups for a coffee meeting","warning"); return; }
    const picks = ids.slice(0,2).map(id=>byS[id][Math.floor(Math.random()*byS[id].length)]);
    setCoffeeMeeting(picks);
  };

  const pingAgent = async () => {
    if (!selectedEmp) return;
    setIsPinging(true); setPingResult(null);
    const startup = startups.find(s=>s.id===selectedEmp.startupId);
    let txt;
    if (window.claude) {
      try {
        txt = await window.claude.complete({ messages:[{ role:"user", content:
          `You are ${selectedEmp.name}, an AI agent (${selectedEmp.expertise}) at startup "${startup?.name}". Generate a realistic 2-sentence status update or office chatter. Be direct and technical.\nRoom: ${selectedEmp.currentRoom} | Mood: ${selectedEmp.mood} | Energy: ${Math.floor(selectedEmp.energy)}% | Tasks: ${selectedEmp.tasks.map(t=>t.label).join(", ")} | Skills: ${selectedEmp.skills.map(s=>`${s.name} Lv${s.level}`).join(", ")}`
        }]});
      } catch { txt = `Running at ${Math.floor(selectedEmp.energy)}% capacity on "${selectedEmp.tasks.find(t=>t.status==="doing")?.label||"idle"}". ${selectedEmp.mood === "tired" ? "Need a break soon." : "Making solid progress."}`; }
    } else {
      txt = `Running at ${Math.floor(selectedEmp.energy)}% capacity on "${selectedEmp.tasks.find(t=>t.status==="doing")?.label||"idle"}". ${selectedEmp.mood === "tired" ? "Need a break soon." : "Making solid progress."}`;
    }
    setPingResult(txt);
    setIsPinging(false);
  };

  const addStartup = (name, objective, repo) => {
    const n = { id:`s${Date.now()}`, name: name||"New Venture", logo:"🚀", objective:objective||"Build the future",
      githubRepo:repo||undefined, parameters:{funding:"Seed",stealth:false},
      position:{ x:200+startups.length*870, y:1200 }, weeklyScore:0,
      milestones:[
        {id:"m1",label:"Ideation & Validation",status:"completed"},
        {id:"m2",label:"MVP Development",status:"in-progress"},
        {id:"m3",label:"Growth & Scaling",status:"pending"},
        {id:"m4",label:objective||"Final Objective",status:"pending"},
      ]};
    setStartups(p=>[...p,n]);
    addLog(`Launched ${n.name}!`, "success");
  };

  const addEmployee = useCallback(data => {
    setEmployees(p=>[...p,data]);
    addLog(`${data.name} joined ${startups.find(s=>s.id===data.startupId)?.name}`, "info");
  }, [startups]);

  const removeEmployee = id => {
    setEmployees(p=>p.filter(e=>e.id!==id));
    if (selectedEmpId===id) setSelectedEmpId(null);
  };

  // ── Room renderer ──────────────────────────────────────────────────────────
  const renderRooms = (roomIds, layouts, filterFn, startupCtx) =>
    roomIds.map(roomId => {
      const room = ROOMS.find(r=>r.id===roomId);
      const layout = layouts[roomId];
      const emps = employees.filter(e=>e.currentRoom===roomId && filterFn(e));
      return (
        <div key={roomId}
          onClick={e => { e.stopPropagation(); setRoomTarget({roomId,room,startupContext:startupCtx,emps}); setSelectedEmpId(null); setSelectedStartId(null); }}
          style={{ position:"absolute", ...layout, background:"rgba(18,18,18,0.5)", border:"1px solid rgba(255,255,255,0.04)",
            borderRadius:10, overflow:"hidden", cursor:"pointer", transition:"background 0.2s" }}
          onMouseOver={e=>(e.currentTarget.style.background="rgba(28,28,28,0.8)")}
          onMouseOut={e=>(e.currentTarget.style.background="rgba(18,18,18,0.5)")}>
          <div style={{ position:"absolute", top:8, left:12, display:"flex", alignItems:"center", gap:5, opacity:0.6 }}>
            <RoomIcon id={roomId} size={9} color="#555" />
            <span style={{ fontSize:8, fontWeight:700, color:"#555", textTransform:"uppercase", letterSpacing:"0.06em" }}>{room.name}</span>
          </div>
          <div style={{ width:"100%", height:"100%", padding:"22px 10px 6px", display:"flex", flexWrap:"wrap", gap:8, alignItems:"flex-start", overflowY:"auto", boxSizing:"border-box" }}>
            {emps.map(emp => (
              <div key={emp.id} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:3, position:"relative" }}
                onClick={ev => { ev.stopPropagation(); setSelectedEmpId(emp.id); setSelectedStartId(null); setRoomTarget(null); }}>
                {/* Speech bubble */}
                <div style={{ position:"absolute", bottom:"100%", marginBottom:2, background:"rgba(15,15,15,0.95)",
                  border:"1px solid #1e1e1e", borderRadius:6, padding:"2px 6px", whiteSpace:"nowrap",
                  fontSize:7, color:"#ccc", maxWidth:80, overflow:"hidden", textOverflow:"ellipsis" }}>
                  {emp.tasks.find(t=>t.status==="doing")?.label.slice(0,18)||emp.mood}
                </div>
                <XpRing totalXp={emp.totalXp||0} size={38}>
                  <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:16, borderRadius:"50%", background:"#0a0a0a", position:"relative" }}>
                    {emp.avatar}
                    <div style={{ position:"absolute", bottom:0, right:0, width:8, height:8, borderRadius:"50%",
                      background: MOOD_COLOR[emp.mood]||"#666", border:"2px solid #0a0a0a" }} />
                  </div>
                </XpRing>
                <div style={{ fontSize:6, color:"#444", textAlign:"center", maxWidth:42, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {emp.name.split(" ")[0]}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    });

  // ─ Right panel ──────────────────────────────────────────────────────────────
  const renderRightPanel = () => {
    if (selectedEmp) {
      const level = getLevel(selectedEmp.totalXp||0);
      return (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          {/* Agent header */}
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              <XpRing totalXp={selectedEmp.totalXp||0} size={54}>
                <div style={{ width:"100%", height:"100%", display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:24, borderRadius:"50%", background:"#080808" }}>{selectedEmp.avatar}</div>
              </XpRing>
              <div>
                <div style={{ fontWeight:800, color:"#eee", fontSize:16, letterSpacing:"-0.02em" }}>{selectedEmp.name}</div>
                <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:4 }}>
                  <LevelBadge totalXp={selectedEmp.totalXp||0} />
                  <span style={{ fontSize:10, color:"#444" }}>{selectedEmp.expertise}</span>
                </div>
              </div>
            </div>
            <button onClick={() => setSelectedEmpId(null)} style={{ background:"transparent", border:"none", cursor:"pointer" }}>
              <Icon name="X" size={14} color="#444" />
            </button>
          </div>

          {/* XP + ST */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
            {[["Total XP", (selectedEmp.totalXp||0).toLocaleString(), "#22c55e"],
              ["Skill Tokens", selectedEmp.skillTokens||0, "#f59e0b"]].map(([label,val,color])=>(
              <div key={label} style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:10, padding:"10px 12px" }}>
                <div style={{ fontSize:16, fontWeight:800, color }}>{val}</div>
                <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.06em", marginTop:2 }}>{label}</div>
              </div>
            ))}
          </div>

          {/* Vitals */}
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <StatBar label="Energy" value={selectedEmp.energy} color="#22c55e" />
            <StatBar label="Stress" value={selectedEmp.stress} color="#ef4444" />
          </div>

          {/* Location + mood */}
          <div style={{ display:"flex", gap:8 }}>
            <div style={{ flex:1, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:10, padding:"8px 12px" }}>
              <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:4 }}>Location</div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <RoomIcon id={selectedEmp.currentRoom} size={11} color="#666" />
                <span style={{ fontSize:11, color:"#888" }}>{ROOMS.find(r=>r.id===selectedEmp.currentRoom)?.name||selectedEmp.currentRoom}</span>
              </div>
            </div>
            <div style={{ flex:1, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:10, padding:"8px 12px" }}>
              <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:4 }}>Mood</div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <div style={{ width:7, height:7, borderRadius:"50%", background:MOOD_COLOR[selectedEmp.mood]||"#666",
                  boxShadow:`0 0 6px ${MOOD_COLOR[selectedEmp.mood]||"#666"}` }} />
                <span style={{ fontSize:11, color:MOOD_COLOR[selectedEmp.mood]||"#888", textTransform:"capitalize" }}>{selectedEmp.mood}</span>
              </div>
            </div>
          </div>

          {/* Skills */}
          <div>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight:700, marginBottom:8 }}>Skill Progression</div>
            {selectedEmp.skills.map(skill => (
              <div key={skill.name} style={{ position:"relative", marginBottom:4 }}
                onMouseEnter={()=>setHoveredSkill(skill.name)}
                onMouseLeave={()=>setHoveredSkill(null)}>
                <SkillBar skill={skill} isHovered={hoveredSkill===skill.name} synergy={SKILL_SYNERGIES[hoveredSkill]} />
                {hoveredSkill===skill.name && SKILL_SYNERGIES[skill.name] && (
                  <div style={{ position:"absolute", top:"100%", left:0, zIndex:60, width:200,
                    background:"#111", border:"1px solid #2a2a2a", borderRadius:10, padding:14, boxShadow:"0 8px 32px rgba(0,0,0,0.7)" }}>
                    <div style={{ fontSize:9, color:"#818cf8", textTransform:"uppercase", letterSpacing:"0.06em", fontWeight:700, marginBottom:6 }}>Synergies</div>
                    <div style={{ fontSize:11, color:"#c7d2fe", marginBottom:4 }}>+: <strong>{SKILL_SYNERGIES[skill.name].skills.join(", ")}</strong></div>
                    <div style={{ fontSize:11, color:"#818cf8" }}>{SKILL_SYNERGIES[skill.name].effect}</div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Tasks */}
          <div>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight:700, marginBottom:8 }}>Task Flow</div>
            <div style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:10, padding:12 }}>
              <TaskFlowchart tasks={selectedEmp.tasks} />
            </div>
          </div>

          {/* Journal */}
          {selectedEmp.journal?.length > 0 && (
            <div style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:12, padding:14 }}>
              <div style={{ fontSize:9, color:"#555", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight:700, marginBottom:8, display:"flex", alignItems:"center", gap:6 }}>
                <Icon name="BookOpen" size={10} color="#666" /> Journal — Last Entry
              </div>
              <p style={{ fontSize:11, color:"#666", lineHeight:1.7, margin:0, fontStyle:"italic" }}>
                "{selectedEmp.journal[selectedEmp.journal.length-1]}"
              </p>
            </div>
          )}

          {/* Ping output */}
          {pingResult && (
            <div style={{ background:"rgba(8,145,178,0.06)", border:"1px solid rgba(8,145,178,0.2)", borderRadius:12, padding:14 }}>
              <div style={{ fontSize:9, color:"#0891b2", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight:700, marginBottom:6 }}>Neural Ping Output</div>
              <p style={{ fontSize:12, color:"#a5f3fc", lineHeight:1.65, margin:0 }}>"{pingResult}"</p>
            </div>
          )}

          {/* Actions */}
          <div style={{ display:"flex", gap:8, paddingTop:4 }}>
            <button onClick={pingAgent} disabled={isPinging}
              style={{ flex:1, background:"#0891b2", border:"1px solid rgba(255,255,255,0.08)", borderRadius:12, padding:14,
                color:"white", fontWeight:800, fontSize:10, letterSpacing:"0.06em", textTransform:"uppercase", cursor:"pointer",
                display:"flex", alignItems:"center", justifyContent:"center", gap:6, opacity:isPinging?0.5:1,
                boxShadow:"0 0 20px rgba(8,145,178,0.2)" }}>
              <Icon name="MessageSq" size={12} color="white" />
              {isPinging ? "Pinging…" : "Ping Agent"}
            </button>
            <button onClick={()=>removeEmployee(selectedEmp.id)}
              style={{ width:44, background:"#0a0a0a", border:"1px solid rgba(239,68,68,0.25)", borderRadius:12,
                display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
              <Icon name="X" size={14} color="#ef4444" />
            </button>
          </div>
        </div>
      );
    }

    if (roomTarget) {
      return (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              <div style={{ width:44, height:44, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:12,
                display:"flex", alignItems:"center", justifyContent:"center" }}>
                <RoomIcon id={roomTarget.roomId} size={20} color="#3b82f6" />
              </div>
              <div>
                <div style={{ fontWeight:800, color:"#eee", fontSize:15 }}>{roomTarget.room.name}</div>
                <div style={{ fontSize:10, color:"#444", marginTop:2 }}>{roomTarget.emps.length} agents present</div>
              </div>
            </div>
            <button onClick={()=>setRoomTarget(null)} style={{ background:"transparent", border:"none", cursor:"pointer" }}>
              <Icon name="X" size={14} color="#444" />
            </button>
          </div>
          {roomTarget.startupContext && (
            <div style={{ fontSize:10, color:"#555", background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:8, padding:"6px 12px" }}>
              {roomTarget.startupContext.logo} {roomTarget.startupContext.name}
            </div>
          )}
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {roomTarget.emps.length === 0
              ? <div style={{ textAlign:"center", color:"#2a2a2a", fontSize:11, padding:"32px 0" }}>Empty Room</div>
              : roomTarget.emps.map(emp => (
                <div key={emp.id} onClick={()=>{ setSelectedEmpId(emp.id); setRoomTarget(null); }}
                  style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:12, padding:14, cursor:"pointer",
                    transition:"border-color 0.2s" }}
                  onMouseOver={e=>e.currentTarget.style.borderColor="#2a2a2a"}
                  onMouseOut={e=>e.currentTarget.style.borderColor="#1a1a1a"}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    <div style={{ width:36, height:36, background:"#111", borderRadius:10,
                      display:"flex", alignItems:"center", justifyContent:"center", fontSize:18,
                      border:`1px solid ${LEVEL_COLORS[getLevel(emp.totalXp||0)]}44` }}>{emp.avatar}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:700, color:"#ddd", fontSize:12 }}>{emp.name}</div>
                      <div style={{ fontSize:10, color:"#555", textTransform:"uppercase", letterSpacing:"0.04em" }}>{emp.expertise}</div>
                    </div>
                    <div style={{ width:7, height:7, borderRadius:"50%", background:MOOD_COLOR[emp.mood]||"#666" }} />
                  </div>
                  {roomTarget.roomId==="work_area" && (() => {
                    const ct = emp.tasks.find(t=>t.status==="doing");
                    return ct ? (
                      <div style={{ marginTop:10 }}>
                        <div style={{ fontSize:10, color:"#555", marginBottom:4 }}>{ct.label}</div>
                        <div style={{ background:"#111", height:2, borderRadius:1, overflow:"hidden" }}>
                          <div style={{ height:"100%", background:"#3b82f6", width:`${ct.progress}%` }} />
                        </div>
                      </div>
                    ) : null;
                  })()}
                </div>
              ))
            }
          </div>
        </div>
      );
    }

    if (selectedStart) {
      const team = employees.filter(e=>e.startupId===selectedStart.id);
      return (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              <div style={{ width:52, height:52, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:14,
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:28 }}>{selectedStart.logo}</div>
              <div>
                <div style={{ fontWeight:800, color:"#eee", fontSize:16, letterSpacing:"-0.02em" }}>{selectedStart.name}</div>
                <div style={{ display:"flex", gap:6, marginTop:4, flexWrap:"wrap" }}>
                  <span style={{ fontSize:9, color:"#ccc", background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.12)",
                    borderRadius:4, padding:"2px 8px" }}>{selectedStart.parameters.funding} Stage</span>
                  {selectedStart.parameters.stealth && (
                    <span style={{ fontSize:9, color:"#888", background:"#111", border:"1px solid #222", borderRadius:4, padding:"2px 8px" }}>Stealth</span>
                  )}
                </div>
              </div>
            </div>
            <button onClick={()=>setSelectedStartId(null)} style={{ background:"transparent", border:"none", cursor:"pointer" }}>
              <Icon name="X" size={14} color="#444" />
            </button>
          </div>

          <div style={{ background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:12, padding:14 }}>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:6 }}>Core Objective</div>
            <p style={{ fontSize:12, color:"#666", lineHeight:1.7, margin:0 }}>{selectedStart.objective}</p>
          </div>

          {selectedStart.weeklyScore > 0 && (
            <div style={{ background:"#0c0a14", border:"1px solid #2a1a4a", borderRadius:12, padding:"10px 14px",
              display:"flex", alignItems:"center", gap:10 }}>
              <Icon name="Star" size={14} color="#a855f7" />
              <div>
                <div style={{ fontSize:14, fontWeight:800, color:"#c084fc" }}>{selectedStart.weeklyScore}/5.0</div>
                <div style={{ fontSize:9, color:"#555", textTransform:"uppercase", letterSpacing:"0.06em" }}>Weekly Score</div>
              </div>
            </div>
          )}

          {/* Team */}
          <div>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight:700, marginBottom:8 }}>Team ({team.length} agents)</div>
            <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
              {team.map(emp => {
                const level = getLevel(emp.totalXp||0);
                return (
                  <div key={emp.id} onClick={()=>{ setSelectedEmpId(emp.id); setSelectedStartId(null); }}
                    style={{ display:"flex", alignItems:"center", gap:10, background:"#0a0a0a", border:"1px solid #1a1a1a",
                      borderRadius:10, padding:"8px 12px", cursor:"pointer", transition:"border-color 0.2s" }}
                    onMouseOver={e=>e.currentTarget.style.borderColor="#2a2a2a"}
                    onMouseOut={e=>e.currentTarget.style.borderColor="#1a1a1a"}>
                    <div style={{ width:30, height:30, background:"#111", borderRadius:8,
                      display:"flex", alignItems:"center", justifyContent:"center", fontSize:14,
                      border:`1px solid ${LEVEL_COLORS[level]}44` }}>{emp.avatar}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:12, color:"#ccc", fontWeight:700 }}>{emp.name}</div>
                      <div style={{ fontSize:10, color:"#444" }}>{emp.expertise} · {LEVEL_NAMES[level]}</div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <div style={{ fontSize:10, color:"#f59e0b" }}>{emp.skillTokens||0} ST</div>
                      <div style={{ fontSize:10, color:MOOD_COLOR[emp.mood]||"#666" }}>{emp.mood}</div>
                    </div>
                  </div>
                );
              })}
              {team.length === 0 && <div style={{ fontSize:11, color:"#2a2a2a", textAlign:"center", padding:"16px 0" }}>No agents assigned</div>}
            </div>
          </div>

          {selectedStart.githubRepo && (
            <div style={{ display:"flex", alignItems:"center", gap:10, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:10, padding:"10px 14px" }}>
              <Icon name="Github" size={14} color="#666" />
              <span style={{ fontSize:11, color:"#888", fontFamily:"monospace" }}>{selectedStart.githubRepo}</span>
            </div>
          )}

          {/* Actions */}
          <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginTop:"auto" }}>
            <button onClick={()=>setPitchTarget(selectedStart)}
              style={{ flex:1, minWidth:80, background:"#0c0a14", border:"1px solid #2a1a4a", borderRadius:12, padding:12,
                color:"#a5b4fc", fontWeight:700, fontSize:10, cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em",
                display:"flex", alignItems:"center", justifyContent:"center", gap:6 }}>
              <Icon name="Presentation" size={11} color="#818cf8" /> Evaluate
            </button>
            <button onClick={()=>setKanbanTarget(selectedStart)}
              style={{ flex:1, minWidth:80, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:12, padding:12,
                color:"#888", fontWeight:700, fontSize:10, cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em",
                display:"flex", alignItems:"center", justifyContent:"center", gap:6 }}>
              <Icon name="Layout" size={11} color="#888" /> Kanban
            </button>
            <button onClick={()=>setShowAddEmployee(true)}
              style={{ flex:1, minWidth:80, background:"#0891b2", border:"1px solid rgba(255,255,255,0.08)", borderRadius:12, padding:12,
                color:"white", fontWeight:800, fontSize:10, cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em",
                display:"flex", alignItems:"center", justifyContent:"center", gap:6,
                boxShadow:"0 0 16px rgba(8,145,178,0.2)" }}>
              <Icon name="Plus" size={11} color="white" /> Add Agent
            </button>
          </div>
        </div>
      );
    }

    return (
      <div style={{ height:"100%", border:"1px dashed #1a1a1a", borderRadius:14, display:"flex",
        flexDirection:"column", alignItems:"center", justifyContent:"center", padding:24, textAlign:"center" }}>
        <div style={{ width:48, height:48, background:"#0a0a0a", border:"1px solid #1a1a1a", borderRadius:14,
          display:"flex", alignItems:"center", justifyContent:"center", marginBottom:14, opacity:0.4 }}>
          <Icon name="Users" size={22} color="#444" />
        </div>
        <div style={{ fontSize:10, fontWeight:700, color:"#333", textTransform:"uppercase", letterSpacing:"0.12em" }}>Data Standby</div>
        <p style={{ fontSize:10, color:"#222", marginTop:8, lineHeight:1.7, textTransform:"uppercase", letterSpacing:"0.04em" }}>Click an agent or startup<br/>to monitor</p>
      </div>
    );
  };

  // ── Main render ──────────────────────────────────────────────────────────────
  const totalXP  = employees.reduce((a,e)=>a+(e.totalXp||0),0);
  const totalST  = employees.reduce((a,e)=>a+(e.skillTokens||0),0);
  const lastLog  = logs[logs.length-1];

  return (
    <div style={{ minHeight:"100vh", background:"#060606", color:"#888", overflow:"hidden", position:"relative", fontFamily:"'Space Grotesk', 'IBM Plex Mono', sans-serif" }}>

      {/* ── Header ── */}
      <header style={{ height:58, borderBottom:"1px solid #111", display:"flex", alignItems:"center",
        justifyContent:"space-between", padding:"0 20px", background:"rgba(6,6,6,0.96)",
        backdropFilter:"blur(20px)", position:"fixed", top:10, left:10, right:10,
        borderRadius:16, zIndex:50, border:"1px solid #1a1a1a", boxShadow:"0 4px 24px rgba(0,0,0,0.5)" }}>
        {/* Logo */}
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <div style={{ width:36, height:36, background:"#fff", borderRadius:10,
            display:"flex", alignItems:"center", justifyContent:"center" }}>
            <Icon name="BrainCircuit" size={18} color="black" />
          </div>
          <div>
            <div style={{ fontWeight:900, color:"#f0f0f0", letterSpacing:"0.04em", textTransform:"uppercase", fontSize:13 }}>Studio_IA</div>
            <div style={{ fontSize:9, color:"#333", letterSpacing:"0.16em" }}>SIMULATION ENGINE ACTIVE</div>
          </div>
        </div>

        {/* Live ticker */}
        <div style={{ display:"flex", alignItems:"center", gap:8, background:"#0a0a0a",
          border:"1px solid #1a1a1a", padding:"6px 14px", borderRadius:10, maxWidth:360, overflow:"hidden" }}>
          <div style={{ width:6, height:6, background:"#22c55e", borderRadius:"50%", flexShrink:0,
            boxShadow:"0 0 6px #22c55e", animation:"statusPulse 2s infinite" }} />
          <span style={{ fontSize:10, fontWeight:600, color:"#555", letterSpacing:"0.04em", whiteSpace:"nowrap",
            overflow:"hidden", textOverflow:"ellipsis" }}>
            {lastLog ? lastLog.msg : "System online"}
          </span>
        </div>

        {/* Actions */}
        <div style={{ display:"flex", gap:8 }}>
          <button onClick={triggerCoffeeMeeting}
            style={{ display:"flex", alignItems:"center", gap:6, background:"#0a0a0a", border:"1px solid #1e1e1e",
              borderRadius:10, padding:"8px 14px", color:"#777", fontSize:10, fontWeight:700, cursor:"pointer",
              letterSpacing:"0.06em", textTransform:"uppercase" }}>
            <Icon name="Coffee" size={12} color="#888" /> Coffee Break
          </button>
          <button onClick={()=>setShowAddStartup(true)}
            style={{ display:"flex", alignItems:"center", gap:6, background:"#0891b2", border:"1px solid rgba(255,255,255,0.08)",
              borderRadius:10, padding:"8px 16px", color:"white", fontSize:10, fontWeight:900, cursor:"pointer",
              letterSpacing:"0.06em", textTransform:"uppercase", boxShadow:"0 0 16px rgba(8,145,178,0.25)" }}>
            <Icon name="Plus" size={12} color="white" /> Register Startup
          </button>
        </div>
      </header>

      {/* ── Main layout ── */}
      <main style={{ paddingTop:80, paddingBottom:12, paddingLeft:12, paddingRight:12,
        display:"grid", gridTemplateColumns:"268px 1fr 296px", gap:12, height:"100vh", boxSizing:"border-box" }}>

        {/* ── LEFT: startups + metrics ── */}
        <div style={{ display:"flex", flexDirection:"column", height:"100%", overflow:"hidden", gap:10 }}>
          <div style={{ fontSize:9, fontWeight:700, color:"#333", letterSpacing:"0.14em", textTransform:"uppercase", padding:"0 2px" }}>
            Active Ventures ({startups.length})
          </div>

          <div style={{ flex:1, overflowY:"auto", display:"flex", flexDirection:"column", gap:8 }}>
            {startups.map(startup => {
              const team = employees.filter(e=>e.startupId===startup.id);
              const sel  = selectedStartId===startup.id;
              return (
                <div key={startup.id} onClick={()=>{ setSelectedStartId(startup.id); setSelectedEmpId(null); setRoomTarget(null); }}
                  style={{ background:"#0a0a0a", border:`1px solid ${sel?"#2a2a2a":"#111"}`, padding:18, borderRadius:18,
                    cursor:"pointer", boxShadow:sel?"0 0 0 1px #2a2a2a, 0 0 20px rgba(255,255,255,0.03)":"none",
                    transition:"all 0.2s" }}
                  onMouseOver={e=>!sel&&(e.currentTarget.style.borderColor="#1e1e1e")}
                  onMouseOut={e=>!sel&&(e.currentTarget.style.borderColor="#111")}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <div style={{ width:36, height:36, background:"#111", border:"1px solid #1a1a1a",
                        borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>
                        {startup.logo}
                      </div>
                      <div>
                        <div style={{ fontWeight:700, color:"#ddd", fontSize:13 }}>{startup.name}</div>
                        <div style={{ fontSize:9, color:"#333", letterSpacing:"0.04em", marginTop:1 }}>
                          {startup.parameters.funding.toUpperCase()}{startup.parameters.stealth?" · STEALTH":""}
                        </div>
                      </div>
                    </div>
                    <button onClick={e=>{ e.stopPropagation(); setShowAddEmployee(true); setSelectedStartId(startup.id); }}
                      style={{ width:26, height:26, background:"#111", border:"1px solid #1a1a1a", borderRadius:7,
                        display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
                      <Icon name="Plus" size={11} color="#555" />
                    </button>
                  </div>
                  <p style={{ fontSize:10, color:"#444", margin:"0 0 10px", overflow:"hidden",
                    display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical" }}>{startup.objective}</p>
                  <div style={{ display:"flex", gap:4, marginBottom:8 }}>
                    {team.slice(0,5).map(e=>(
                      <div key={e.id} style={{ width:20, height:20, background:"#111", borderRadius:5,
                        display:"flex", alignItems:"center", justifyContent:"center", fontSize:11,
                        border:`1px solid ${MOOD_COLOR[e.mood]||"#1a1a1a"}44` }}>{e.avatar}</div>
                    ))}
                    {team.length>5 && <div style={{ width:20, height:20, background:"#111", borderRadius:5,
                      display:"flex", alignItems:"center", justifyContent:"center", fontSize:9, color:"#444",
                      border:"1px solid #1a1a1a" }}>+{team.length-5}</div>}
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{ flex:1, background:"#0d0d0d", height:2, borderRadius:1, overflow:"hidden" }}>
                      <div style={{ background:"#2a2a2a", height:"100%", width:"65%", boxShadow:"0 0 4px #3a3a3a" }} />
                    </div>
                    {startup.weeklyScore>0 && (
                      <div style={{ fontSize:9, color:"#a855f7", background:"#a855f711", border:"1px solid #a855f733", borderRadius:5, padding:"1px 6px" }}>
                        ★ {startup.weeklyScore}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Global metrics */}
          <div style={{ background:"#0a0a0a", border:"1px solid #111", borderRadius:14, padding:18 }}>
            <div style={{ fontSize:9, color:"#333", letterSpacing:"0.14em", textTransform:"uppercase", marginBottom:12 }}>Global_Metrics</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>
              {[["Agents",employees.length,"#eee"],["Startups",startups.length,"#a855f7"],
                ["Total XP",totalXP.toLocaleString(),"#22c55e"],["Total ST",totalST,"#f59e0b"]].map(([label,val,color])=>(
                <div key={label} style={{ background:"#070707", border:"1px solid #111", borderRadius:10, padding:"8px 10px", textAlign:"center" }}>
                  <div style={{ fontSize:14, fontWeight:900, color }}>{val}</div>
                  <div style={{ fontSize:8, color:"#333", textTransform:"uppercase", letterSpacing:"0.06em", marginTop:2 }}>{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── CENTER: Map canvas ── */}
        <div ref={mapRef}
          style={{ background:"rgba(4,8,12,0.6)", border:"1px solid #111", borderRadius:24, position:"relative",
            overflow:"hidden", cursor:isMapLocked?"default":isPanning.current?"grabbing":"grab" }}
          onMouseDown={onMapMouseDown} onMouseMove={onMapMouseMove}
          onMouseUp={onMapMouseUp}   onMouseLeave={onMapMouseUp}>

          {/* Map controls */}
          <div style={{ position:"absolute", top:12, right:12, zIndex:20, display:"flex", flexDirection:"column", gap:5 }}>
            {[["ZoomIn",()=>setVp(v=>({...v,scale:Math.min(4,v.scale*1.2)}))],
              ["ZoomOut",()=>setVp(v=>({...v,scale:Math.max(0.12,v.scale/1.2)}))],
              ["Locate",recenterAll],
              [isMapLocked?"Lock":"Unlock",()=>setIsMapLocked(l=>!l)]
            ].map(([icon,action],i)=>(
              <button key={i} onClick={action}
                style={{ width:34, height:34, background: i===3&&isMapLocked?"rgba(245,158,11,0.12)":"#0a0a0a",
                  border:`1px solid ${i===3&&isMapLocked?"#f59e0b":"#1a1a1a"}`,
                  borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center",
                  cursor:"pointer", color: i===3&&isMapLocked?"#f59e0b":"#555" }}>
                <Icon name={icon} size={14} color={i===3&&isMapLocked?"#f59e0b":"#555"} />
              </button>
            ))}
          </div>

          {/* Canvas world */}
          <div style={{ width:4000, height:4000, position:"absolute",
            transform:`translate(${vp.x}px,${vp.y}px) scale(${vp.scale})`, transformOrigin:"0 0" }}>
            {/* Dot grid */}
            <div style={{ position:"absolute", inset:0, pointerEvents:"none",
              backgroundImage:"radial-gradient(#1a1a1a 1px,transparent 1px)", backgroundSize:"48px 48px", opacity:0.7 }} />

            {/* Connection lines startup → hub */}
            <svg style={{ position:"absolute", inset:0, pointerEvents:"none", overflow:"visible" }}>
              {startups.map(s=>(
                <line key={s.id}
                  x1={s.position.x+290} y1={s.position.y+240}
                  x2={hubPos.x+380}    y2={hubPos.y+320}
                  stroke="#1a2a1a" strokeWidth="2" strokeDasharray="8,8" opacity="0.5" />
              ))}
            </svg>

            {/* Startup nodes */}
            {startups.map(startup=>(
              <div key={startup.id} data-nodedrag="1"
                style={{ position:"absolute", left:startup.position.x, top:startup.position.y,
                  width:580, height:480, background:"rgba(8,8,8,0.9)", backdropFilter:"blur(8px)",
                  border:`1px solid ${selectedStartId===startup.id?"#2a2a2a":"rgba(30,30,30,0.8)"}`,
                  borderRadius:28, overflow:"hidden",
                  boxShadow:selectedStartId===startup.id?"0 0 40px rgba(255,255,255,0.03)":"none" }}>
                {/* Node header */}
                <div style={{ height:56, background:"rgba(4,8,12,0.95)", borderBottom:"1px solid #111",
                  display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 18px",
                  cursor:"grab", userSelect:"none" }}
                  onClick={()=>{ setSelectedStartId(startup.id); setSelectedEmpId(null); setRoomTarget(null); }}
                  onPointerDown={e=>{ e.stopPropagation();
                    nodeDrag.current={type:"startup",id:startup.id,startX:e.clientX,startY:e.clientY,initX:startup.position.x,initY:startup.position.y};
                    e.currentTarget.setPointerCapture(e.pointerId); }}
                  onPointerMove={e=>{ if(!nodeDrag.current||nodeDrag.current.id!==startup.id) return; e.stopPropagation();
                    const dx=(e.clientX-nodeDrag.current.startX)/vp.scale, dy=(e.clientY-nodeDrag.current.startY)/vp.scale;
                    setStartups(p=>p.map(s=>s.id===startup.id?{...s,position:{x:nodeDrag.current.initX+dx,y:nodeDrag.current.initY+dy}}:s)); }}
                  onPointerUp={()=>{ nodeDrag.current=null; }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    <span style={{ fontSize:20 }}>{startup.logo}</span>
                    <div>
                      <div style={{ fontWeight:800, color:"#eee", fontSize:13, letterSpacing:"-0.01em" }}>{startup.name}</div>
                      <div style={{ fontSize:8, color:"#333", letterSpacing:"0.08em" }}>{startup.parameters.funding.toUpperCase()}</div>
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:6 }}>
                    <button onClick={e=>{e.stopPropagation();setKanbanTarget(startup);}}
                      style={{ background:"#111", border:"1px solid #1e1e1e", borderRadius:7, padding:"4px 8px",
                        fontSize:8, color:"#555", cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em" }}>Kanban</button>
                    <button onClick={e=>{e.stopPropagation();setPitchTarget(startup);}}
                      style={{ background:"#111", border:"1px solid #2a1a4a", borderRadius:7, padding:"4px 8px",
                        fontSize:8, color:"#818cf8", cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em" }}>Evaluate</button>
                  </div>
                </div>
                {/* Rooms */}
                <div style={{ position:"relative", width:"100%", height:"calc(100% - 56px)" }}>
                  {renderRooms(["work_area","daily_room"], STARTUP_ROOM_LAYOUTS, e=>e.startupId===startup.id, startup)}
                </div>
              </div>
            ))}

            {/* Incubator Hub */}
            <div data-nodedrag="1"
              style={{ position:"absolute", left:hubPos.x, top:hubPos.y, width:760, height:640,
                background:"rgba(6,6,6,0.92)", backdropFilter:"blur(8px)",
                border:"1px solid rgba(20,30,20,0.9)", borderRadius:28, overflow:"hidden" }}>
              <div style={{ height:56, background:"rgba(2,6,4,0.97)", borderBottom:"1px solid #0d1a0d",
                display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 18px",
                cursor:"grab", userSelect:"none" }}
                onPointerDown={e=>{ e.stopPropagation();
                  nodeDrag.current={type:"hub",startX:e.clientX,startY:e.clientY,initX:hubPos.x,initY:hubPos.y};
                  e.currentTarget.setPointerCapture(e.pointerId); }}
                onPointerMove={e=>{ if(!nodeDrag.current||nodeDrag.current.type!=="hub") return; e.stopPropagation();
                  const dx=(e.clientX-nodeDrag.current.startX)/vp.scale, dy=(e.clientY-nodeDrag.current.startY)/vp.scale;
                  setHubPos({x:nodeDrag.current.initX+dx,y:nodeDrag.current.initY+dy}); }}
                onPointerUp={()=>{ nodeDrag.current=null; }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:18 }}>🏢</span>
                  <div>
                    <div style={{ fontWeight:800, color:"#eee", fontSize:13, letterSpacing:"-0.01em" }}>The Pépinière</div>
                    <div style={{ fontSize:8, color:"#2a3a2a", letterSpacing:"0.08em" }}>INCUBATOR HUB</div>
                  </div>
                </div>
                <button onClick={triggerCoffeeMeeting}
                  style={{ background:"#0a110a", border:"1px solid #1a2a1a", borderRadius:7, padding:"4px 10px",
                    fontSize:8, color:"#4a7a4a", cursor:"pointer", textTransform:"uppercase", letterSpacing:"0.04em",
                    display:"flex", alignItems:"center", gap:4 }}>
                  <Icon name="Coffee" size={9} color="#4a7a4a" /> Coffee Meet
                </button>
              </div>
              <div style={{ position:"relative", width:"100%", height:"calc(100% - 56px)" }}>
                {renderRooms(["pitch_arena","training_room","break_room","director_office"],
                  INCUBATOR_ROOM_LAYOUTS, ()=>true, null)}
              </div>
            </div>
          </div>
        </div>

        {/* ── RIGHT: Inspector panel ── */}
        <div style={{ height:"100%", overflowY:"auto", background:"#0a0a0a", border:"1px solid #111",
          borderRadius:20, padding:20, boxSizing:"border-box" }}>
          {renderRightPanel()}
        </div>
      </main>

      {/* ── Log window ── */}
      <LogWindow logs={logs} isOpen={isLogOpen} setIsOpen={setIsLogOpen} />

      {/* ── Modals ── */}
      {showAddStartup  && <AddStartupModal  onAdd={addStartup}  onClose={()=>setShowAddStartup(false)} />}
      {showAddEmployee && <AddEmployeeModal startups={startups} onAdd={addEmployee} onClose={()=>setShowAddEmployee(false)} />}
      {coffeeMeeting   && (
        <CoffeeMeetingModal agents={coffeeMeeting} startups={startups}
          onClose={()=>{ setCoffeeMeeting(null);
            setEmployees(p=>p.map(e=>coffeeMeeting.find(a=>a.id===e.id)?{...e,totalXp:(e.totalXp||0)+30,skillTokens:(e.skillTokens||0)+15}:e)); }} />
      )}
      {pitchTarget   && <PitchFeedbackModal startup={pitchTarget}  onClose={()=>setPitchTarget(null)} />}
      {kanbanTarget  && <KanbanModal startup={kanbanTarget} employees={employees} setEmployees={setEmployees} onClose={()=>setKanbanTarget(null)} />}

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#060606;overflow:hidden;}
        ::-webkit-scrollbar{width:3px;height:3px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:#1e1e1e;border-radius:4px;}
        ::-webkit-scrollbar-thumb:hover{background:#2a2a2a;}
        select option{background:#0f0f0f;color:#ddd;}
        @keyframes statusPulse{0%,100%{opacity:1}50%{opacity:0.4}}
        @keyframes milePulse{0%,100%{transform:scale(1)}50%{transform:scale(1.4)}}
      `}</style>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
