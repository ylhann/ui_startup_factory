// ─── Constants & Initial Data ─────────────────────────────────────────────────

const LEVEL_NAMES = ["Intern", "Junior", "Confirmed", "Senior", "Expert", "Principal"];
const LEVEL_COLORS = ["#666666", "#ffffff", "#22c55e", "#f59e0b", "#a855f7", "#ef4444"];
const LEVEL_XP = [0, 500, 2000, 6000, 15000, 40000];

function getLevel(totalXp) {
  for (let i = LEVEL_XP.length - 1; i >= 0; i--) {
    if (totalXp >= LEVEL_XP[i]) return i;
  }
  return 0;
}

const ROOMS = [
  { id: "work_area", name: "Work Area", icon: "Laptop" },
  { id: "daily_room", name: "Daily Standup", icon: "Users" },
  { id: "pitch_arena", name: "Pitch Arena", icon: "Presentation" },
  { id: "training_room", name: "Training Room", icon: "Brain" },
  { id: "break_room", name: "Break Room", icon: "Coffee" },
  { id: "director_office", name: "Director Office", icon: "Briefcase" },
];

const STARTUP_ROOM_LAYOUTS = {
  work_area:  { left: "4%",  top: "4%",  width: "44%", height: "92%" },
  daily_room: { left: "52%", top: "4%",  width: "44%", height: "92%" },
};
const INCUBATOR_ROOM_LAYOUTS = {
  pitch_arena:     { left: "4%",  top: "4%",  width: "44%", height: "44%" },
  training_room:   { left: "52%", top: "4%",  width: "44%", height: "44%" },
  break_room:      { left: "4%",  top: "52%", width: "44%", height: "44%" },
  director_office: { left: "52%", top: "52%", width: "44%", height: "44%" },
};

const SKILL_SYNERGIES = {
  PyTorch:       { skills: ["LLM Alignment", "K8s", "GCP"],           effect: "+15% AI Training Speed" },
  Rust:          { skills: ["K8s", "Terraform", "Backend"],           effect: "Zero Memory Leaks, +20% Stability" },
  "LLM Alignment": { skills: ["PyTorch", "Social Eng"],              effect: "Safe AI Outputs, B2B contracts" },
  Figma:         { skills: ["WebGL", "CSS", "Social Eng"],            effect: "+30% Client Conversion Rate" },
  WebGL:         { skills: ["Figma", "Rust"],                         effect: "GPU-Accelerated 3D UI enabled" },
  "Social Eng":  { skills: ["LLM Alignment", "Figma"],               effect: "Viral loop potential acquired" },
  K8s:           { skills: ["GCP", "Terraform", "Rust"],             effect: "Auto-scaling (+50% Task Bandwidth)" },
  GCP:           { skills: ["K8s", "Terraform"],                      effect: "Cloud costs -40%" },
  Terraform:     { skills: ["GCP", "K8s"],                           effect: "1-Click Multi-Cloud Deployments" },
};

const TASK_POOL = [
  "Debug regression in production", "Upgrade server cluster", "Cross-team synergy sync",
  "Write API documentation", "Refactor legacy modules", "Optimize neural weights",
  "Implement caching layer", "Deploy canary release", "Write unit tests",
  "Security audit pass", "Review PR from teammate", "Brainstorm next feature sprint",
];

const EXPERTISE_OPTS = ["AI", "Design", "DevOps", "Frontend", "Backend", "Security", "Research", "Product", "Data"];
const AVATAR_POOL = ["🤖", "🎨", "☁️", "🔬", "⚙️", "🛡️", "📊", "🎯", "🧠", "💡", "🔧", "🚀"];

const MOOD_COLOR = { focused: "#ededed", happy: "#22c55e", social: "#a855f7", tired: "#ef4444" };

const INITIAL_STARTUPS = [
  {
    id: "s1", name: "NeuralFlow", logo: "⚡",
    objective: "Build a decentralized AI training network",
    githubRepo: "neuralflow-labs/core",
    parameters: { stealth: false, funding: "Seed" },
    position: { x: 200, y: 1200 }, weeklyScore: 4.2,
    milestones: [
      { id: "m1", label: "Core Protocol Design", status: "completed" },
      { id: "m2", label: "Seed Funding Round", status: "in-progress" },
      { id: "m3", label: "Beta Testnet Launch", status: "pending" },
      { id: "m4", label: "Decentralized AI Network Live", status: "pending" },
    ],
  },
  {
    id: "s2", name: "EcoSynth", logo: "🌱",
    objective: "AI-driven carbon sequestration monitoring",
    githubRepo: "ecosynth-org/monitor",
    parameters: { stealth: true, funding: "Bootstrap" },
    position: { x: 1050, y: 1200 }, weeklyScore: 3.8,
    milestones: [
      { id: "m1", label: "Sensor Prototype", status: "completed" },
      { id: "m2", label: "Data Pipeline Setup", status: "completed" },
      { id: "m3", label: "AI Model Training", status: "in-progress" },
      { id: "m4", label: "Carbon Sequestration SaaS", status: "pending" },
    ],
  },
];

const INITIAL_EMPLOYEES = [
  {
    id: "e1", name: "Alex AI", avatar: "🤖", expertise: "AI", startupId: "s1",
    currentRoom: "work_area", mood: "focused", energy: 90, stress: 20, experience: 5,
    totalXp: 2847, skillTokens: 340,
    skills: [
      { name: "PyTorch", level: 3, xp: 450, maxXp: 1000 },
      { name: "Rust", level: 2, xp: 200, maxXp: 500 },
      { name: "LLM Alignment", level: 4, xp: 800, maxXp: 2000 },
    ],
    tasks: [
      { id: "t1", label: "Optimize weight quantization", status: "doing", progress: 45 },
      { id: "t2", label: "Draft ethics guidelines", status: "todo", progress: 0, dependencies: ["t1"] },
      { id: "t2b", label: "Publish Model Card", status: "todo", progress: 0, dependencies: ["t2"] },
    ],
    journal: ["Started quantization task. Key challenge: keeping accuracy above 95% after int8 conversion."],
  },
  {
    id: "e2", name: "Sam Design", avatar: "🎨", expertise: "Design", startupId: "s1",
    currentRoom: "break_room", mood: "social", energy: 100, stress: 0, experience: 3,
    totalXp: 1240, skillTokens: 180,
    skills: [
      { name: "Figma", level: 4, xp: 1200, maxXp: 2000 },
      { name: "WebGL", level: 1, xp: 50, maxXp: 200 },
      { name: "Social Eng", level: 2, xp: 100, maxXp: 500 },
    ],
    tasks: [
      { id: "t3", label: "Design node visualization UI", status: "doing", progress: 12 },
    ],
    journal: ["Break room sparks ideas. Got inspired by the hub layout for the node viz."],
  },
  {
    id: "e3", name: "Casey Cloud", avatar: "☁️", expertise: "DevOps", startupId: "s2",
    currentRoom: "work_area", mood: "tired", energy: 15, stress: 85, experience: 4,
    totalXp: 4100, skillTokens: 510,
    skills: [
      { name: "K8s", level: 3, xp: 300, maxXp: 1000 },
      { name: "GCP", level: 3, xp: 600, maxXp: 1000 },
      { name: "Terraform", level: 4, xp: 1500, maxXp: 2000 },
    ],
    tasks: [
      { id: "t4", label: "Deploy monitoring cluster", status: "done", progress: 100 },
    ],
    journal: ["Cluster finally up. 6h of debugging — K8s + Terraform combo works perfectly."],
  },
];

Object.assign(window, {
  LEVEL_NAMES, LEVEL_COLORS, LEVEL_XP, getLevel,
  ROOMS, STARTUP_ROOM_LAYOUTS, INCUBATOR_ROOM_LAYOUTS,
  SKILL_SYNERGIES, TASK_POOL, EXPERTISE_OPTS, AVATAR_POOL,
  MOOD_COLOR, INITIAL_STARTUPS, INITIAL_EMPLOYEES,
});
