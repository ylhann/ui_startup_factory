// ─── Shared UI Components ─────────────────────────────────────────────────────
// Depends on: window globals from data.jsx

const { useState, useEffect, useRef, useCallback } = React;

// ─── Icons (inline SVG, minimal) ─────────────────────────────────────────────
function Icon({ name, size = 16, color = "currentColor", style: extraStyle = {} }) {
  const paths = {
    X:            "M18 6L6 18M6 6l12 12",
    Plus:         "M12 5v14M5 12h14",
    Users:        "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75",
    Coffee:       "M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8zM6 1v3M10 1v3M14 1v3",
    Laptop:       "M2 20h20M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z",
    Presentation: "M2 3h20v14H2zM8 21l4-4 4 4M12 17v-4",
    Brain:        "M9.5 2A6.5 6.5 0 0 1 16 8.5c0 2.5-1.5 4.5-3 5.5v2a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-2c-1.5-1-3-3-3-5.5A6.5 6.5 0 0 1 9.5 2zM6 14H4a2 2 0 0 0 0 4h1M18 14h2a2 2 0 0 1 0 4h-1",
    Briefcase:    "M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",
    ZoomIn:       "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35M11 8v6M8 11h6",
    ZoomOut:      "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.35-4.35M8 11h6",
    Locate:       "M3 12h4M17 12h4M12 3v4M12 17v4M12 12m-2 0a2 2 0 1 0 4 0 2 2 0 0 0-4 0",
    Lock:         "M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2zM7 11V7a5 5 0 0 1 10 0v4",
    Unlock:       "M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2zM7 11V7a5 5 0 1 1 9.9-1",
    Github:       "M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22",
    MessageSq:    "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
    Activity:     "M22 12h-4l-3 9L9 3l-3 9H2",
    Sparkles:     "M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5zM5 3l.75 2.25L8 6l-2.25.75L5 9l-.75-2.25L2 6l2.25-.75zM19 15l.75 2.25L22 18l-2.25.75L19 21l-.75-2.25L16 18l2.25-.75z",
    Check:        "M20 6L9 17l-5-5",
    TrendingUp:   "M23 6l-9.5 9.5-5-5L1 18M17 6h6v6",
    ChevronR:     "M9 18l6-6-6-6",
    Zap:          "M13 2L3 14h9l-1 8 10-12h-9l1-8z",
    AlertTri:     "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01",
    Star:         "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
    BookOpen:     "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",
    Layout:       "M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM3 9h18M9 21V9",
    BrainCircuit: "M12 4a4 4 0 0 1 4 4M8 4a4 4 0 0 0 0 8h8a4 4 0 0 0 0-8M6 20h.01M10 20h.01M14 20h.01M18 20h.01M6 16v4M10 16v4M14 16v4M18 16v4M8 12v4M12 12v4M16 12v4",
    Clock:        "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2",
    Coins:        "M12 12m-8 0a8 8 0 1 0 16 0 8 8 0 0 0-16 0M12 6v.01M12 18v.01",
    Flame:        "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",
    ArrowUp:      "M12 19V5M5 12l7-7 7 7",
    Settings:     "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
  };
  const d = paths[name] || paths.X;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, ...extraStyle }}>
      <path d={d} />
    </svg>
  );
}

// ─── XP Ring ─────────────────────────────────────────────────────────────────
function XpRing({ totalXp, size = 52, children }) {
  const level = getLevel(totalXp);
  const nextLvl = Math.min(level + 1, LEVEL_XP.length - 1);
  const from = LEVEL_XP[level], to = LEVEL_XP[nextLvl];
  const pct = nextLvl === level ? 1 : (totalXp - from) / (to - from);
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const dash = pct * circ;
  const color = LEVEL_COLORS[level];
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ position: "absolute", top: 0, left: 0, transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#222" strokeWidth={3} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={3}
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.5s ease" }} />
      </svg>
      <div style={{ position: "absolute", inset: 3, borderRadius: "50%", overflow: "hidden",
        display: "flex", alignItems: "center", justifyContent: "center", background: "#0d0d0d" }}>
        {children}
      </div>
    </div>
  );
}

// ─── Level Badge ──────────────────────────────────────────────────────────────
function LevelBadge({ totalXp, small = false }) {
  const level = getLevel(totalXp);
  const color = LEVEL_COLORS[level];
  return (
    <span style={{ background: color + "22", border: `1px solid ${color}55`, color,
      fontSize: small ? 8 : 9, fontWeight: 700, letterSpacing: "0.04em", padding: small ? "1px 5px" : "2px 7px",
      borderRadius: 4, textTransform: "uppercase" }}>
      {LEVEL_NAMES[level]}
    </span>
  );
}

// ─── Stat Bar ─────────────────────────────────────────────────────────────────
function StatBar({ label, value, color }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: 10, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em" }}>{label}</span>
        <span style={{ fontSize: 10, color: "#888", fontWeight: 600 }}>{Math.round(value)}%</span>
      </div>
      <div style={{ background: "#111", height: 3, borderRadius: 2, overflow: "hidden", border: "1px solid #1e1e1e" }}>
        <div style={{ height: "100%", width: `${value}%`, background: color, borderRadius: 2,
          transition: "width 0.6s ease", boxShadow: `0 0 6px ${color}66` }} />
      </div>
    </div>
  );
}

// ─── Skill Bar ────────────────────────────────────────────────────────────────
function SkillBar({ skill, isHovered, synergy }) {
  const pct = Math.min((skill.xp / skill.maxXp) * 100, 100);
  const lit = isHovered && synergy?.skills.includes(skill.name);
  return (
    <div style={{ padding: "5px 8px", borderRadius: 8, border: `1px solid ${lit ? "#6366f1" : "transparent"}`,
      background: lit ? "#6366f108" : "transparent", transition: "all 0.2s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
        <span style={{ fontSize: 11, color: lit ? "#a5b4fc" : "#777" }}>{skill.name} {lit && "↑"}</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: lit ? "#818cf8" : "#ccc" }}>Lv{skill.level}</span>
      </div>
      <div style={{ background: "#111", height: 3, borderRadius: 2, overflow: "hidden", border: "1px solid #1e1e1e" }}>
        <div style={{ width: `${pct}%`, height: "100%", borderRadius: 2, transition: "width 0.5s",
          background: lit ? "#6366f1" : "#fff", boxShadow: lit ? "0 0 6px #6366f1" : "0 0 5px #eee" }} />
      </div>
      <div style={{ fontSize: 9, color: "#444", marginTop: 2 }}>{Math.floor(skill.xp)} / {skill.maxXp} XP</div>
    </div>
  );
}

// ─── Room Icon ────────────────────────────────────────────────────────────────
function RoomIcon({ id, size = 14, color = "#666" }) {
  const map = { work_area: "Laptop", daily_room: "Users", pitch_arena: "Presentation",
    training_room: "Brain", break_room: "Coffee", director_office: "Briefcase" };
  return <Icon name={map[id] || "Laptop"} size={size} color={color} />;
}

// ─── Simple Markdown ──────────────────────────────────────────────────────────
function SimpleMarkdown({ text }) {
  if (!text) return null;
  return (
    <div style={{ fontSize: 12, lineHeight: 1.75, color: "#777" }}>
      {text.split("\n").map((line, i) => {
        if (line.startsWith("## ")) return <h3 key={i} style={{ color: "#ddd", fontWeight: 700, fontSize: 13, margin: "10px 0 4px" }}>{line.slice(3)}</h3>;
        if (line.startsWith("# "))  return <h2 key={i} style={{ color: "#ddd", fontWeight: 700, fontSize: 14, margin: "12px 0 6px" }}>{line.slice(2)}</h2>;
        if (line.startsWith("- "))  return <div key={i} style={{ paddingLeft: 12, marginBottom: 2 }}>• {line.slice(2)}</div>;
        if (line.startsWith("**")) { const c = line.replace(/\*\*(.*?)\*\*/g, "$1"); return <p key={i} style={{ fontWeight: 600, color: "#ddd", marginBottom: 2 }}>{c}</p>; }
        if (!line.trim())           return <div key={i} style={{ height: 6 }} />;
        return <p key={i} style={{ marginBottom: 2 }}>{line}</p>;
      })}
    </div>
  );
}

// ─── Task Flowchart (simple vertical DAG) ─────────────────────────────────────
function TaskFlowchart({ tasks }) {
  if (!tasks || tasks.length === 0) return <div style={{ fontSize: 11, color: "#444" }}>No tasks.</div>;
  const statusColor = { todo: "#444", doing: "#3b82f6", done: "#22c55e" };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {tasks.map((t, i) => {
        const blocked = t.status !== "done" && t.dependencies?.some(d => tasks.find(x=>x.id===d)?.status !== "done");
        return (
          <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {i > 0 && <div style={{ width: 1, height: 12, background: "#222", marginLeft: 10, marginTop: -6, position: "absolute" }} />}
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: blocked ? "#2a2a2a" : statusColor[t.status], flexShrink: 0,
              boxShadow: t.status === "doing" ? "0 0 6px #3b82f6" : "none", border: `1px solid ${blocked ? "#333" : statusColor[t.status]}` }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: blocked ? "#444" : t.status === "done" ? "#22c55e" : "#bbb",
                textDecoration: blocked ? "line-through" : "none", lineHeight: 1.4 }}>{t.label}</div>
              {t.status === "doing" && t.progress > 0 && (
                <div style={{ background: "#111", height: 2, borderRadius: 1, marginTop: 3, overflow: "hidden" }}>
                  <div style={{ height: "100%", background: "#3b82f6", width: `${t.progress}%` }} />
                </div>
              )}
            </div>
            <div style={{ fontSize: 9, color: blocked ? "#333" : statusColor[t.status], textTransform: "uppercase", letterSpacing: "0.04em" }}>
              {blocked ? "blocked" : t.status}
            </div>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { Icon, XpRing, LevelBadge, StatBar, SkillBar, RoomIcon, SimpleMarkdown, TaskFlowchart });
