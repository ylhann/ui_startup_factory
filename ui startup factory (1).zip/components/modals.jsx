// ─── Modals ───────────────────────────────────────────────────────────────────
// Depends on: window globals from data.jsx + ui.jsx

const { useState: useStateM, useEffect: useEffectM } = React;

// ─── AI helper (uses claude via window.claude if available, else demo text) ───
async function callAI(system, userPrompt, maxTokens = 400) {
  if (window.claude) {
    try {
      return await window.claude.complete({ messages: [{ role: "user", content: `SYSTEM: ${system}\n\nUSER: ${userPrompt}` }] });
    } catch { return getDemoText(system); }
  }
  return getDemoText(system);
}

function getDemoText(system) {
  if (system.includes("coffee")) return `[Alex AI]: I've been battling int8 quantization all morning — accuracy keeps dipping below threshold.\n[Casey Cloud]: Interesting, reminds me of the precision issues we hit with our sensor pipeline. We solved it with a calibration step before export.\n[Alex AI]: Oh, that's clever. We could add a per-layer scale factor post-quantization.\n[Casey Cloud]: Exactly. Took us two days to figure out, but it's now baked into our CI.\n[Alex AI]: I'll loop in Sam to redesign the calibration UI — it needs to be accessible for non-ML folks.\n[Casey Cloud]: Smart move. Documentation is half the battle.\n==KNOWLEDGE==\nCalibration step before quantization export significantly reduces accuracy loss in production AI models.`;
  if (system.includes("Director")) return `## Core Idea Soundness\n\nSolid market fit with a clear technical differentiation. The decentralized approach is timely but adds coordination complexity.\n\n## Execution Risks\n\n- **Team concentration**: Too much expertise in one domain; missing GTM muscle\n- **Timeline**: Seed runway with 4 pending milestones is aggressive\n- **Regulatory**: Decentralized AI networks face evolving compliance landscapes\n\n## Actionable Improvements\n\n- Hire a Head of Partnerships in the next 30 days\n- Compress milestones 3 and 4 into a single phased launch\n- Begin regulatory mapping in EU and US markets immediately`;
  return "The simulation is running in demo mode. Connect your API key to enable live AI responses.";
}

// ─── Overlay backdrop ─────────────────────────────────────────────────────────
function Backdrop({ children, onClose }) {
  return (
    <div onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ position: "fixed", inset: 0, zIndex: 200, display: "flex", alignItems: "center",
        justifyContent: "center", padding: 24, background: "rgba(2,4,8,0.88)", backdropFilter: "blur(12px)" }}>
      {children}
    </div>
  );
}

// ─── Modal card ───────────────────────────────────────────────────────────────
function ModalCard({ children, maxWidth = 560, style: extra = {} }) {
  return (
    <div style={{ background: "#0f0f0f", border: "1px solid #222", borderRadius: 20,
      width: "100%", maxWidth, padding: 32, position: "relative", overflow: "hidden",
      boxShadow: "0 32px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.03)", ...extra }}>
      {children}
    </div>
  );
}

// ─── Modal header ─────────────────────────────────────────────────────────────
function ModalHeader({ title, subtitle, icon, iconBg = "#1a1a1a", onClose }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
      marginBottom: 24, paddingBottom: 20, borderBottom: "1px solid #1e1e1e" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        {icon && (
          <div style={{ width: 44, height: 44, background: iconBg, borderRadius: 12,
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "1px solid rgba(255,255,255,0.07)", fontSize: 22 }}>
            {icon}
          </div>
        )}
        <div>
          <div style={{ fontWeight: 800, color: "#f0f0f0", fontSize: 14, letterSpacing: "0.04em", textTransform: "uppercase" }}>{title}</div>
          {subtitle && <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>{subtitle}</div>}
        </div>
      </div>
      <button onClick={onClose} style={{ background: "#1a1a1a", border: "1px solid #2a2a2a",
        borderRadius: 10, padding: 8, cursor: "pointer", color: "#555", display: "flex" }}>
        <Icon name="X" size={15} color="#666" />
      </button>
    </div>
  );
}

// ─── Coffee Meeting Modal ──────────────────────────────────────────────────────
function CoffeeMeetingModal({ agents, startups, onClose }) {
  const [lines, setLines] = useStateM([]);
  const [knowledge, setKnowledge] = useStateM("");
  const [loading, setLoading] = useStateM(true);

  useEffectM(() => {
    (async () => {
      const names = agents.map(a => `${a.name} (${a.expertise}, ${startups.find(s=>s.id===a.startupId)?.name})`).join(" and ");
      const skills = agents.map(a => `${a.name}: ${a.skills.map(s=>`${s.name} Lv${s.level}`).join(", ")}`).join(" | ");
      const tasks  = agents.map(a => `${a.name}: ${a.tasks.find(t=>t.status==="doing")?.label || "idle"}`).join(" | ");
      const transcript = await callAI(
        "You simulate a realistic coffee break conversation between AI agents. Each shares something useful from their work.",
        `Coffee break: ${names}. Skills: ${skills}. Work: ${tasks}. Write 6-8 dialogue exchanges as [Name]: message. End with ==KNOWLEDGE== and a one-sentence insight.`,
        600
      );
      const parts = transcript.split("==KNOWLEDGE==");
      setLines((parts[0] || transcript).trim().split("\n").filter(l => l.trim()));
      setKnowledge((parts[1] || "").trim());
      setLoading(false);
    })();
  }, []);

  return (
    <Backdrop onClose={onClose}>
      <ModalCard maxWidth={580}>
        <ModalHeader title="☕ Coffee Meeting" subtitle={agents.map(a=>a.name).join(" × ")} icon="☕" onClose={onClose} />
        {/* Agent avatars */}
        <div style={{ display: "flex", gap: 16, justifyContent: "center", marginBottom: 20 }}>
          {agents.map(a => {
            const s = startups.find(x=>x.id===a.startupId);
            return (
              <div key={a.id} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: 48, height: 48, background: "#111", border: `2px solid ${LEVEL_COLORS[getLevel(a.totalXp)]}`,
                  borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{a.avatar}</div>
                <div style={{ fontSize: 10, color: "#888", textAlign: "center" }}>{a.name}</div>
                <div style={{ fontSize: 9, color: "#444" }}>{s?.name}</div>
              </div>
            );
          })}
        </div>
        {/* Transcript */}
        <div style={{ background: "#080808", border: "1px solid #1a1a1a", borderRadius: 14,
          padding: 18, maxHeight: 260, overflowY: "auto", marginBottom: 16 }}>
          {loading ? (
            <div style={{ textAlign: "center", color: "#444", fontSize: 12, padding: 24 }}>Connecting agents…</div>
          ) : (
            lines.map((line, i) => {
              const match = line.match(/^\[([^\]]+)\]:\s*(.*)/);
              if (!match) return null;
              const [, speaker, msg] = match;
              const agent = agents.find(a => a.name.includes(speaker) || speaker.includes(a.name.split(" ")[0]));
              return (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 14, alignItems: "flex-start" }}>
                  <div style={{ width: 28, height: 28, background: "#111", borderRadius: 8, flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, border: "1px solid #222" }}>
                    {agent?.avatar || "👤"}
                  </div>
                  <div>
                    <div style={{ fontSize: 10, color: "#eee", marginBottom: 2, fontWeight: 700, letterSpacing: "0.04em" }}>{speaker.toUpperCase()}</div>
                    <div style={{ fontSize: 12, color: "#777", lineHeight: 1.65 }}>{msg}</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
        {/* Knowledge */}
        {knowledge && (
          <div style={{ background: "#0c0c14", border: "1px solid #2a2a4a", borderRadius: 12, padding: 16, display: "flex", gap: 10 }}>
            <Icon name="Sparkles" size={14} color="#818cf8" style={{ marginTop: 2, flexShrink: 0 }} />
            <div>
              <div style={{ fontSize: 10, color: "#818cf8", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 4 }}>Knowledge Captured</div>
              <div style={{ fontSize: 12, color: "#666" }}>{knowledge}</div>
            </div>
          </div>
        )}
        {!loading && (
          <div style={{ display: "flex", gap: 8, marginTop: 14, justifyContent: "center" }}>
            {agents.map(a => (
              <div key={a.id} style={{ fontSize: 10, color: "#22c55e", background: "#22c55e11",
                border: "1px solid #22c55e33", borderRadius: 6, padding: "3px 10px" }}>
                +30 XP · +15 ST → {a.name.split(" ")[0]}
              </div>
            ))}
          </div>
        )}
      </ModalCard>
    </Backdrop>
  );
}

// ─── Pitch Feedback Modal ──────────────────────────────────────────────────────
function PitchFeedbackModal({ startup, onClose }) {
  const [content, setContent] = useStateM("");
  const [loading, setLoading] = useStateM(true);

  useEffectM(() => {
    (async () => {
      const text = await callAI(
        "You are a ruthless but constructive Incubator Director at 'The Pépinière'. Give structured, realistic feedback. Use markdown with ## sections for: Core Idea Soundness, Execution Risks, Actionable Improvements. Be concise and brutally honest.",
        `Startup: "${startup.name}" | Stage: ${startup.parameters.funding} | Objective: "${startup.objective}" | Stealth: ${startup.parameters.stealth}`,
        500
      );
      setContent(text);
      setLoading(false);
    })();
  }, []);

  return (
    <Backdrop onClose={onClose}>
      <ModalCard maxWidth={620} style={{ maxHeight: "85vh", overflow: "hidden", display: "flex", flexDirection: "column", border: "1px solid #2a1a4a", boxShadow: "0 0 60px rgba(99,102,241,0.1)" }}>
        <ModalHeader title={`${startup.name} — Evaluation`} subtitle="● INCUBATOR DIRECTOR ANALYSIS"
          icon={startup.logo} iconBg="#1a0a2a" onClose={onClose} />
        <div style={{ overflowY: "auto", flex: 1 }}>
          {loading ? (
            <div style={{ textAlign: "center", color: "#444", fontSize: 12, padding: 40 }}>Director is reviewing your pitch…</div>
          ) : <SimpleMarkdown text={content} />}
        </div>
      </ModalCard>
    </Backdrop>
  );
}

// ─── Kanban Board Modal ────────────────────────────────────────────────────────
function KanbanModal({ startup, employees, setEmployees, onClose }) {
  const [dragInfo, setDragInfo] = useStateM(null);
  const team = employees.filter(e => e.startupId === startup.id);
  const cols = [
    { id: "todo",  label: "To Do",       color: "#555" },
    { id: "doing", label: "In Progress", color: "#3b82f6" },
    { id: "done",  label: "Done",        color: "#22c55e" },
  ];

  const moveTask = (empId, taskId, status) => {
    setEmployees(prev => prev.map(e => e.id !== empId ? e : {
      ...e, tasks: e.tasks.map(t => t.id !== taskId ? t : {
        ...t, status, progress: status === "todo" ? 0 : status === "done" ? 100 : t.progress
      })
    }));
  };

  return (
    <Backdrop onClose={onClose}>
      <ModalCard maxWidth={1160} style={{ height: "88vh", display: "flex", flexDirection: "column", padding: 0, overflow: "hidden" }}>
        {/* Header */}
        <div style={{ padding: "20px 28px", borderBottom: "1px solid #1a1a1a", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 44, height: 44, background: "#111", border: "1px solid #222", borderRadius: 12,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>{startup.logo}</div>
            <div>
              <div style={{ fontWeight: 800, color: "#eee", fontSize: 16 }}>{startup.name} Dashboard</div>
              <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>{team.length} Active Agents · {startup.parameters.funding} Stage</div>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", cursor: "pointer", color: "#555", padding: 6, borderRadius: 8 }}>
            <Icon name="X" size={18} color="#666" />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 24, display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Milestones timeline */}
          {startup.milestones?.length > 0 && (
            <div style={{ background: "#080808", border: "1px solid #1a1a1a", borderRadius: 16, padding: 22 }}>
              <div style={{ fontSize: 11, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em", fontWeight: 700, marginBottom: 20, display: "flex", alignItems: "center", gap: 8 }}>
                <Icon name="TrendingUp" size={13} color="#3b82f6" /> Project Milestones
              </div>
              <div style={{ display: "flex", alignItems: "flex-start" }}>
                {startup.milestones.map((m, i) => {
                  const done = m.status === "completed", active = m.status === "in-progress";
                  const last = i === startup.milestones.length - 1;
                  return (
                    <div key={m.id} style={{ display: "flex", flex: last ? "none" : 1, position: "relative" }}>
                      {!last && <div style={{ position: "absolute", top: 11, left: 22, right: -8, height: 2,
                        background: done ? "#3b82f6" : "#1a1a1a", zIndex: 1 }} />}
                      <div style={{ position: "relative", zIndex: 2, display: "flex", flexDirection: "column", gap: 10, width: 140 }}>
                        <div style={{ width: 22, height: 22, borderRadius: "50%",
                          background: done ? "#3b82f6" : "#0f0f0f",
                          border: `2px solid ${done ? "#3b82f6" : active ? "#3b82f6" : "#2a2a2a"}`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          boxShadow: active ? "0 0 0 4px rgba(59,130,246,0.12)" : "none" }}>
                          {done && <Icon name="Check" size={12} color="white" />}
                          {active && <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#3b82f6", animation: "milePulse 2s infinite" }} />}
                        </div>
                        <div style={{ paddingRight: 14 }}>
                          <div style={{ fontSize: 11, fontWeight: 600, color: done ? "#ddd" : active ? "#3b82f6" : "#444", lineHeight: 1.4 }}>{m.label}</div>
                          <div style={{ fontSize: 10, color: "#333", marginTop: 3, textTransform: "capitalize" }}>{m.status.replace("-", " ")}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Kanban */}
          <div style={{ display: "flex", gap: 14, flex: 1, minHeight: 320 }}>
            {cols.map(col => {
              const colTasks = team.flatMap(e => e.tasks.filter(t => t.status === col.id).map(t => ({ ...t, empId: e.id, empName: e.name, empAvatar: e.avatar })));
              return (
                <div key={col.id}
                  onDragOver={e => e.preventDefault()}
                  onDrop={e => { e.preventDefault(); const d = JSON.parse(e.dataTransfer.getData("text/plain")); moveTask(d.empId, d.taskId, col.id); }}
                  style={{ flex: 1, background: "#080808", border: "1px solid #1a1a1a", borderRadius: 16, padding: 18, display: "flex", flexDirection: "column" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, paddingBottom: 12, borderBottom: "1px solid #1a1a1a" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ width: 7, height: 7, borderRadius: "50%", background: col.color }} />
                      <span style={{ fontSize: 12, fontWeight: 600, color: "#ccc" }}>{col.label}</span>
                    </div>
                    <span style={{ fontSize: 10, color: "#555", background: "#111", padding: "2px 8px", borderRadius: 10 }}>{colTasks.length}</span>
                  </div>
                  <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10, overflowY: "auto" }}>
                    {colTasks.map(task => {
                      const blocked = task.status !== "done" && task.dependencies?.some(d => {
                        const owner = team.find(e => e.tasks.some(t => t.id === d));
                        return owner?.tasks.find(t => t.id === d)?.status !== "done";
                      });
                      return (
                        <div key={task.id} draggable
                          onDragStart={e => e.dataTransfer.setData("text/plain", JSON.stringify({ empId: task.empId, taskId: task.id }))}
                          style={{ background: "#0f0f0f", border: `1px solid ${blocked ? "#1a1a1a" : "#222"}`, borderRadius: 12, padding: 14, cursor: "grab",
                            opacity: blocked ? 0.5 : 1, transition: "all 0.2s" }}>
                          <div style={{ fontSize: 11, color: blocked ? "#444" : "#ccc", lineHeight: 1.5, textDecoration: blocked ? "line-through" : "none", marginBottom: 8 }}>{task.label}</div>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <span style={{ fontSize: 13 }}>{task.empAvatar}</span>
                              <span style={{ fontSize: 10, color: "#444" }}>{task.empName.split(" ")[0]}</span>
                            </div>
                            {blocked && <span style={{ fontSize: 9, color: "#f59e0b", background: "#f59e0b11", border: "1px solid #f59e0b22", borderRadius: 4, padding: "1px 6px" }}>blocked</span>}
                          </div>
                          {task.status === "doing" && task.progress > 0 && (
                            <div style={{ background: "#111", height: 2, borderRadius: 1, marginTop: 10, overflow: "hidden" }}>
                              <div style={{ height: "100%", background: "#3b82f6", width: `${task.progress}%` }} />
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {colTasks.length === 0 && <div style={{ textAlign: "center", color: "#2a2a2a", fontSize: 11, padding: "20px 0" }}>Drop tasks here</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </ModalCard>
    </Backdrop>
  );
}

// ─── Add Startup Modal ─────────────────────────────────────────────────────────
function AddStartupModal({ onAdd, onClose }) {
  const [name, setName] = useStateM("");
  const [objective, setObjective] = useStateM("");
  const [repo, setRepo] = useStateM("");

  const inputStyle = { width: "100%", background: "#080808", border: "1px solid #222", borderRadius: 10,
    padding: "10px 14px", color: "#ddd", fontSize: 12, outline: "none", boxSizing: "border-box" };
  const labelStyle = { fontSize: 10, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em",
    fontWeight: 700, display: "block", marginBottom: 6 };

  return (
    <Backdrop onClose={onClose}>
      <ModalCard maxWidth={440}>
        <ModalHeader title="Register New Venture" icon="🚀" onClose={onClose} />
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {[["Startup Name *", name, setName, "e.g. Nexus.io", false],
            ["Target Objective", objective, setObjective, "Primary simulation goal…", true],
            ["Cloud Repository (Optional)", repo, setRepo, "e.g. github.com/user/repo", false]].map(([label, val, set, ph, isArea]) => (
            <div key={label}>
              <label style={labelStyle}>{label}</label>
              {isArea
                ? <textarea value={val} onChange={e => set(e.target.value)} placeholder={ph}
                    style={{ ...inputStyle, height: 68, resize: "none" }} />
                : <input value={val} onChange={e => set(e.target.value)} placeholder={ph} style={inputStyle} />}
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
          <button onClick={onClose} style={{ flex: 1, padding: 14, background: "#111", border: "1px solid #222",
            borderRadius: 12, color: "#666", fontWeight: 700, fontSize: 11, textTransform: "uppercase", cursor: "pointer", letterSpacing: "0.06em" }}>Abort</button>
          <button onClick={() => { onAdd(name, objective, repo); onClose(); }}
            disabled={!name.trim()}
            style={{ flex: 2, padding: 14, background: name.trim() ? "#0891b2" : "#111", border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 12, color: name.trim() ? "white" : "#333", fontWeight: 800, fontSize: 11,
              textTransform: "uppercase", cursor: name.trim() ? "pointer" : "not-allowed", letterSpacing: "0.06em",
              boxShadow: name.trim() ? "0 0 20px rgba(8,145,178,0.25)" : "none" }}>Confirm Entry</button>
        </div>
      </ModalCard>
    </Backdrop>
  );
}

// ─── Add Employee Modal ────────────────────────────────────────────────────────
function AddEmployeeModal({ startups, onAdd, onClose }) {
  const [name, setName] = useStateM("");
  const [expertise, setExpertise] = useStateM("Frontend");
  const [startupId, setStartupId] = useStateM(startups[0]?.id || "");
  const [skill1, setSkill1] = useStateM("React");
  const [skill2, setSkill2] = useStateM("TypeScript");
  const avatar = AVATAR_POOL[Math.floor(Math.random() * AVATAR_POOL.length)];

  const inputStyle = { width: "100%", background: "#080808", border: "1px solid #222", borderRadius: 10,
    padding: "10px 14px", color: "#ddd", fontSize: 12, outline: "none", boxSizing: "border-box" };
  const labelStyle = { fontSize: 10, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em",
    fontWeight: 700, display: "block", marginBottom: 6 };

  const handleSubmit = () => {
    if (!name.trim()) return;
    onAdd({ id: `e${Date.now()}`, name: name.trim(), avatar, expertise, startupId,
      currentRoom: "work_area", mood: "happy", energy: 100, stress: 0, experience: 1,
      totalXp: 0, skillTokens: 100,
      skills: [{ name: skill1 || "Skill A", level: 1, xp: 0, maxXp: 100 }, { name: skill2 || "Skill B", level: 1, xp: 0, maxXp: 100 }],
      tasks: [{ id: `t${Date.now()}`, label: "Initialize workspace", status: "todo", progress: 0 }],
      journal: ["Just joined the team. Ready to ship."],
    });
    onClose();
  };

  return (
    <Backdrop onClose={onClose}>
      <ModalCard maxWidth={420}>
        <ModalHeader title="Deploy New Agent" icon="🤖" onClose={onClose} />
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label style={labelStyle}>Agent Name *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Jordan Dev" style={inputStyle} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={labelStyle}>Expertise</label>
              <select value={expertise} onChange={e => setExpertise(e.target.value)} style={{ ...inputStyle, cursor: "pointer" }}>
                {EXPERTISE_OPTS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Startup</label>
              <select value={startupId} onChange={e => setStartupId(e.target.value)} style={{ ...inputStyle, cursor: "pointer" }}>
                {startups.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div><label style={labelStyle}>Skill A</label><input value={skill1} onChange={e => setSkill1(e.target.value)} placeholder="React" style={inputStyle} /></div>
            <div><label style={labelStyle}>Skill B</label><input value={skill2} onChange={e => setSkill2(e.target.value)} placeholder="TypeScript" style={inputStyle} /></div>
          </div>
          <div style={{ background: "#080808", border: "1px solid #1a1a1a", borderRadius: 12, padding: "10px 14px",
            display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 24 }}>{avatar}</span>
            <div>
              <div style={{ fontSize: 11, color: "#666" }}>Avatar assigned randomly</div>
              <div style={{ fontSize: 10, color: "#333", marginTop: 2 }}>Starts at Level 1 · 100 SkillTokens</div>
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 24 }}>
          <button onClick={onClose} style={{ flex: 1, padding: 14, background: "#111", border: "1px solid #222",
            borderRadius: 12, color: "#666", fontWeight: 700, fontSize: 11, textTransform: "uppercase", cursor: "pointer", letterSpacing: "0.06em" }}>Abort</button>
          <button onClick={handleSubmit} disabled={!name.trim()}
            style={{ flex: 2, padding: 14, background: name.trim() ? "#0891b2" : "#111", border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 12, color: name.trim() ? "white" : "#333", fontWeight: 800, fontSize: 11,
              textTransform: "uppercase", cursor: name.trim() ? "pointer" : "not-allowed", letterSpacing: "0.06em",
              boxShadow: name.trim() ? "0 0 20px rgba(8,145,178,0.25)" : "none" }}>Confirm Deploy</button>
        </div>
      </ModalCard>
    </Backdrop>
  );
}

Object.assign(window, { CoffeeMeetingModal, PitchFeedbackModal, KanbanModal, AddStartupModal, AddEmployeeModal });
